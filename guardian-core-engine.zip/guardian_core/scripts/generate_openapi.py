"""
Generates openapi.yaml from a Python dict. Run after adding/changing
any endpoint in app/main.py:

    python scripts/generate_openapi.py

Kept as a generator rather than hand-maintained YAML so common pieces
(security requirements, standard error responses) stay consistent
across all 60 endpoints instead of drifting one at a time.
"""

import os
import yaml

ERROR_SCHEMA_REF = {"$ref": "#/components/schemas/ErrorResponse"}


def err(status_desc: str):
    return {"description": status_desc, "content": {"application/json": {"schema": ERROR_SCHEMA_REF}}}


STANDARD_ERRORS = {
    "401": err("Missing or invalid Authorization bearer token"),
    "403": err("Forbidden — caller/admin not authorized for this action"),
    "404": err("Not found"),
    "409": err("Conflict — invalid state transition or validation failure"),
}


def ok(schema_ref: str, is_array: bool = False, description: str = "OK"):
    schema = {"type": "array", "items": {"$ref": schema_ref}} if is_array else {"$ref": schema_ref}
    return {"200": {"description": description, "content": {"application/json": {"schema": schema}}}}


def body(schema_ref: str):
    return {"required": True, "content": {"application/json": {"schema": {"$ref": schema_ref}}}}


def op(summary, tag, responses, request_body_ref=None, params=None, needs_admin_key=False):
    entry = {
        "summary": summary,
        "tags": [tag],
        "security": [{"ServiceApiKey": []}] + ([{"AdminApiKey": []}] if needs_admin_key else []),
        "responses": {**responses, **STANDARD_ERRORS},
    }
    if request_body_ref:
        entry["requestBody"] = body(request_body_ref)
    if params:
        entry["parameters"] = params
    return entry


def path_param(name, schema_type="string", description=""):
    return {"name": name, "in": "path", "required": True,
            "schema": {"type": schema_type}, "description": description}


def query_param(name, schema_type="string", description=""):
    return {"name": name, "in": "query", "required": False,
            "schema": {"type": schema_type}, "description": description}


# ---------------------------------------------------------------
# Component schemas
# ---------------------------------------------------------------

SCHEMAS = {
    "ErrorResponse": {
        "type": "object",
        "properties": {"detail": {"type": "string"}},
    },
    "System": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "system_key": {"type": "string"},
            "display_name": {"type": "string"}, "category": {"type": "string"},
            "criticality": {"type": "string", "enum": ["low", "medium", "high", "critical"]},
            "trust_level": {"type": "string", "enum": ["standard", "elevated", "restricted"]},
            "permitted_categories": {"type": "array", "items": {"type": "string"}},
            "connection_type": {"type": "string"}, "is_active": {"type": "boolean"},
        },
    },
    "SystemCreate": {
        "type": "object", "required": ["system_key", "display_name", "category"],
        "properties": {
            "system_key": {"type": "string"}, "display_name": {"type": "string"},
            "category": {"type": "string"}, "criticality": {"type": "string", "default": "medium"},
            "trust_level": {"type": "string", "default": "standard"},
            "permitted_categories": {"type": "array", "items": {"type": "string"}},
            "connection_type": {"type": "string", "default": "api_poll"},
        },
    },
    "Check": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "name": {"type": "string"}, "category": {"type": "string"},
            "scope": {"type": "string", "enum": ["single_system", "cross_system"]},
            "system_id": {"type": "string", "nullable": True},
            "check_logic_ref": {"type": "string"}, "run_frequency": {"type": "string"},
            "severity_default": {"type": "string"}, "is_active": {"type": "boolean"},
            "auto_fix_allowed": {"type": "boolean"},
        },
    },
    "CheckCreate": {
        "type": "object", "required": ["name", "category", "check_logic_ref"],
        "properties": {
            "name": {"type": "string"}, "category": {"type": "string"},
            "scope": {"type": "string", "default": "single_system"},
            "system_id": {"type": "string", "nullable": True},
            "target_module": {"type": "string", "nullable": True},
            "check_logic_ref": {"type": "string"},
            "run_frequency": {"type": "string", "default": "hourly"},
            "severity_default": {"type": "string", "default": "medium"},
            "auto_fix_allowed": {"type": "boolean", "default": False},
        },
    },
    "Finding": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "check_id": {"type": "string"},
            "system_id": {"type": "string", "nullable": True},
            "entity_type": {"type": "string"}, "entity_id": {"type": "string", "nullable": True},
            "severity": {"type": "string"}, "summary": {"type": "string"},
            "status": {"type": "string", "enum": ["open", "acknowledged", "fixed", "dismissed", "false_positive"]},
            "detected_at": {"type": "string", "format": "date-time"},
            "resolved_at": {"type": "string", "format": "date-time", "nullable": True},
            "resolved_by": {"type": "string", "nullable": True},
        },
    },
    "FindingCreate": {
        "type": "object", "required": ["check_id", "entity_type", "severity", "summary"],
        "properties": {
            "check_id": {"type": "string"}, "system_id": {"type": "string", "nullable": True},
            "entity_type": {"type": "string"}, "entity_id": {"type": "string", "nullable": True},
            "severity": {"type": "string"}, "summary": {"type": "string"},
            "evidence_json": {"type": "object", "nullable": True},
        },
    },
    "FindingResolve": {
        "type": "object", "required": ["resolved_by"],
        "properties": {
            "resolved_by": {"type": "string"},
            "status": {"type": "string", "default": "fixed",
                       "enum": ["fixed", "dismissed", "false_positive"]},
        },
    },
    "FixProposal": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "finding_id": {"type": "string"}, "system_id": {"type": "string"},
            "proposed_action": {"type": "string"}, "category": {"type": "string"},
            "risk_level": {"type": "string", "enum": ["low", "medium", "high"]},
            "requires_approval": {"type": "boolean"},
            "approved_by": {"type": "string", "nullable": True},
            "approved_at": {"type": "string", "format": "date-time", "nullable": True},
            "auto_applied": {"type": "boolean"},
            "applied_at": {"type": "string", "format": "date-time", "nullable": True},
            "status": {"type": "string", "enum": ["pending", "approved", "applied", "rejected"]},
        },
    },
    "FixProposalCreate": {
        "type": "object",
        "required": ["finding_id", "system_id", "proposed_action", "category", "risk_level"],
        "properties": {
            "finding_id": {"type": "string"}, "system_id": {"type": "string"},
            "proposed_action": {"type": "string"}, "change_json": {"type": "object"},
            "category": {"type": "string",
                         "description": "finance/payroll/benefits/compensation/tax/vault_secret/"
                                        "code_patch/infrastructure ALWAYS require approval regardless of risk_level"},
            "risk_level": {"type": "string", "enum": ["low", "medium", "high"]},
        },
    },
    "FixProposalReject": {
        "type": "object",
        "properties": {"reason": {"type": "string", "nullable": True}},
    },
    "Admin": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "identity_ref": {"type": "string"},
            "role": {"type": "string", "enum": ["viewer", "approver", "super_admin"]},
            "system_scope": {"type": "array", "items": {"type": "string"}, "nullable": True},
            "api_key": {"type": "string",
                        "description": "Raw API key — returned ONLY at creation, never retrievable again"},
        },
    },
    "AdminCreate": {
        "type": "object", "required": ["identity_ref"],
        "properties": {
            "identity_ref": {"type": "string"}, "role": {"type": "string", "default": "viewer"},
            "system_scope": {"type": "array", "items": {"type": "string"}, "nullable": True},
        },
    },
    "ActionLogEntry": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "system_id": {"type": "string", "nullable": True},
            "action_type": {"type": "string"}, "reference_table": {"type": "string"},
            "reference_id": {"type": "string"}, "detail_json": {"type": "object"},
            "occurred_at": {"type": "string", "format": "date-time"},
        },
    },
    "SecurityIncident": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "system_id": {"type": "string", "nullable": True},
            "incident_type": {"type": "string"}, "severity": {"type": "string"},
            "auto_response": {"type": "string", "nullable": True,
                               "enum": ["session_terminated", "account_locked", "mfa_forced", None]},
            "status": {"type": "string", "enum": ["open", "investigating", "contained", "resolved"]},
            "detected_at": {"type": "string", "format": "date-time"},
        },
    },
    "SecurityIncidentCreate": {
        "type": "object", "required": ["incident_type", "severity"],
        "properties": {
            "incident_type": {"type": "string"}, "severity": {"type": "string"},
            "system_id": {"type": "string", "nullable": True},
            "actor_ref": {"type": "string", "nullable": True},
            "source_ip": {"type": "string", "nullable": True},
            "auto_response": {"type": "string", "nullable": True,
                               "description": "Must be one of session_terminated/account_locked/mfa_forced or null"},
            "evidence_json": {"type": "object", "nullable": True},
        },
    },
    "EscalationPolicy": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "name": {"type": "string"},
            "applies_to_severity": {"type": "string"},
            "system_id": {"type": "string", "nullable": True},
            "escalation_order": {"type": "array", "items": {"type": "string"}},
            "step_timeout_minutes": {"type": "integer"}, "is_active": {"type": "boolean"},
        },
    },
    "EscalationPolicyCreate": {
        "type": "object", "required": ["name", "applies_to_severity", "escalation_order"],
        "properties": {
            "name": {"type": "string"}, "applies_to_severity": {"type": "string"},
            "system_id": {"type": "string", "nullable": True,
                          "description": "Omit for a global policy applying to every system"},
            "escalation_order": {"type": "array", "items": {"type": "string"},
                                  "description": "Ordered list of admin identity_refs"},
            "step_timeout_minutes": {"type": "integer", "default": 30},
        },
    },
    "EscalationEvent": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "policy_id": {"type": "string"},
            "finding_id": {"type": "string", "nullable": True},
            "security_incident_id": {"type": "string", "nullable": True},
            "current_step": {"type": "integer"}, "notified_ref": {"type": "string"},
            "notified_at": {"type": "string", "format": "date-time"},
            "acknowledged_at": {"type": "string", "format": "date-time", "nullable": True},
            "status": {"type": "string", "enum": ["active", "acknowledged", "exhausted"]},
        },
    },
    "AudioStream": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "system_id": {"type": "string"}, "source_ref": {"type": "string"},
            "channel_count": {"type": "integer"}, "sample_rate_hz": {"type": "integer", "nullable": True},
            "status": {"type": "string", "enum": ["active", "ended"]},
            "channel_ids": {"type": "array", "items": {"type": "string"},
                             "description": "Only present in the create response"},
        },
    },
    "AudioStreamCreate": {
        "type": "object", "required": ["system_id", "source_ref"],
        "properties": {
            "system_id": {"type": "string"}, "source_ref": {"type": "string"},
            "channel_count": {"type": "integer", "default": 1},
            "sample_rate_hz": {"type": "integer", "nullable": True},
        },
    },
    "AudioChannel": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "stream_id": {"type": "string"}, "channel_index": {"type": "integer"},
            "channel_label": {"type": "string", "nullable": True},
            "actor_ref": {"type": "string", "nullable": True},
        },
    },
    "AudioChannelUpdate": {
        "type": "object",
        "properties": {
            "channel_label": {"type": "string", "nullable": True},
            "actor_ref": {"type": "string", "nullable": True},
        },
    },
    "AudioBand": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "name": {"type": "string"},
            "low_hz": {"type": "number"}, "high_hz": {"type": "number"}, "is_active": {"type": "boolean"},
        },
    },
    "AudioBandCreate": {
        "type": "object", "required": ["name", "low_hz", "high_hz"],
        "properties": {
            "name": {"type": "string"}, "low_hz": {"type": "number"}, "high_hz": {"type": "number"},
        },
    },
    "AudioBandMetricCreate": {
        "type": "object", "required": ["channel_id", "band_id", "window_start", "window_end"],
        "properties": {
            "channel_id": {"type": "string"}, "band_id": {"type": "string"},
            "window_start": {"type": "string"}, "window_end": {"type": "string"},
            "avg_level_db": {"type": "number", "nullable": True},
            "peak_level_db": {"type": "number", "nullable": True},
            "noise_floor_db": {"type": "number", "nullable": True},
            "clipping_ratio": {"type": "number", "minimum": 0, "maximum": 1, "nullable": True},
            "silence_ratio": {"type": "number", "minimum": 0, "maximum": 1, "nullable": True},
        },
    },
    "AudioBandMetric": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "channel_id": {"type": "string"}, "band_id": {"type": "string"},
            "window_start": {"type": "string"}, "window_end": {"type": "string"},
            "avg_level_db": {"type": "number", "nullable": True},
            "peak_level_db": {"type": "number", "nullable": True},
            "noise_floor_db": {"type": "number", "nullable": True},
            "clipping_ratio": {"type": "number", "nullable": True},
            "silence_ratio": {"type": "number", "nullable": True},
        },
    },
    "AudioFinding": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "stream_id": {"type": "string"},
            "channel_id": {"type": "string", "nullable": True}, "band_id": {"type": "string", "nullable": True},
            "linked_security_incident_id": {"type": "string", "nullable": True},
            "finding_type": {"type": "string"}, "severity": {"type": "string"},
            "summary": {"type": "string"}, "status": {"type": "string"},
        },
    },
    "AudioFindingCreate": {
        "type": "object", "required": ["stream_id", "finding_type", "severity", "summary"],
        "properties": {
            "stream_id": {"type": "string"}, "finding_type": {"type": "string",
                "description": "'possible_unauthorized_capture' always auto-creates a linked security incident"},
            "severity": {"type": "string"}, "summary": {"type": "string"},
            "channel_id": {"type": "string", "nullable": True}, "band_id": {"type": "string", "nullable": True},
            "evidence_json": {"type": "object", "nullable": True},
        },
    },
    "CodeSignature": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "system_id": {"type": "string"}, "component_ref": {"type": "string"},
            "algorithm": {"type": "string"}, "expected_hash": {"type": "string"},
            "is_active": {"type": "boolean"},
        },
    },
    "CodeSignatureCreate": {
        "type": "object", "required": ["system_id", "component_ref", "expected_hash"],
        "properties": {
            "system_id": {"type": "string"}, "component_ref": {"type": "string"},
            "expected_hash": {"type": "string"}, "algorithm": {"type": "string", "default": "sha256"},
            "registered_by": {"type": "string", "nullable": True},
        },
    },
    "IntegrityCheckResult": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "signature_id": {"type": "string", "nullable": True},
            "system_id": {"type": "string"}, "component_ref": {"type": "string"},
            "actual_hash": {"type": "string"},
            "result": {"type": "string", "enum": ["match", "mismatch", "no_baseline"]},
            "linked_security_incident_id": {"type": "string", "nullable": True},
        },
    },
    "IntegrityCheckCreate": {
        "type": "object", "required": ["system_id", "component_ref", "actual_hash"],
        "properties": {
            "system_id": {"type": "string"}, "component_ref": {"type": "string"},
            "actual_hash": {"type": "string"},
        },
    },
    "Connector": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "connector_key": {"type": "string"}, "display_name": {"type": "string"},
            "connector_type": {"type": "string",
                                "enum": ["system_integration", "sensor_feed", "c2_link", "vendor_gateway"]},
            "direction": {"type": "string", "enum": ["inbound", "outbound", "bidirectional"]},
            "target_system_id": {"type": "string", "nullable": True}, "is_active": {"type": "boolean"},
        },
    },
    "ConnectorCreate": {
        "type": "object", "required": ["connector_key", "display_name", "connector_type", "direction", "authorized_by"],
        "properties": {
            "connector_key": {"type": "string"}, "display_name": {"type": "string"},
            "connector_type": {"type": "string"}, "direction": {"type": "string"},
            "authorized_by": {"type": "string"}, "target_system_id": {"type": "string", "nullable": True},
            "capabilities_json": {"type": "object", "nullable": True},
            "version": {"type": "string", "default": "1.0"}, "auth_ref": {"type": "string", "nullable": True},
        },
    },
    "VendorGatewayConnector": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "connector_id": {"type": "string"}, "vendor_system_id": {"type": "string"},
            "data_direction": {"type": "string"},
            "exposed_fields": {"type": "array", "items": {"type": "string"}},
            "isolation_method": {"type": "string",
                                  "enum": ["one_way_webhook", "dmz_proxy", "signed_event_relay"]},
            "is_active": {"type": "boolean"},
        },
    },
    "VendorGatewayConnectorCreate": {
        "type": "object",
        "required": ["connector_id", "vendor_system_id", "data_direction", "exposed_fields", "isolation_method"],
        "properties": {
            "connector_id": {"type": "string"}, "vendor_system_id": {"type": "string"},
            "data_direction": {"type": "string",
                                "enum": ["guardian_reads_from_vendor", "guardian_pushes_alerts_to_vendor"]},
            "exposed_fields": {"type": "array", "items": {"type": "string"},
                                "description": "Non-empty explicit allowlist — required"},
            "isolation_method": {"type": "string",
                                  "description": "'direct_db_link' is rejected — vendors never get direct DB access"},
            "never_exposes_internal_ref": {"type": "array", "items": {"type": "string"}, "nullable": True},
        },
    },
    "Sensor": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "sensor_key": {"type": "string"}, "sensor_type": {"type": "string"},
            "system_id": {"type": "string"}, "connector_id": {"type": "string", "nullable": True},
            "is_active": {"type": "boolean"},
        },
    },
    "SensorCreate": {
        "type": "object", "required": ["sensor_key", "sensor_type", "system_id"],
        "properties": {
            "sensor_key": {"type": "string"}, "sensor_type": {"type": "string"},
            "system_id": {"type": "string"}, "connector_id": {"type": "string", "nullable": True},
            "capabilities_json": {"type": "object", "nullable": True},
        },
    },
    "SensorEventCreate": {
        "type": "object", "required": ["sensor_id", "event_type"],
        "properties": {
            "sensor_id": {"type": "string"}, "event_type": {"type": "string"},
            "severity": {"type": "string", "default": "info"},
            "payload_json": {"type": "object", "nullable": True},
        },
    },
    "SensorEventResult": {
        "type": "object",
        "properties": {
            "accepted": {"type": "boolean"},
            "reason": {"type": "string", "nullable": True, "description": "'rate_limited' if throttled"},
            "event_id": {"type": "string", "nullable": True},
        },
    },
    "SensorEvent": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "sensor_id": {"type": "string"}, "event_type": {"type": "string"},
            "severity": {"type": "string"}, "payload_json": {"type": "object"},
            "occurred_at": {"type": "string", "format": "date-time"},
        },
    },
    "C2Integration": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "connector_id": {"type": "string"}, "c2_system_name": {"type": "string"},
            "role": {"type": "string"}, "data_scope": {"type": "array", "items": {"type": "string"}},
            "accepts_directives": {"type": "boolean"}, "is_active": {"type": "boolean"},
        },
    },
    "C2IntegrationCreate": {
        "type": "object", "required": ["connector_id", "c2_system_name", "data_scope"],
        "properties": {
            "connector_id": {"type": "string"},
            "c2_system_name": {"type": "string", "description": "e.g. 'sensor_fusion', 'sensory_nerve_servers'"},
            "data_scope": {"type": "array", "items": {"type": "string"}},
            "role": {"type": "string", "default": "upstream_command"},
            "accepts_directives": {"type": "boolean", "default": False,
                "description": "Governs whether directives are LISTENED to — a directive is still ALWAYS "
                                "converted to a normal fix proposal, never auto-applied unilaterally"},
        },
    },
    "C2Publish": {
        "type": "object", "required": ["payload_summary"],
        "properties": {
            "payload_summary": {"type": "string"},
            "reference_table": {"type": "string", "nullable": True},
            "reference_id": {"type": "string", "nullable": True},
        },
    },
    "C2Directive": {
        "type": "object",
        "required": ["finding_id", "system_id", "proposed_action", "category", "risk_level"],
        "properties": {
            "finding_id": {"type": "string"}, "system_id": {"type": "string"},
            "proposed_action": {"type": "string"}, "change_json": {"type": "object"},
            "category": {"type": "string"}, "risk_level": {"type": "string"},
        },
    },
    "C2SyncLogEntry": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "c2_integration_id": {"type": "string"},
            "direction": {"type": "string", "enum": ["published", "received"]},
            "payload_summary": {"type": "string"}, "occurred_at": {"type": "string", "format": "date-time"},
        },
    },
    "SystemHealthScore": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "system_id": {"type": "string"}, "score": {"type": "number"},
            "open_findings_weight": {"type": "number"}, "security_weight": {"type": "number"},
            "computed_at": {"type": "string", "format": "date-time"},
        },
    },
    "EcosystemRiskScore": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "score": {"type": "number"}, "systems_included": {"type": "integer"},
            "contributing_factors_json": {"type": "array", "items": {"type": "object"}},
            "computed_at": {"type": "string", "format": "date-time"},
        },
    },
    "RateLimitCreate": {
        "type": "object", "required": ["max_events_per_minute"],
        "properties": {
            "max_events_per_minute": {"type": "integer", "minimum": 1},
            "system_id": {"type": "string", "nullable": True},
            "sensor_id": {"type": "string", "nullable": True},
        },
    },
    "RateLimitStatus": {
        "type": "object",
        "properties": {
            "id": {"type": "string"}, "system_id": {"type": "string", "nullable": True},
            "sensor_id": {"type": "string", "nullable": True},
            "max_events_per_minute": {"type": "integer"}, "current_window_count": {"type": "integer"},
            "is_throttled": {"type": "boolean"},
        },
    },
}
SCHEMA_REF = {name: f"#/components/schemas/{name}" for name in SCHEMAS}

# ---------------------------------------------------------------
# Paths
# ---------------------------------------------------------------

PATHS = {
    "/health": {"get": {"summary": "Liveness check (no auth required)", "tags": ["meta"],
                         "responses": {"200": {"description": "OK"}}}},

    "/systems": {
        "post": op("Register a monitored system", "systems", ok(SCHEMA_REF["System"]), SCHEMA_REF["SystemCreate"]),
        "get": op("List systems", "systems", ok(SCHEMA_REF["System"], is_array=True)),
    },
    "/systems/{system_id}": {
        "get": op("Get a system", "systems", ok(SCHEMA_REF["System"]),
                   params=[path_param("system_id")]),
    },
    "/checks": {
        "post": op("Register a monitoring check", "checks", ok(SCHEMA_REF["Check"]), SCHEMA_REF["CheckCreate"]),
        "get": op("List checks", "checks", ok(SCHEMA_REF["Check"], is_array=True)),
    },
    "/findings": {
        "post": op("Record a finding", "findings", ok(SCHEMA_REF["Finding"]), SCHEMA_REF["FindingCreate"]),
        "get": op("List findings", "findings", ok(SCHEMA_REF["Finding"], is_array=True),
                  params=[query_param("status")]),
    },
    "/findings/{finding_id}/resolve": {
        "post": op("Resolve a finding", "findings", ok(SCHEMA_REF["Finding"]), SCHEMA_REF["FindingResolve"],
                    params=[path_param("finding_id")]),
    },
    "/fix-proposals": {
        "post": op("Propose a fix (may auto-apply per safety rules)", "fix-proposals",
                    ok(SCHEMA_REF["FixProposal"]), SCHEMA_REF["FixProposalCreate"]),
        "get": op("List fix proposals", "fix-proposals", ok(SCHEMA_REF["FixProposal"], is_array=True),
                  params=[query_param("status")]),
    },
    "/fix-proposals/{proposal_id}/approve": {
        "post": op("Approve a pending fix proposal", "fix-proposals", ok(SCHEMA_REF["FixProposal"]),
                    params=[path_param("proposal_id")], needs_admin_key=True),
    },
    "/fix-proposals/{proposal_id}/apply": {
        "post": op("Apply an approved fix proposal", "fix-proposals", ok(SCHEMA_REF["FixProposal"]),
                    params=[path_param("proposal_id")]),
    },
    "/fix-proposals/{proposal_id}/reject": {
        "post": op("Reject a pending fix proposal", "fix-proposals", ok(SCHEMA_REF["FixProposal"]),
                    SCHEMA_REF["FixProposalReject"], params=[path_param("proposal_id")], needs_admin_key=True),
    },
    "/admins": {
        "post": op("Register an admin identity (returns a raw API key once)", "admins",
                    ok(SCHEMA_REF["Admin"]), SCHEMA_REF["AdminCreate"]),
        "get": op("List admins (never includes API keys)", "admins", ok(SCHEMA_REF["Admin"], is_array=True)),
    },
    "/admins/{identity_ref}/revoke": {
        "post": op("Revoke an admin's access (super_admin only)", "admins", ok(SCHEMA_REF["Admin"]),
                    params=[path_param("identity_ref")], needs_admin_key=True),
    },
    "/action-log": {
        "get": op("Full audit trail", "action-log", ok(SCHEMA_REF["ActionLogEntry"], is_array=True),
                  params=[query_param("system_id")]),
    },
    "/security-incidents": {
        "post": op("Log a security incident (validates auto_response)", "security",
                    ok(SCHEMA_REF["SecurityIncident"]), SCHEMA_REF["SecurityIncidentCreate"]),
        "get": op("List security incidents", "security", ok(SCHEMA_REF["SecurityIncident"], is_array=True),
                  params=[query_param("status")]),
    },
    "/security-incidents/{incident_id}/resolve": {
        "post": op("Resolve a security incident", "security", ok(SCHEMA_REF["SecurityIncident"]),
                    params=[path_param("incident_id")]),
    },
    "/escalation-policies": {
        "post": op("Define an escalation chain for a severity", "escalation",
                    ok(SCHEMA_REF["EscalationPolicy"]), SCHEMA_REF["EscalationPolicyCreate"]),
        "get": op("List escalation policies", "escalation", ok(SCHEMA_REF["EscalationPolicy"], is_array=True)),
    },
    "/escalation-events": {
        "get": op("List escalation events", "escalation", ok(SCHEMA_REF["EscalationEvent"], is_array=True),
                  params=[query_param("status")]),
    },
    "/escalation-events/{event_id}/acknowledge": {
        "post": op("Acknowledge an escalation (notified admin or super_admin)", "escalation",
                    ok(SCHEMA_REF["EscalationEvent"]), params=[path_param("event_id")], needs_admin_key=True),
    },
    "/process-escalations": {
        "post": op("Advance timed-out escalations (run on a schedule)", "escalation",
                    {"200": {"description": "OK"}}),
    },
    "/audio-streams": {
        "post": op("Register an audio stream (auto-creates channels)", "audio",
                    ok(SCHEMA_REF["AudioStream"]), SCHEMA_REF["AudioStreamCreate"]),
        "get": op("List audio streams", "audio", ok(SCHEMA_REF["AudioStream"], is_array=True),
                  params=[query_param("system_id")]),
    },
    "/audio-streams/{stream_id}/end": {
        "post": op("Mark a stream ended", "audio", ok(SCHEMA_REF["AudioStream"]),
                    params=[path_param("stream_id")]),
    },
    "/audio-streams/{stream_id}/channels": {
        "get": op("List a stream's channels", "audio", ok(SCHEMA_REF["AudioChannel"], is_array=True),
                  params=[path_param("stream_id")]),
    },
    "/audio-channels/{channel_id}": {
        "post": op("Label a channel / link a speaker", "audio", ok(SCHEMA_REF["AudioChannel"]),
                    SCHEMA_REF["AudioChannelUpdate"], params=[path_param("channel_id")]),
    },
    "/audio-bands": {
        "post": op("Define a frequency band", "audio", ok(SCHEMA_REF["AudioBand"]), SCHEMA_REF["AudioBandCreate"]),
        "get": op("List frequency bands", "audio", ok(SCHEMA_REF["AudioBand"], is_array=True)),
    },
    "/audio-band-metrics": {
        "post": op("Record per-channel, per-band metrics", "audio", ok(SCHEMA_REF["AudioBandMetric"]),
                    SCHEMA_REF["AudioBandMetricCreate"]),
    },
    "/audio-channels/{channel_id}/metrics": {
        "get": op("List a channel's recorded metrics", "audio", ok(SCHEMA_REF["AudioBandMetric"], is_array=True),
                  params=[path_param("channel_id")]),
    },
    "/audio-findings": {
        "post": op("Record an audio finding (may auto-escalate)", "audio", ok(SCHEMA_REF["AudioFinding"]),
                    SCHEMA_REF["AudioFindingCreate"]),
        "get": op("List audio findings", "audio", ok(SCHEMA_REF["AudioFinding"], is_array=True),
                  params=[query_param("stream_id"), query_param("status")]),
    },
    "/audio-findings/{finding_id}/resolve": {
        "post": op("Resolve an audio finding (blocked if linked incident open)", "audio",
                    ok(SCHEMA_REF["AudioFinding"]), params=[path_param("finding_id")]),
    },
    "/code-signatures": {
        "post": op("Register/rotate a known-good hash for a component", "integrity",
                    ok(SCHEMA_REF["CodeSignature"]), SCHEMA_REF["CodeSignatureCreate"]),
        "get": op("List registered signatures", "integrity", ok(SCHEMA_REF["CodeSignature"], is_array=True),
                  params=[query_param("system_id"), query_param("component_ref")]),
    },
    "/integrity-checks": {
        "post": op("Verify a hash against the active baseline", "integrity",
                    ok(SCHEMA_REF["IntegrityCheckResult"]), SCHEMA_REF["IntegrityCheckCreate"]),
        "get": op("List the integrity check log", "integrity", ok(SCHEMA_REF["IntegrityCheckResult"], is_array=True),
                  params=[query_param("system_id"), query_param("component_ref"), query_param("result")]),
    },
    "/connectors": {
        "post": op("Register a connector (any type)", "connectors", ok(SCHEMA_REF["Connector"]),
                    SCHEMA_REF["ConnectorCreate"]),
        "get": op("List connectors", "connectors", ok(SCHEMA_REF["Connector"], is_array=True),
                  params=[query_param("connector_type")]),
    },
    "/vendor-gateway-connectors": {
        "post": op("Create an isolated vendor/contractor gateway", "vendor-gateway",
                    ok(SCHEMA_REF["VendorGatewayConnector"]), SCHEMA_REF["VendorGatewayConnectorCreate"]),
        "get": op("List vendor gateways", "vendor-gateway", ok(SCHEMA_REF["VendorGatewayConnector"], is_array=True),
                  params=[query_param("vendor_system_id")]),
    },
    "/sensors": {
        "post": op("Register a sensor (any type)", "sensors", ok(SCHEMA_REF["Sensor"]), SCHEMA_REF["SensorCreate"]),
        "get": op("List sensors", "sensors", ok(SCHEMA_REF["Sensor"], is_array=True),
                  params=[query_param("system_id"), query_param("sensor_type")]),
    },
    "/sensor-events": {
        "post": op("Record a sensor event (passes through the rate limiter)", "sensors",
                    ok(SCHEMA_REF["SensorEventResult"]), SCHEMA_REF["SensorEventCreate"]),
        "get": op("List sensor events", "sensors", ok(SCHEMA_REF["SensorEvent"], is_array=True),
                  params=[query_param("sensor_id")]),
    },
    "/c2-integrations": {
        "post": op("Register a Sensor Fusion / Sensory Nerve Server link", "c2",
                    ok(SCHEMA_REF["C2Integration"]), SCHEMA_REF["C2IntegrationCreate"]),
    },
    "/c2-integrations/{integration_id}/publish": {
        "post": op("Log data published upward to a C2 system", "c2", ok(SCHEMA_REF["C2SyncLogEntry"]),
                    SCHEMA_REF["C2Publish"], params=[path_param("integration_id")]),
    },
    "/c2-integrations/{integration_id}/directive": {
        "post": op("Receive a directive (always becomes a fix proposal, never auto-applied)", "c2",
                    ok(SCHEMA_REF["FixProposal"]), SCHEMA_REF["C2Directive"],
                    params=[path_param("integration_id")]),
    },
    "/c2-sync-log": {
        "get": op("Full publish/receive history with a C2 system", "c2",
                  ok(SCHEMA_REF["C2SyncLogEntry"], is_array=True), params=[query_param("integration_id")]),
    },
    "/systems/{system_id}/health-score": {
        "post": op("Compute and record a system's health score", "scoring", ok(SCHEMA_REF["SystemHealthScore"]),
                    params=[path_param("system_id")]),
    },
    "/systems/{system_id}/health-scores": {
        "get": op("Score history for a system", "scoring", ok(SCHEMA_REF["SystemHealthScore"], is_array=True),
                  params=[path_param("system_id")]),
    },
    "/ecosystem-risk-score": {
        "post": op("Compute and record the ecosystem-wide risk score", "scoring",
                    ok(SCHEMA_REF["EcosystemRiskScore"])),
    },
    "/ecosystem-risk-scores": {
        "get": op("Ecosystem risk score history", "scoring", ok(SCHEMA_REF["EcosystemRiskScore"], is_array=True)),
    },
    "/rate-limits": {
        "post": op("Configure a system- or sensor-scoped ingestion limit", "rate-limits",
                    ok(SCHEMA_REF["RateLimitStatus"]), SCHEMA_REF["RateLimitCreate"]),
    },
    "/rate-limits/status": {
        "get": op("Current throttle status for a scope", "rate-limits", ok(SCHEMA_REF["RateLimitStatus"]),
                  params=[query_param("system_id"), query_param("sensor_id")]),
    },
}

SPEC = {
    "openapi": "3.0.3",
    "info": {
        "title": "Guardian Core Engine API",
        "version": "1.0.0",
        "description": (
            "Ecosystem-wide monitoring, fix-approval, and defense API. "
            "Every endpoint except /health requires a service bearer token; "
            "approve/reject/acknowledge additionally require a per-admin API key "
            "(X-Admin-Api-Key) — see the security schemes below."
        ),
    },
    "servers": [{"url": "http://localhost:8000", "description": "Local/dev"}],
    "tags": [
        {"name": t} for t in [
            "meta", "systems", "checks", "findings", "fix-proposals", "admins", "action-log",
            "security", "escalation", "audio", "integrity", "connectors", "vendor-gateway",
            "sensors", "c2", "scoring", "rate-limits",
        ]
    ],
    "components": {
        "securitySchemes": {
            "ServiceApiKey": {
                "type": "http", "scheme": "bearer",
                "description": "GUARDIAN_API_KEY — required on every endpoint except /health",
            },
            "AdminApiKey": {
                "type": "apiKey", "in": "header", "name": "X-Admin-Api-Key",
                "description": "Per-admin key returned once at registration — required for "
                                "approve/reject/acknowledge/revoke",
            },
        },
        "schemas": SCHEMAS,
    },
    "security": [{"ServiceApiKey": []}],
    "paths": PATHS,
}


def main():
    out_path = os.path.join(os.path.dirname(__file__), "..", "openapi.yaml")
    with open(out_path, "w") as f:
        yaml.dump(SPEC, f, sort_keys=False, default_flow_style=False, width=100)
    print(f"Wrote {os.path.abspath(out_path)}")


if __name__ == "__main__":
    main()
