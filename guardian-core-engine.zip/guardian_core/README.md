# Guardian — Core Engine

The first slice of the Guardian ecosystem schema, built as real, tested
code: system registry, checks, findings, fix proposals, and the
human-approval workflow.

## Stack

Flask + Python's built-in `sqlite3` + `unittest`. This environment had
no internet access to install FastAPI/SQLAlchemy/pytest, so the stack
was adapted — the business logic in `app/services.py` is what matters
and is framework-independent; swap `app/main.py` and `app/db.py` for
FastAPI/SQLAlchemy later without touching the rules.

## Run it

```bash
pip install flask
python -m app.main        # serves on http://localhost:8000
```

## Run the tests

```bash
python -m unittest discover -s tests -v
```

104 tests, all passing (111 counting docs tests, 3 more skipped
unless a real Postgres is available — see below). They cover the
parts that actually matter:

- A fix only **auto-applies** when risk is low AND its category is
  explicitly permitted by the target system.
- `finance`, `payroll`, `benefits`, `compensation`, `tax`,
  `vault_secret`, `code_patch`, and `infrastructure` categories
  **always** require human approval — even at low risk, even if a
  system's config says it's permitted. This is tested for every one
  of those categories individually.
- Only an admin with role `approver`/`super_admin`, scoped to the
  target system (or scoped to all systems), can approve or reject.
- A proposal can't be applied before it's approved, approved twice,
  approved after rejection, or approved by an unknown/revoked admin.
- Every finding, fix, approval, and rejection writes an
  `guardian_action_log` row.

**Security incidents & escalation (new):**
- `auto_response` is restricted to reversible containment actions
  (`session_terminated`, `account_locked`, `mfa_forced`) — anything
  else (data deletion, permanent bans) is rejected outright.
- A `high`/`critical` incident automatically triggers every active
  escalation policy matching its severity (system-scoped or global),
  opening an escalation event notifying the first person in that
  policy's order.
- Only the currently-notified admin, or a `super_admin` (covering),
  may acknowledge an escalation.
- `process-escalations` (meant to run on a schedule) advances any
  unacknowledged event past its timeout window to the next person in
  line, and marks it `exhausted` once the list runs out — never loops.
- Acknowledged events are never touched by timeout processing.

**Audio monitoring (new):**
- Registering a stream auto-creates its declared channels; each
  channel can be labeled and linked to a speaker afterward.
- Band metrics (level, noise floor, clipping, silence ratio) are
  validated — ratios must be between 0 and 1.
- A `possible_unauthorized_capture` finding **always** creates a
  linked security incident automatically — no code path can dismiss
  it silently.
- An audio finding of that type **cannot be resolved** until its
  linked security incident is resolved first — the finding and the
  incident it triggered move together, not independently.

**Code integrity verification (new):**
- Register a known-good hash for a component; re-registering rotates
  it and deactivates the old baseline (for legitimate new releases).
- Verifying a hash returns `match`, `mismatch`, or `no_baseline` — a
  mismatch always creates a `critical` security incident automatically.
- Scope: hash comparison only. This deliberately does **not** include
  anti-debugging, control-flow obfuscation, environment attestation,
  or in-memory decrypt/wipe execution — those are analysis-evasion
  techniques indistinguishable in code from malware anti-analysis
  tooling, and out of scope for what Guardian builds. If you need
  binary-level anti-tamper for a shipped client app, that's a job for
  an audited commercial app-shielding SDK, not something bolted onto
  a monitoring system.

**Vendor/contractor gateway (new):**
- A vendor connection's `isolation_method` can never be
  `direct_db_link` — rejected at the API.
- `exposed_fields` must be a non-empty explicit allowlist.
- An admin can never be granted `system_scope` that includes a
  registered vendor system — protection flows toward vendors, access
  never flows in from them. A global admin (`system_scope: null`) is
  unaffected by this rule, since that's an internal-authority grant,
  not a vendor-side one.

**Sensor registry & ingestion (new):**
- Generic `sensor_type` support (badge readers, network, environmental,
  audio, etc.) through one registry and one event table.
- Every sensor event passes through the rate limiter first — a
  flooding sensor gets throttled (events rejected with
  `accepted: false`) rather than allowed to overwhelm Guardian.

**Command & control integration (new):**
- Publishing to a C2 system (Sensor Fusion, Sensory Nerve Servers) is
  logged in `c2-sync-log`.
- A directive received FROM a C2 system is rejected outright if that
  integration isn't configured to accept directives.
- Even when accepted, a directive is **never** auto-applied — it
  always becomes a normal fix proposal, subject to the exact same
  approval rules (including the always-requires-approval categories)
  as any other proposed fix. `accepts_directives` governs whether
  Guardian listens, never whether it acts unilaterally on what it
  hears.

**Health & risk scoring (new):**
- Per-system health score: starts at 100, each open finding costs 5
  points, each open security incident costs 15, floored at 0.
- Ecosystem risk score: average health deficit across all active
  systems — one trended number for the whole ecosystem, with a
  per-system breakdown for drill-down.
- Resolving findings/incidents restores the score on the next
  computation — nothing is permanently penalized.

**Ingestion rate limiting (new):**
- Sensor-scoped limits take priority over system-scoped ones.
- A rolling one-minute window; exceeding it throttles new events
  (not a hard error) and logs the spike as an action-log entry the
  first time a scope crosses into throttled state.

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/systems` | Register a monitored system |
| GET | `/systems` | List systems |
| POST | `/checks` | Register a monitoring check |
| POST | `/findings` | Record a finding |
| POST | `/findings/<id>/resolve` | Close out a finding |
| POST | `/fix-proposals` | Propose a fix (may auto-apply) |
| POST | `/fix-proposals/<id>/approve` | Approve a pending fix |
| POST | `/fix-proposals/<id>/apply` | Apply an approved fix |
| POST | `/fix-proposals/<id>/reject` | Reject a pending fix |
| POST | `/admins` | Register an admin identity |
| GET | `/action-log` | Full audit trail |
| POST | `/security-incidents` | Log a security incident (validates auto_response) |
| GET | `/security-incidents` | List incidents |
| POST | `/security-incidents/<id>/resolve` | Close an incident |
| POST | `/escalation-policies` | Define an escalation chain for a severity |
| GET | `/escalation-policies` | List policies |
| GET | `/escalation-events` | List active/acknowledged/exhausted escalations |
| POST | `/escalation-events/<id>/acknowledge` | Acknowledge (notified admin or super_admin) |
| POST | `/process-escalations` | Advance timed-out escalations (run on a schedule) |
| POST | `/audio-streams` | Register a stream (auto-creates channels) |
| GET | `/audio-streams` | List streams |
| POST | `/audio-streams/<id>/end` | Mark a stream ended |
| GET | `/audio-streams/<id>/channels` | List a stream's channels |
| POST | `/audio-channels/<id>` | Label a channel / link a speaker |
| POST | `/audio-bands` | Define a frequency band |
| POST | `/audio-band-metrics` | Record per-channel, per-band metrics |
| GET | `/audio-channels/<id>/metrics` | List a channel's recorded metrics |
| POST | `/audio-findings` | Record an audio finding (may auto-escalate) |
| POST | `/audio-findings/<id>/resolve` | Resolve (blocked if linked incident is still open) |
| POST | `/code-signatures` | Register/rotate a known-good hash for a component |
| GET | `/code-signatures` | List registered signatures |
| POST | `/integrity-checks` | Verify a hash against the active baseline |
| GET | `/integrity-checks` | List the check log |
| POST | `/connectors` | Register a connector (any type) |
| GET | `/connectors` | List connectors |
| POST | `/vendor-gateway-connectors` | Create an isolated vendor/contractor gateway |
| GET | `/vendor-gateway-connectors` | List vendor gateways |
| POST | `/sensors` | Register a sensor (any type) |
| GET | `/sensors` | List sensors |
| POST | `/sensor-events` | Record a sensor event (rate-limited) |
| GET | `/sensor-events` | List sensor events |
| POST | `/c2-integrations` | Register a Sensor Fusion / Sensory Nerve Server link |
| POST | `/c2-integrations/<id>/publish` | Log data published upward to a C2 system |
| POST | `/c2-integrations/<id>/directive` | Receive a directive (always becomes a fix proposal) |
| GET | `/c2-sync-log` | Full publish/receive history with a C2 system |
| POST | `/systems/<id>/health-score` | Compute and record a system's health score |
| GET | `/systems/<id>/health-scores` | Score history for a system |
| POST | `/ecosystem-risk-score` | Compute and record the ecosystem-wide risk score |
| GET | `/ecosystem-risk-scores` | Ecosystem risk score history |
| POST | `/rate-limits` | Configure a system- or sensor-scoped ingestion limit |
| GET | `/rate-limits/status` | Current throttle status for a scope |

## Status

Every module from `guardian-ecosystem-schema.sql` now has real, tested
code: core engine, security incidents & escalation, audio monitoring,
code integrity verification, vendor gateway, sensor registry, C2
integration, and health/risk scoring. 104 tests, all passing.

Not built (by design, declined on request — see conversation):
anti-debugging, control-flow obfuscation, string/data encryption,
environment attestation, and other analysis-evasion techniques. The
build-tool project (`guardian-buildtool`) covers the legitimate subset
of that space: local-variable renaming and metadata stripping.

## Authentication

**Service-level:** every endpoint except `/health` requires
`Authorization: Bearer <GUARDIAN_API_KEY>`. In production
(`GUARDIAN_ENV=production`) the app refuses to start if
`GUARDIAN_API_KEY` isn't set. Outside production, an ephemeral key is
auto-generated and printed to stderr — convenient for local dev, never
for anything real.

**Per-admin:** registering an admin (`POST /admins`) returns a raw API
key (`gdn_...`) **once** — it's never retrievable again, only a hash
is stored. `approve`, `reject`, and `acknowledge` require
`X-Admin-Api-Key` matching that admin's key; the identity is resolved
from the key, never trusted from a request body field. This closes a
real gap the earlier design had — before this, anyone could type any
admin's email into a JSON body and act as them. `POST
/admins/<identity_ref>/revoke` (requires a `super_admin`'s key)
invalidates a compromised or departing admin's key immediately.

## Deployment

`Dockerfile` runs as a non-root user behind gunicorn (not Flask's dev
server), with a healthcheck against `/health`. `docker-compose.yml`
wires up a persistent volume for the SQLite file and requires
`GUARDIAN_API_KEY` to be set before it will start. See `.env.example`
for the full list of configuration variables.

```bash
cp .env.example .env   # fill in a real GUARDIAN_API_KEY
docker compose up --build
```

The SQLite file needs a persistent volume in any real deployment —
the container filesystem is ephemeral. For serious concurrent load,
swap `app/db.py` for a real connection pool against Postgres; the
service layer (`app/services.py`) doesn't change.

## Integration test

`tests/test_integration_lifecycle.py` is different from the other
test files — instead of testing one module's rules in isolation, it
walks one coherent incident end to end (system registration → findings
→ auto-applied and human-approved fixes → security incident →
escalation with a real timeout hand-off → acknowledgment → an
integrity-check-triggered incident → a vendor gateway → rate-limited
sensor events → health/risk scoring → a coherent action-log trail).
This is where a cross-module wiring bug would show up that per-module
tests can't catch alone — and it did: escalation acknowledge/advance/
exhaust log entries were writing `system_id=None`, silently breaking
per-system action-log filtering. Fixed as part of this pass.

## Postgres backend

SQLite is the default; set `GUARDIAN_DATABASE_URL` (or `DATABASE_URL`)
to a `postgres://` or `postgresql://` URL to use Postgres instead —
`app/db.py` picks the backend automatically. Install the extra
dependency first:

```bash
pip install -r requirements.txt -r requirements-postgres.txt
```

**Honesty about what's verified where:** this was built in a sandbox
with no internet access (couldn't install psycopg2) and no Postgres
server available, so the adapter code could not be executed here —
only reasoned through carefully (ANSI-portable SQL throughout,
placeholder translation, RealDictCursor row compatibility, and
rollback-on-error so one failed query doesn't poison a connection
reused across many requests). `tests/test_postgres_backend.py` is
written to actually prove it works, but self-skips unless psycopg2 is
installed AND `GUARDIAN_TEST_POSTGRES_URL` points at a real, reachable
Postgres instance — it runs for real in CI (see below), and locally
if you have Postgres available:

```bash
docker run -d -e POSTGRES_PASSWORD=guardian -e POSTGRES_USER=guardian \
    -e POSTGRES_DB=guardian_test -p 5432:5432 postgres:16
export GUARDIAN_TEST_POSTGRES_URL=postgresql://guardian:guardian@localhost:5432/guardian_test
pip install psycopg2-binary
python -m unittest tests.test_postgres_backend -v
```

## API docs

`GET /docs` serves a Swagger UI page (both this and `/openapi.yaml`
are the only routes that don't require the service API key, so the
docs are easy to share). `GET /openapi.yaml` serves the raw spec —
all 60 operations, generated from `scripts/generate_openapi.py`
rather than hand-typed, so it can't silently drift from the endpoint
list. Regenerate after adding or changing any endpoint:

```bash
python scripts/generate_openapi.py
```

CI checks that the committed `openapi.yaml` matches what the generator
produces, and fails the build if someone changes an endpoint without
regenerating it.

Note: `/docs` loads Swagger UI from a CDN, so the *browser* viewing it
needs internet access (the server itself doesn't). Self-host
`swagger-ui-dist` instead if this needs to work fully air-gapped.

## CI

`.github/workflows/ci.yml` runs on every push/PR:
- The full test suite on Python 3.11 and 3.12, **against a real
  Postgres service container** — so `test_postgres_backend.py` isn't
  just skipped in CI the way it is in this sandbox; a job step
  explicitly fails the build if it ever is skipped there.
- Regenerates `openapi.yaml` and diffs it against the committed
  version, failing if they don't match.
- Builds the Docker image and smoke-tests `/health` against a running
  container.
