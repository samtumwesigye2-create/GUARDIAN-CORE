"""
Core Guardian business logic — the safety principles from the design
doc, enforced here in code rather than only documented in comments:

1. Finance/payroll/benefits/comp/tax/vault/code/infra fixes ALWAYS
   require human approval, regardless of risk_level.
2. A fix can only auto-apply if risk_level == 'low' AND its category
   is in the target system's permitted_categories AND it's not on the
   always-requires-approval list.
3. Only an admin with role 'approver' or 'super_admin', scoped to the
   target system (or system_scope = None, meaning all systems), may
   approve or reject a fix.
4. Every state-changing action writes a guardian_action_log row.
"""

import hashlib
import json
import secrets
import sqlite3
import uuid
from datetime import datetime, timezone

ALWAYS_REQUIRES_APPROVAL_CATEGORIES = {
    "finance", "payroll", "benefits", "compensation",
    "tax", "vault_secret", "code_patch", "infrastructure",
}


class GuardianError(Exception):
    pass


class NotFoundError(GuardianError):
    pass


class ForbiddenError(GuardianError):
    pass


class InvalidStateError(GuardianError):
    pass


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _uid() -> str:
    return str(uuid.uuid4())


def _row_to_dict(row: sqlite3.Row) -> dict:
    return {k: row[k] for k in row.keys()}


def _log_action(conn, *, system_id, action_type, reference_table, reference_id, detail=None):
    conn.execute(
        """INSERT INTO guardian_action_log
           (id, system_id, action_type, reference_table, reference_id, detail_json, occurred_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (_uid(), system_id, action_type, reference_table, reference_id,
         json.dumps(detail or {}), _now()),
    )


# ---------- Systems ----------

def register_system(conn, *, system_key, display_name, category,
                     criticality="medium", trust_level="standard",
                     permitted_categories=None, connection_type="api_poll"):
    existing = conn.execute(
        "SELECT id FROM guardian_system_registry WHERE system_key = ?", (system_key,)
    ).fetchone()
    if existing:
        raise InvalidStateError(f"system_key '{system_key}' already registered")

    system_id = _uid()
    conn.execute(
        """INSERT INTO guardian_system_registry
           (id, system_key, display_name, category, criticality, trust_level,
            permitted_categories, connection_type, is_active, onboarded_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)""",
        (system_id, system_key, display_name, category, criticality, trust_level,
         json.dumps(permitted_categories or []), connection_type, _now()),
    )
    conn.commit()
    return get_system(conn, system_id)


def get_system(conn, system_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_system_registry WHERE id = ?", (system_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("system not found")
    d = _row_to_dict(row)
    d["permitted_categories"] = json.loads(d["permitted_categories"])
    d["is_active"] = bool(d["is_active"])
    return d


def list_systems(conn) -> list:
    rows = conn.execute("SELECT * FROM guardian_system_registry").fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["permitted_categories"] = json.loads(d["permitted_categories"])
        d["is_active"] = bool(d["is_active"])
        out.append(d)
    return out


# ---------- Checks ----------

def create_check(conn, *, name, category, check_logic_ref, scope="single_system",
                  system_id=None, target_module=None, run_frequency="hourly",
                  severity_default="medium", auto_fix_allowed=False):
    if scope == "single_system" and not system_id:
        raise InvalidStateError("single_system checks require a system_id")
    if system_id:
        get_system(conn, system_id)  # raises NotFoundError if missing

    check_id = _uid()
    conn.execute(
        """INSERT INTO guardian_checks
           (id, name, category, scope, system_id, target_module, check_logic_ref,
            run_frequency, severity_default, is_active, auto_fix_allowed)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)""",
        (check_id, name, category, scope, system_id, target_module, check_logic_ref,
         run_frequency, severity_default, int(auto_fix_allowed)),
    )
    conn.commit()
    return get_check(conn, check_id)


def get_check(conn, check_id) -> dict:
    row = conn.execute("SELECT * FROM guardian_checks WHERE id = ?", (check_id,)).fetchone()
    if not row:
        raise NotFoundError("check not found")
    d = _row_to_dict(row)
    d["is_active"] = bool(d["is_active"])
    d["auto_fix_allowed"] = bool(d["auto_fix_allowed"])
    return d


def list_checks(conn) -> list:
    rows = conn.execute("SELECT * FROM guardian_checks").fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["is_active"] = bool(d["is_active"])
        d["auto_fix_allowed"] = bool(d["auto_fix_allowed"])
        out.append(d)
    return out


# ---------- Findings ----------

def create_finding(conn, *, check_id, entity_type, severity, summary,
                    system_id=None, entity_id=None, evidence_json=None):
    check = get_check(conn, check_id)
    resolved_system_id = system_id or check["system_id"]

    finding_id = _uid()
    conn.execute(
        """INSERT INTO guardian_findings
           (id, check_id, system_id, entity_type, entity_id, severity, summary,
            evidence_json, status, detected_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)""",
        (finding_id, check_id, resolved_system_id, entity_type, entity_id, severity,
         summary, json.dumps(evidence_json or {}), _now()),
    )
    _log_action(conn, system_id=resolved_system_id, action_type="finding_created",
                reference_table="guardian_findings", reference_id=finding_id,
                detail={"severity": severity, "summary": summary})
    conn.commit()
    return get_finding(conn, finding_id)


def get_finding(conn, finding_id) -> dict:
    row = conn.execute("SELECT * FROM guardian_findings WHERE id = ?", (finding_id,)).fetchone()
    if not row:
        raise NotFoundError("finding not found")
    return _row_to_dict(row)


def list_findings(conn, status=None) -> list:
    if status:
        rows = conn.execute(
            "SELECT * FROM guardian_findings WHERE status = ?", (status,)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM guardian_findings").fetchall()
    return [_row_to_dict(r) for r in rows]


def resolve_finding(conn, finding_id, *, resolved_by, status="fixed"):
    finding = get_finding(conn, finding_id)
    if finding["status"] not in ("open", "acknowledged"):
        raise InvalidStateError(f"cannot resolve a finding in status '{finding['status']}'")

    conn.execute(
        "UPDATE guardian_findings SET status = ?, resolved_at = ?, resolved_by = ? WHERE id = ?",
        (status, _now(), resolved_by, finding_id),
    )
    _log_action(conn, system_id=finding["system_id"], action_type="finding_resolved",
                reference_table="guardian_findings", reference_id=finding_id,
                detail={"status": status, "resolved_by": resolved_by})
    conn.commit()
    return get_finding(conn, finding_id)


# ---------- Fix proposals ----------

def _requires_approval(system: dict, category: str, risk_level: str) -> bool:
    if category in ALWAYS_REQUIRES_APPROVAL_CATEGORIES:
        return True
    if risk_level != "low":
        return True
    if category not in (system["permitted_categories"] or []):
        return True
    return False


def create_fix_proposal(conn, *, finding_id, system_id, proposed_action,
                         change_json, category, risk_level):
    get_finding(conn, finding_id)  # existence check
    system = get_system(conn, system_id)  # existence check + data for rule evaluation

    requires_approval = _requires_approval(system, category, risk_level)
    proposal_id = _uid()
    now = _now()

    if requires_approval:
        conn.execute(
            """INSERT INTO guardian_fix_proposals
               (id, finding_id, system_id, proposed_action, change_json, category,
                risk_level, requires_approval, auto_applied, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, 'pending')""",
            (proposal_id, finding_id, system_id, proposed_action,
             json.dumps(change_json), category, risk_level),
        )
        _log_action(conn, system_id=system_id, action_type="fix_proposal_created",
                    reference_table="guardian_fix_proposals", reference_id=proposal_id,
                    detail={"category": category, "risk_level": risk_level,
                            "requires_approval": True})
    else:
        conn.execute(
            """INSERT INTO guardian_fix_proposals
               (id, finding_id, system_id, proposed_action, change_json, category,
                risk_level, requires_approval, auto_applied, applied_at, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, 0, 1, ?, 'applied')""",
            (proposal_id, finding_id, system_id, proposed_action,
             json.dumps(change_json), category, risk_level, now),
        )
        _log_action(conn, system_id=system_id, action_type="fix_auto_applied",
                    reference_table="guardian_fix_proposals", reference_id=proposal_id,
                    detail={"category": category, "risk_level": risk_level})

    conn.commit()
    return get_fix_proposal(conn, proposal_id)


def get_fix_proposal(conn, proposal_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_fix_proposals WHERE id = ?", (proposal_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("fix proposal not found")
    d = _row_to_dict(row)
    d["requires_approval"] = bool(d["requires_approval"])
    d["auto_applied"] = bool(d["auto_applied"])
    return d


def list_fix_proposals(conn, status=None) -> list:
    if status:
        rows = conn.execute(
            "SELECT * FROM guardian_fix_proposals WHERE status = ?", (status,)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM guardian_fix_proposals").fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["requires_approval"] = bool(d["requires_approval"])
        d["auto_applied"] = bool(d["auto_applied"])
        out.append(d)
    return out


def _hash_api_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


def _generate_api_key() -> str:
    return "gdn_" + secrets.token_urlsafe(32)


def _get_active_admin(conn, identity_ref) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_admins WHERE identity_ref = ?", (identity_ref,)
    ).fetchone()
    if not row or row["revoked_at"] is not None:
        raise ForbiddenError("unknown or revoked admin identity")
    d = _row_to_dict(row)
    d.pop("api_key_hash", None)
    d["system_scope"] = json.loads(d["system_scope"]) if d["system_scope"] else None
    return d


def get_admin_by_api_key(conn, raw_api_key: str) -> dict:
    """Resolves an admin from a presented raw API key. This is the
    ONLY legitimate way to establish 'I am admin X' — never trust an
    identity_ref supplied directly in a request body, since anyone
    could type any email address there."""
    key_hash = _hash_api_key(raw_api_key)
    row = conn.execute(
        "SELECT * FROM guardian_admins WHERE api_key_hash = ?", (key_hash,)
    ).fetchone()
    if not row or row["revoked_at"] is not None:
        raise ForbiddenError("invalid or revoked API key")
    d = _row_to_dict(row)
    d.pop("api_key_hash", None)
    d["system_scope"] = json.loads(d["system_scope"]) if d["system_scope"] else None
    return d


def revoke_admin(conn, identity_ref):
    admin = _get_active_admin(conn, identity_ref)
    conn.execute(
        "UPDATE guardian_admins SET revoked_at = ? WHERE identity_ref = ?",
        (_now(), identity_ref),
    )
    _log_action(conn, system_id=None, action_type="admin_revoked",
                reference_table="guardian_admins", reference_id=admin["id"], detail={})
    conn.commit()
    return _get_active_admin_including_revoked(conn, identity_ref)


def _get_active_admin_including_revoked(conn, identity_ref) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_admins WHERE identity_ref = ?", (identity_ref,)
    ).fetchone()
    d = _row_to_dict(row)
    d.pop("api_key_hash", None)
    d["system_scope"] = json.loads(d["system_scope"]) if d["system_scope"] else None
    return d


def _admin_can_act_on_system(admin: dict, system_id: str) -> bool:
    if admin["role"] not in ("approver", "super_admin"):
        return False
    if admin["system_scope"] is None:
        return True
    return system_id in admin["system_scope"]


def approve_fix_proposal(conn, proposal_id, *, admin_identity_ref):
    proposal = get_fix_proposal(conn, proposal_id)
    if proposal["status"] != "pending":
        raise InvalidStateError(f"cannot approve a proposal in status '{proposal['status']}'")
    if not proposal["requires_approval"]:
        raise InvalidStateError("this proposal did not require approval (already auto-applied)")

    admin = _get_active_admin(conn, admin_identity_ref)
    if not _admin_can_act_on_system(admin, proposal["system_id"]):
        raise ForbiddenError("admin is not authorized to approve fixes for this system")

    conn.execute(
        "UPDATE guardian_fix_proposals SET status = 'approved', approved_by = ?, approved_at = ? WHERE id = ?",
        (admin["identity_ref"], _now(), proposal_id),
    )
    _log_action(conn, system_id=proposal["system_id"], action_type="fix_approved",
                reference_table="guardian_fix_proposals", reference_id=proposal_id,
                detail={"approved_by": admin["identity_ref"]})
    conn.commit()
    return get_fix_proposal(conn, proposal_id)


def apply_fix_proposal(conn, proposal_id):
    proposal = get_fix_proposal(conn, proposal_id)
    if proposal["status"] != "approved":
        raise InvalidStateError(
            f"cannot apply a proposal in status '{proposal['status']}' — must be 'approved' first"
        )
    conn.execute(
        "UPDATE guardian_fix_proposals SET status = 'applied', applied_at = ? WHERE id = ?",
        (_now(), proposal_id),
    )
    _log_action(conn, system_id=proposal["system_id"], action_type="fix_applied",
                reference_table="guardian_fix_proposals", reference_id=proposal_id, detail={})
    conn.commit()
    return get_fix_proposal(conn, proposal_id)


def reject_fix_proposal(conn, proposal_id, *, admin_identity_ref, reason=None):
    proposal = get_fix_proposal(conn, proposal_id)
    if proposal["status"] != "pending":
        raise InvalidStateError(f"cannot reject a proposal in status '{proposal['status']}'")

    admin = _get_active_admin(conn, admin_identity_ref)
    if not _admin_can_act_on_system(admin, proposal["system_id"]):
        raise ForbiddenError("admin is not authorized to reject fixes for this system")

    conn.execute("UPDATE guardian_fix_proposals SET status = 'rejected' WHERE id = ?", (proposal_id,))
    _log_action(conn, system_id=proposal["system_id"], action_type="fix_rejected",
                reference_table="guardian_fix_proposals", reference_id=proposal_id,
                detail={"rejected_by": admin["identity_ref"], "reason": reason})
    conn.commit()
    return get_fix_proposal(conn, proposal_id)


# ---------- Admins ----------

def register_admin(conn, *, identity_ref, role="viewer", system_scope=None):
    existing = conn.execute(
        "SELECT id FROM guardian_admins WHERE identity_ref = ?", (identity_ref,)
    ).fetchone()
    if existing:
        raise InvalidStateError("admin already registered")
    admin_id = _uid()
    raw_key = _generate_api_key()
    conn.execute(
        """INSERT INTO guardian_admins (id, identity_ref, role, system_scope, api_key_hash, added_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (admin_id, identity_ref, role,
         json.dumps(system_scope) if system_scope is not None else None,
         _hash_api_key(raw_key), _now()),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM guardian_admins WHERE id = ?", (admin_id,)).fetchone()
    d = _row_to_dict(row)
    d.pop("api_key_hash", None)
    d["system_scope"] = json.loads(d["system_scope"]) if d["system_scope"] else None
    # The raw key is returned ONLY here, at creation time. It cannot be
    # retrieved again — losing it means re-issuing (revoke + re-register).
    d["api_key"] = raw_key
    return d


def list_admins(conn) -> list:
    rows = conn.execute("SELECT * FROM guardian_admins").fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d.pop("api_key_hash", None)  # never expose, not even the hash
        d["system_scope"] = json.loads(d["system_scope"]) if d["system_scope"] else None
        out.append(d)
    return out


# ---------- Action log ----------

def list_action_log(conn, system_id=None) -> list:
    if system_id:
        rows = conn.execute(
            "SELECT * FROM guardian_action_log WHERE system_id = ? ORDER BY occurred_at DESC",
            (system_id,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM guardian_action_log ORDER BY occurred_at DESC"
        ).fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["detail_json"] = json.loads(d["detail_json"]) if d["detail_json"] else {}
        out.append(d)
    return out


# ---------- Security incidents ----------

# Auto-response is limited to reversible containment actions — never
# data deletion, never permanent bans (safety principle, enforced here
# not just documented).
ALLOWED_AUTO_RESPONSES = {"session_terminated", "account_locked", "mfa_forced", None}


def create_security_incident(conn, *, incident_type, severity, system_id=None,
                              actor_ref=None, source_ip=None, auto_response=None,
                              evidence_json=None):
    if auto_response not in ALLOWED_AUTO_RESPONSES:
        raise InvalidStateError(
            f"auto_response '{auto_response}' is not an allowed reversible containment action"
        )
    if system_id:
        get_system(conn, system_id)  # existence check

    incident_id = _uid()
    conn.execute(
        """INSERT INTO guardian_security_incidents
           (id, system_id, incident_type, actor_ref, source_ip, severity,
            auto_response, evidence_json, status, detected_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)""",
        (incident_id, system_id, incident_type, actor_ref, source_ip, severity,
         auto_response, json.dumps(evidence_json or {}), _now()),
    )
    _log_action(conn, system_id=system_id, action_type="security_incident_created",
                reference_table="guardian_security_incidents", reference_id=incident_id,
                detail={"incident_type": incident_type, "severity": severity,
                        "auto_response": auto_response})
    conn.commit()

    incident = get_security_incident(conn, incident_id)

    # High/critical incidents trigger escalation under any matching
    # active policy (system-scoped or global).
    if severity in ("high", "critical"):
        _trigger_escalations(conn, severity=severity, system_id=system_id,
                              security_incident_id=incident_id)

    return incident


def get_security_incident(conn, incident_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_security_incidents WHERE id = ?", (incident_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("security incident not found")
    return _row_to_dict(row)


def list_security_incidents(conn, status=None) -> list:
    if status:
        rows = conn.execute(
            "SELECT * FROM guardian_security_incidents WHERE status = ?", (status,)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM guardian_security_incidents").fetchall()
    return [_row_to_dict(r) for r in rows]


def resolve_security_incident(conn, incident_id, *, resolved_by=None):
    incident = get_security_incident(conn, incident_id)
    if incident["status"] == "resolved":
        raise InvalidStateError("incident already resolved")
    conn.execute(
        "UPDATE guardian_security_incidents SET status = 'resolved', resolved_at = ? WHERE id = ?",
        (_now(), incident_id),
    )
    _log_action(conn, system_id=incident["system_id"], action_type="security_incident_resolved",
                reference_table="guardian_security_incidents", reference_id=incident_id,
                detail={"resolved_by": resolved_by})
    conn.commit()
    return get_security_incident(conn, incident_id)


# ---------- Escalation policies & events ----------

def create_escalation_policy(conn, *, name, applies_to_severity, escalation_order,
                              system_id=None, step_timeout_minutes=30):
    if not escalation_order:
        raise InvalidStateError("escalation_order must have at least one admin identity_ref")
    if system_id:
        get_system(conn, system_id)

    policy_id = _uid()
    conn.execute(
        """INSERT INTO guardian_escalation_policies
           (id, name, applies_to_severity, system_id, escalation_order,
            step_timeout_minutes, is_active)
           VALUES (?, ?, ?, ?, ?, ?, 1)""",
        (policy_id, name, applies_to_severity, system_id,
         json.dumps(escalation_order), step_timeout_minutes),
    )
    conn.commit()
    return get_escalation_policy(conn, policy_id)


def get_escalation_policy(conn, policy_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_escalation_policies WHERE id = ?", (policy_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("escalation policy not found")
    d = _row_to_dict(row)
    d["escalation_order"] = json.loads(d["escalation_order"])
    d["is_active"] = bool(d["is_active"])
    return d


def list_escalation_policies(conn) -> list:
    rows = conn.execute("SELECT * FROM guardian_escalation_policies").fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["escalation_order"] = json.loads(d["escalation_order"])
        d["is_active"] = bool(d["is_active"])
        out.append(d)
    return out


def _trigger_escalations(conn, *, severity, system_id, finding_id=None, security_incident_id=None):
    """Finds every active policy matching this severity (scoped to the
    system, or global with system_id IS NULL) and opens an escalation
    event on step 0 for each."""
    rows = conn.execute(
        """SELECT * FROM guardian_escalation_policies
           WHERE is_active = 1 AND applies_to_severity = ?
             AND (system_id = ? OR system_id IS NULL)""",
        (severity, system_id),
    ).fetchall()

    events = []
    for row in rows:
        policy = _row_to_dict(row)
        order = json.loads(policy["escalation_order"])
        first_notified = order[0]
        event_id = _uid()
        conn.execute(
            """INSERT INTO guardian_escalation_events
               (id, policy_id, finding_id, security_incident_id, current_step,
                notified_ref, notified_at, status)
               VALUES (?, ?, ?, ?, 0, ?, ?, 'active')""",
            (event_id, policy["id"], finding_id, security_incident_id, first_notified, _now()),
        )
        _log_action(conn, system_id=system_id, action_type="escalation_triggered",
                    reference_table="guardian_escalation_events", reference_id=event_id,
                    detail={"policy_id": policy["id"], "notified_ref": first_notified})
        events.append(event_id)
    conn.commit()
    return events


def get_escalation_event(conn, event_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_escalation_events WHERE id = ?", (event_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("escalation event not found")
    return _row_to_dict(row)


def list_escalation_events(conn, status=None) -> list:
    if status:
        rows = conn.execute(
            "SELECT * FROM guardian_escalation_events WHERE status = ?", (status,)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM guardian_escalation_events").fetchall()
    return [_row_to_dict(r) for r in rows]


def acknowledge_escalation(conn, event_id, *, admin_identity_ref):
    event = get_escalation_event(conn, event_id)
    if event["status"] != "active":
        raise InvalidStateError(f"cannot acknowledge an escalation in status '{event['status']}'")

    admin = _get_active_admin(conn, admin_identity_ref)
    # Whoever is currently notified may acknowledge; a super_admin may
    # always acknowledge on anyone's behalf (e.g. covering for someone).
    if admin["identity_ref"] != event["notified_ref"] and admin["role"] != "super_admin":
        raise ForbiddenError("only the currently notified admin (or a super_admin) may acknowledge")

    policy = get_escalation_policy(conn, event["policy_id"])
    conn.execute(
        "UPDATE guardian_escalation_events SET status = 'acknowledged', acknowledged_at = ? WHERE id = ?",
        (_now(), event_id),
    )
    _log_action(conn, system_id=policy["system_id"], action_type="escalation_acknowledged",
                reference_table="guardian_escalation_events", reference_id=event_id,
                detail={"acknowledged_by": admin["identity_ref"]})
    conn.commit()
    return get_escalation_event(conn, event_id)


def process_escalation_timeouts(conn, *, now=None):
    """Advances every active escalation event whose current step has
    timed out to the next person in the policy's escalation_order. If
    already on the last step, marks it 'exhausted' instead of looping.
    Returns the list of event ids that were advanced or exhausted.

    `now` is an optional ISO datetime override for deterministic
    testing/backfill; production callers (a scheduled job) omit it and
    real time is used.
    """
    current_time = datetime.fromisoformat(now) if now else datetime.now(timezone.utc)
    advanced = []

    active_events = conn.execute(
        "SELECT * FROM guardian_escalation_events WHERE status = 'active'"
    ).fetchall()

    for row in active_events:
        event = _row_to_dict(row)
        policy = get_escalation_policy(conn, event["policy_id"])
        notified_at = datetime.fromisoformat(event["notified_at"])
        elapsed_minutes = (current_time - notified_at).total_seconds() / 60.0

        if elapsed_minutes < policy["step_timeout_minutes"]:
            continue  # still within the current step's window

        order = policy["escalation_order"]
        next_step = event["current_step"] + 1

        if next_step >= len(order):
            conn.execute(
                "UPDATE guardian_escalation_events SET status = 'exhausted' WHERE id = ?",
                (event["id"],),
            )
            _log_action(conn, system_id=policy["system_id"], action_type="escalation_exhausted",
                        reference_table="guardian_escalation_events", reference_id=event["id"],
                        detail={"policy_id": policy["id"]})
        else:
            next_notified = order[next_step]
            conn.execute(
                """UPDATE guardian_escalation_events
                   SET current_step = ?, notified_ref = ?, notified_at = ?
                   WHERE id = ?""",
                (next_step, next_notified, current_time.isoformat(), event["id"]),
            )
            _log_action(conn, system_id=policy["system_id"], action_type="escalation_advanced",
                        reference_table="guardian_escalation_events", reference_id=event["id"],
                        detail={"policy_id": policy["id"], "notified_ref": next_notified,
                                "step": next_step})
        advanced.append(event["id"])

    conn.commit()
    return advanced


# ---------- Audio monitoring ----------

def create_audio_stream(conn, *, system_id, source_ref, channel_count=1, sample_rate_hz=None):
    get_system(conn, system_id)  # existence check
    if channel_count < 1:
        raise InvalidStateError("channel_count must be at least 1")

    stream_id = _uid()
    conn.execute(
        """INSERT INTO guardian_audio_streams
           (id, system_id, source_ref, channel_count, sample_rate_hz, started_at, status)
           VALUES (?, ?, ?, ?, ?, ?, 'active')""",
        (stream_id, system_id, source_ref, channel_count, sample_rate_hz, _now()),
    )
    # Auto-create the declared number of channels, labeled by index —
    # callers can relabel/link an actor via update_audio_channel.
    channel_ids = []
    for idx in range(channel_count):
        channel_id = _uid()
        conn.execute(
            """INSERT INTO guardian_audio_channels
               (id, stream_id, channel_index, channel_label)
               VALUES (?, ?, ?, ?)""",
            (channel_id, stream_id, idx, f"channel_{idx}"),
        )
        channel_ids.append(channel_id)

    _log_action(conn, system_id=system_id, action_type="audio_stream_started",
                reference_table="guardian_audio_streams", reference_id=stream_id,
                detail={"source_ref": source_ref, "channel_count": channel_count})
    conn.commit()
    stream = get_audio_stream(conn, stream_id)
    stream["channel_ids"] = channel_ids
    return stream


def get_audio_stream(conn, stream_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_audio_streams WHERE id = ?", (stream_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("audio stream not found")
    return _row_to_dict(row)


def list_audio_streams(conn, system_id=None) -> list:
    if system_id:
        rows = conn.execute(
            "SELECT * FROM guardian_audio_streams WHERE system_id = ?", (system_id,)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM guardian_audio_streams").fetchall()
    return [_row_to_dict(r) for r in rows]


def end_audio_stream(conn, stream_id):
    stream = get_audio_stream(conn, stream_id)
    if stream["status"] != "active":
        raise InvalidStateError(f"cannot end a stream in status '{stream['status']}'")
    conn.execute(
        "UPDATE guardian_audio_streams SET status = 'ended', ended_at = ? WHERE id = ?",
        (_now(), stream_id),
    )
    conn.commit()
    return get_audio_stream(conn, stream_id)


def list_audio_channels(conn, stream_id) -> list:
    get_audio_stream(conn, stream_id)  # existence check
    rows = conn.execute(
        "SELECT * FROM guardian_audio_channels WHERE stream_id = ? ORDER BY channel_index",
        (stream_id,),
    ).fetchall()
    return [_row_to_dict(r) for r in rows]


def update_audio_channel(conn, channel_id, *, channel_label=None, actor_ref=None):
    row = conn.execute(
        "SELECT * FROM guardian_audio_channels WHERE id = ?", (channel_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("audio channel not found")
    current = _row_to_dict(row)
    conn.execute(
        "UPDATE guardian_audio_channels SET channel_label = ?, actor_ref = ? WHERE id = ?",
        (channel_label if channel_label is not None else current["channel_label"],
         actor_ref if actor_ref is not None else current["actor_ref"],
         channel_id),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM guardian_audio_channels WHERE id = ?", (channel_id,)).fetchone()
    return _row_to_dict(row)


def create_audio_band(conn, *, name, low_hz, high_hz):
    if low_hz >= high_hz:
        raise InvalidStateError("low_hz must be less than high_hz")
    existing = conn.execute("SELECT id FROM guardian_audio_bands WHERE name = ?", (name,)).fetchone()
    if existing:
        raise InvalidStateError(f"audio band '{name}' already exists")
    band_id = _uid()
    conn.execute(
        "INSERT INTO guardian_audio_bands (id, name, low_hz, high_hz, is_active) VALUES (?, ?, ?, ?, 1)",
        (band_id, name, low_hz, high_hz),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM guardian_audio_bands WHERE id = ?", (band_id,)).fetchone()
    d = _row_to_dict(row)
    d["is_active"] = bool(d["is_active"])
    return d


def list_audio_bands(conn) -> list:
    rows = conn.execute("SELECT * FROM guardian_audio_bands").fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["is_active"] = bool(d["is_active"])
        out.append(d)
    return out


def record_audio_band_metric(conn, *, channel_id, band_id, window_start, window_end,
                              avg_level_db=None, peak_level_db=None, noise_floor_db=None,
                              clipping_ratio=None, silence_ratio=None):
    channel = conn.execute(
        "SELECT * FROM guardian_audio_channels WHERE id = ?", (channel_id,)
    ).fetchone()
    if not channel:
        raise NotFoundError("audio channel not found")
    band = conn.execute("SELECT * FROM guardian_audio_bands WHERE id = ?", (band_id,)).fetchone()
    if not band:
        raise NotFoundError("audio band not found")
    for name, val in (("clipping_ratio", clipping_ratio), ("silence_ratio", silence_ratio)):
        if val is not None and not (0.0 <= val <= 1.0):
            raise InvalidStateError(f"{name} must be between 0 and 1")

    metric_id = _uid()
    conn.execute(
        """INSERT INTO guardian_audio_band_metrics
           (id, channel_id, band_id, window_start, window_end, avg_level_db,
            peak_level_db, noise_floor_db, clipping_ratio, silence_ratio)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (metric_id, channel_id, band_id, window_start, window_end, avg_level_db,
         peak_level_db, noise_floor_db, clipping_ratio, silence_ratio),
    )
    conn.commit()
    row = conn.execute(
        "SELECT * FROM guardian_audio_band_metrics WHERE id = ?", (metric_id,)
    ).fetchone()
    return _row_to_dict(row)


def list_audio_band_metrics(conn, channel_id) -> list:
    rows = conn.execute(
        "SELECT * FROM guardian_audio_band_metrics WHERE channel_id = ? ORDER BY window_start",
        (channel_id,),
    ).fetchall()
    return [_row_to_dict(r) for r in rows]


# Finding types that indicate the audio might be getting captured by
# something other than the authorized recording path. These always
# escalate to a security incident and can never be silently dismissed
# without going through that incident's own lifecycle.
ALWAYS_ESCALATES_AUDIO_FINDING_TYPES = {"possible_unauthorized_capture"}


def create_audio_finding(conn, *, stream_id, finding_type, severity, summary,
                          channel_id=None, band_id=None, evidence_json=None):
    stream = get_audio_stream(conn, stream_id)

    linked_incident_id = None
    if finding_type in ALWAYS_ESCALATES_AUDIO_FINDING_TYPES:
        incident = create_security_incident(
            conn,
            incident_type=finding_type,
            severity=severity if severity in ("high", "critical") else "high",
            system_id=stream["system_id"],
            evidence_json=evidence_json,
        )
        linked_incident_id = incident["id"]

    finding_id = _uid()
    conn.execute(
        """INSERT INTO guardian_audio_findings
           (id, stream_id, channel_id, band_id, linked_security_incident_id,
            finding_type, severity, summary, evidence_json, status, detected_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)""",
        (finding_id, stream_id, channel_id, band_id, linked_incident_id,
         finding_type, severity, summary, json.dumps(evidence_json or {}), _now()),
    )
    _log_action(conn, system_id=stream["system_id"], action_type="audio_finding_created",
                reference_table="guardian_audio_findings", reference_id=finding_id,
                detail={"finding_type": finding_type, "severity": severity,
                        "linked_security_incident_id": linked_incident_id})
    conn.commit()
    return get_audio_finding(conn, finding_id)


def get_audio_finding(conn, finding_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_audio_findings WHERE id = ?", (finding_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("audio finding not found")
    return _row_to_dict(row)


def list_audio_findings(conn, stream_id=None, status=None) -> list:
    query = "SELECT * FROM guardian_audio_findings WHERE 1=1"
    params = []
    if stream_id:
        query += " AND stream_id = ?"
        params.append(stream_id)
    if status:
        query += " AND status = ?"
        params.append(status)
    rows = conn.execute(query, params).fetchall()
    return [_row_to_dict(r) for r in rows]


def resolve_audio_finding(conn, finding_id, *, resolved_by=None):
    finding = get_audio_finding(conn, finding_id)
    if finding["status"] == "resolved":
        raise InvalidStateError("audio finding already resolved")
    if (finding["finding_type"] in ALWAYS_ESCALATES_AUDIO_FINDING_TYPES
            and finding["linked_security_incident_id"]):
        incident = get_security_incident(conn, finding["linked_security_incident_id"])
        if incident["status"] != "resolved":
            raise InvalidStateError(
                "cannot resolve this audio finding until its linked security "
                "incident is resolved"
            )
    conn.execute(
        "UPDATE guardian_audio_findings SET status = 'resolved', resolved_at = ? WHERE id = ?",
        (_now(), finding_id),
    )
    _log_action(conn, system_id=None, action_type="audio_finding_resolved",
                reference_table="guardian_audio_findings", reference_id=finding_id,
                detail={"resolved_by": resolved_by})
    conn.commit()
    return get_audio_finding(conn, finding_id)


# ---------- Code integrity verification ----------
#
# The single supported "protect the code" capability: register a known
# -good hash for a component, then compare future hashes against it.
# This is integrity verification only — no anti-debugging, no
# obfuscation, no anti-analysis. A mismatch produces a critical
# security incident, same as any other tamper signal Guardian handles.

def register_code_signature(conn, *, system_id, component_ref, expected_hash,
                             algorithm="sha256", registered_by=None):
    get_system(conn, system_id)  # existence check

    # Deactivate any prior active signature for this exact component so
    # there's always exactly one active baseline per (system, component).
    conn.execute(
        """UPDATE guardian_code_signatures SET is_active = 0
           WHERE system_id = ? AND component_ref = ? AND is_active = 1""",
        (system_id, component_ref),
    )

    signature_id = _uid()
    conn.execute(
        """INSERT INTO guardian_code_signatures
           (id, system_id, component_ref, algorithm, expected_hash,
            registered_by, registered_at, is_active)
           VALUES (?, ?, ?, ?, ?, ?, ?, 1)""",
        (signature_id, system_id, component_ref, algorithm, expected_hash,
         registered_by, _now()),
    )
    _log_action(conn, system_id=system_id, action_type="code_signature_registered",
                reference_table="guardian_code_signatures", reference_id=signature_id,
                detail={"component_ref": component_ref, "algorithm": algorithm})
    conn.commit()
    return get_code_signature(conn, signature_id)


def get_code_signature(conn, signature_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_code_signatures WHERE id = ?", (signature_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("code signature not found")
    d = _row_to_dict(row)
    d["is_active"] = bool(d["is_active"])
    return d


def _get_active_signature(conn, system_id, component_ref):
    row = conn.execute(
        """SELECT * FROM guardian_code_signatures
           WHERE system_id = ? AND component_ref = ? AND is_active = 1
           ORDER BY registered_at DESC LIMIT 1""",
        (system_id, component_ref),
    ).fetchone()
    if not row:
        return None
    d = _row_to_dict(row)
    d["is_active"] = bool(d["is_active"])
    return d


def list_code_signatures(conn, system_id=None, component_ref=None) -> list:
    query = "SELECT * FROM guardian_code_signatures WHERE 1=1"
    params = []
    if system_id:
        query += " AND system_id = ?"
        params.append(system_id)
    if component_ref:
        query += " AND component_ref = ?"
        params.append(component_ref)
    rows = conn.execute(query, params).fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["is_active"] = bool(d["is_active"])
        out.append(d)
    return out


def verify_code_integrity(conn, *, system_id, component_ref, actual_hash):
    """Compares actual_hash against the active baseline for this
    component. Returns a dict describing the outcome — this is a
    detection result, not a client error, so it never raises for a
    mismatch or a missing baseline; both are valid runtime findings."""
    get_system(conn, system_id)  # existence check
    signature = _get_active_signature(conn, system_id, component_ref)

    if signature is None:
        result = "no_baseline"
        linked_incident_id = None
    elif signature["expected_hash"] == actual_hash:
        result = "match"
        linked_incident_id = None
    else:
        result = "mismatch"
        incident = create_security_incident(
            conn,
            incident_type="code_integrity_violation",
            severity="critical",
            system_id=system_id,
            evidence_json={
                "component_ref": component_ref,
                "expected_hash": signature["expected_hash"],
                "actual_hash": actual_hash,
                "algorithm": signature["algorithm"],
            },
        )
        linked_incident_id = incident["id"]

    check_id = _uid()
    conn.execute(
        """INSERT INTO guardian_integrity_check_log
           (id, signature_id, system_id, component_ref, actual_hash,
            result, linked_security_incident_id, checked_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (check_id, signature["id"] if signature else None, system_id, component_ref,
         actual_hash, result, linked_incident_id, _now()),
    )
    _log_action(conn, system_id=system_id, action_type="integrity_check_performed",
                reference_table="guardian_integrity_check_log", reference_id=check_id,
                detail={"component_ref": component_ref, "result": result})
    conn.commit()

    row = conn.execute(
        "SELECT * FROM guardian_integrity_check_log WHERE id = ?", (check_id,)
    ).fetchone()
    return _row_to_dict(row)


def list_integrity_checks(conn, system_id=None, component_ref=None, result=None) -> list:
    query = "SELECT * FROM guardian_integrity_check_log WHERE 1=1"
    params = []
    if system_id:
        query += " AND system_id = ?"
        params.append(system_id)
    if component_ref:
        query += " AND component_ref = ?"
        params.append(component_ref)
    if result:
        query += " AND result = ?"
        params.append(result)
    query += " ORDER BY checked_at DESC"
    rows = conn.execute(query, params).fetchall()
    return [_row_to_dict(r) for r in rows]


# ---------- Connector registry ----------

def register_connector(conn, *, connector_key, display_name, connector_type, direction,
                        authorized_by, target_system_id=None, capabilities_json=None,
                        version="1.0", auth_ref=None):
    existing = conn.execute(
        "SELECT id FROM guardian_connector_registry WHERE connector_key = ?", (connector_key,)
    ).fetchone()
    if existing:
        raise InvalidStateError(f"connector_key '{connector_key}' already registered")
    if target_system_id:
        get_system(conn, target_system_id)

    connector_id = _uid()
    conn.execute(
        """INSERT INTO guardian_connector_registry
           (id, connector_key, display_name, connector_type, direction, target_system_id,
            capabilities_json, version, auth_ref, authorized_by, authorized_at, is_active)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)""",
        (connector_id, connector_key, display_name, connector_type, direction, target_system_id,
         json.dumps(capabilities_json or {}), version, auth_ref, authorized_by, _now()),
    )
    _log_action(conn, system_id=target_system_id, action_type="connector_registered",
                reference_table="guardian_connector_registry", reference_id=connector_id,
                detail={"connector_key": connector_key, "connector_type": connector_type,
                        "authorized_by": authorized_by})
    conn.commit()
    return get_connector(conn, connector_id)


def get_connector(conn, connector_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_connector_registry WHERE id = ?", (connector_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("connector not found")
    d = _row_to_dict(row)
    d["capabilities_json"] = json.loads(d["capabilities_json"]) if d["capabilities_json"] else {}
    d["is_active"] = bool(d["is_active"])
    return d


def list_connectors(conn, connector_type=None) -> list:
    if connector_type:
        rows = conn.execute(
            "SELECT * FROM guardian_connector_registry WHERE connector_type = ?", (connector_type,)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM guardian_connector_registry").fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["capabilities_json"] = json.loads(d["capabilities_json"]) if d["capabilities_json"] else {}
        d["is_active"] = bool(d["is_active"])
        out.append(d)
    return out


# ---------- Vendor gateway ----------

# Direct DB access is never an acceptable isolation method for a
# vendor/contractor connection — protection flows toward the vendor,
# access never flows in.
FORBIDDEN_VENDOR_ISOLATION_METHODS = {"direct_db_link"}


def create_vendor_gateway_connector(conn, *, connector_id, vendor_system_id, data_direction,
                                     exposed_fields, isolation_method, never_exposes_internal_ref=None):
    get_connector(conn, connector_id)
    get_system(conn, vendor_system_id)
    if isolation_method in FORBIDDEN_VENDOR_ISOLATION_METHODS:
        raise InvalidStateError(
            f"isolation_method '{isolation_method}' is not permitted for a vendor gateway — "
            "vendor/contractor connections must never have direct database access"
        )
    if not exposed_fields:
        raise InvalidStateError("exposed_fields must be a non-empty explicit allowlist")

    gateway_id = _uid()
    conn.execute(
        """INSERT INTO guardian_vendor_gateway_connectors
           (id, connector_id, vendor_system_id, data_direction, exposed_fields,
            isolation_method, never_exposes_internal_ref, is_active)
           VALUES (?, ?, ?, ?, ?, ?, ?, 1)""",
        (gateway_id, connector_id, vendor_system_id, data_direction,
         json.dumps(exposed_fields), isolation_method,
         json.dumps(never_exposes_internal_ref or [])),
    )
    _log_action(conn, system_id=vendor_system_id, action_type="vendor_gateway_created",
                reference_table="guardian_vendor_gateway_connectors", reference_id=gateway_id,
                detail={"isolation_method": isolation_method, "data_direction": data_direction})
    conn.commit()
    return get_vendor_gateway_connector(conn, gateway_id)


def get_vendor_gateway_connector(conn, gateway_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_vendor_gateway_connectors WHERE id = ?", (gateway_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("vendor gateway connector not found")
    d = _row_to_dict(row)
    d["exposed_fields"] = json.loads(d["exposed_fields"])
    d["never_exposes_internal_ref"] = json.loads(d["never_exposes_internal_ref"] or "[]")
    d["is_active"] = bool(d["is_active"])
    return d


def list_vendor_gateway_connectors(conn, vendor_system_id=None) -> list:
    if vendor_system_id:
        rows = conn.execute(
            "SELECT * FROM guardian_vendor_gateway_connectors WHERE vendor_system_id = ?",
            (vendor_system_id,),
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM guardian_vendor_gateway_connectors").fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["exposed_fields"] = json.loads(d["exposed_fields"])
        d["never_exposes_internal_ref"] = json.loads(d["never_exposes_internal_ref"] or "[]")
        d["is_active"] = bool(d["is_active"])
        out.append(d)
    return out


def _is_vendor_gateway_system(conn, system_id) -> bool:
    row = conn.execute(
        "SELECT id FROM guardian_vendor_gateway_connectors WHERE vendor_system_id = ? AND is_active = 1",
        (system_id,),
    ).fetchone()
    return row is not None


def register_admin_guarded(conn, *, identity_ref, role="viewer", system_scope=None):
    """Same as register_admin, but refuses to grant admin access scoped
    to a vendor/contractor system — protection flows toward vendors,
    never access flows in from them."""
    if system_scope:
        for system_id in system_scope:
            if _is_vendor_gateway_system(conn, system_id):
                raise ForbiddenError(
                    f"cannot grant admin access scoped to a vendor/contractor system ({system_id}) — "
                    "vendor systems may never be granted Guardian admin roles"
                )
    return register_admin(conn, identity_ref=identity_ref, role=role, system_scope=system_scope)


# ---------- Sensor registry ----------

def register_sensor(conn, *, sensor_key, sensor_type, system_id, connector_id=None,
                     capabilities_json=None):
    existing = conn.execute(
        "SELECT id FROM guardian_sensor_registry WHERE sensor_key = ?", (sensor_key,)
    ).fetchone()
    if existing:
        raise InvalidStateError(f"sensor_key '{sensor_key}' already registered")
    get_system(conn, system_id)
    if connector_id:
        get_connector(conn, connector_id)

    sensor_id = _uid()
    conn.execute(
        """INSERT INTO guardian_sensor_registry
           (id, sensor_key, sensor_type, system_id, connector_id, capabilities_json,
            is_active, registered_at)
           VALUES (?, ?, ?, ?, ?, ?, 1, ?)""",
        (sensor_id, sensor_key, sensor_type, system_id, connector_id,
         json.dumps(capabilities_json or {}), _now()),
    )
    conn.commit()
    return get_sensor(conn, sensor_id)


def get_sensor(conn, sensor_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_sensor_registry WHERE id = ?", (sensor_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("sensor not found")
    d = _row_to_dict(row)
    d["capabilities_json"] = json.loads(d["capabilities_json"]) if d["capabilities_json"] else {}
    d["is_active"] = bool(d["is_active"])
    return d


def list_sensors(conn, system_id=None, sensor_type=None) -> list:
    query = "SELECT * FROM guardian_sensor_registry WHERE 1=1"
    params = []
    if system_id:
        query += " AND system_id = ?"
        params.append(system_id)
    if sensor_type:
        query += " AND sensor_type = ?"
        params.append(sensor_type)
    rows = conn.execute(query, params).fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["capabilities_json"] = json.loads(d["capabilities_json"]) if d["capabilities_json"] else {}
        d["is_active"] = bool(d["is_active"])
        out.append(d)
    return out


def record_sensor_event(conn, *, sensor_id, event_type, severity="info", payload_json=None):
    sensor = get_sensor(conn, sensor_id)

    # Ingestion passes through the rate limiter first — a flooding
    # sensor gets throttled rather than allowed to overwhelm Guardian.
    throttle_result = _check_and_increment_rate_limit(conn, system_id=sensor["system_id"],
                                                        sensor_id=sensor_id)
    if throttle_result["throttled"]:
        return {"accepted": False, "reason": "rate_limited", "event_id": None}

    event_id = _uid()
    conn.execute(
        """INSERT INTO guardian_sensor_events
           (id, sensor_id, event_type, severity, payload_json, occurred_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (event_id, sensor_id, event_type, severity, json.dumps(payload_json or {}), _now()),
    )
    conn.commit()
    return {"accepted": True, "reason": None, "event_id": event_id}


def list_sensor_events(conn, sensor_id=None) -> list:
    if sensor_id:
        rows = conn.execute(
            "SELECT * FROM guardian_sensor_events WHERE sensor_id = ? ORDER BY occurred_at DESC",
            (sensor_id,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM guardian_sensor_events ORDER BY occurred_at DESC"
        ).fetchall()
    return [_row_to_dict(r) for r in rows]


# ---------- C2 integration ----------

def create_c2_integration(conn, *, connector_id, c2_system_name, data_scope,
                           role="upstream_command", accepts_directives=False):
    get_connector(conn, connector_id)
    integration_id = _uid()
    conn.execute(
        """INSERT INTO guardian_c2_integrations
           (id, connector_id, c2_system_name, role, data_scope, accepts_directives, is_active)
           VALUES (?, ?, ?, ?, ?, ?, 1)""",
        (integration_id, connector_id, c2_system_name, role,
         json.dumps(data_scope), int(accepts_directives)),
    )
    conn.commit()
    return get_c2_integration(conn, integration_id)


def get_c2_integration(conn, integration_id) -> dict:
    row = conn.execute(
        "SELECT * FROM guardian_c2_integrations WHERE id = ?", (integration_id,)
    ).fetchone()
    if not row:
        raise NotFoundError("C2 integration not found")
    d = _row_to_dict(row)
    d["data_scope"] = json.loads(d["data_scope"])
    d["accepts_directives"] = bool(d["accepts_directives"])
    d["is_active"] = bool(d["is_active"])
    return d


def publish_to_c2(conn, integration_id, *, payload_summary, reference_table=None, reference_id=None):
    get_c2_integration(conn, integration_id)
    log_id = _uid()
    conn.execute(
        """INSERT INTO guardian_c2_sync_log
           (id, c2_integration_id, direction, payload_summary, reference_table, reference_id, occurred_at)
           VALUES (?, ?, 'published', ?, ?, ?, ?)""",
        (log_id, integration_id, payload_summary, reference_table, reference_id, _now()),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM guardian_c2_sync_log WHERE id = ?", (log_id,)).fetchone()
    return _row_to_dict(row)


def receive_c2_directive(conn, integration_id, *, finding_id, system_id, proposed_action,
                          change_json, category, risk_level):
    """A directive from a C2 system is NEVER auto-applied, regardless
    of accepts_directives — it always becomes a fix proposal, subject
    to the exact same approval rules as any other proposed fix.
    accepts_directives governs whether Guardian LISTENS at all, never
    whether it acts unilaterally on what it hears."""
    integration = get_c2_integration(conn, integration_id)
    if not integration["accepts_directives"]:
        raise ForbiddenError("this C2 integration is not configured to accept directives")

    proposal = create_fix_proposal(
        conn, finding_id=finding_id, system_id=system_id, proposed_action=proposed_action,
        change_json=change_json, category=category, risk_level=risk_level,
    )

    log_id = _uid()
    conn.execute(
        """INSERT INTO guardian_c2_sync_log
           (id, c2_integration_id, direction, payload_summary, reference_table, reference_id, occurred_at)
           VALUES (?, ?, 'received', ?, 'guardian_fix_proposals', ?, ?)""",
        (log_id, integration_id, f"directive: {proposed_action}", proposal["id"], _now()),
    )
    conn.commit()
    return proposal


def list_c2_sync_log(conn, integration_id=None) -> list:
    if integration_id:
        rows = conn.execute(
            "SELECT * FROM guardian_c2_sync_log WHERE c2_integration_id = ? ORDER BY occurred_at DESC",
            (integration_id,),
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM guardian_c2_sync_log ORDER BY occurred_at DESC").fetchall()
    return [_row_to_dict(r) for r in rows]


# ---------- Health & risk scoring ----------

def compute_system_health_score(conn, system_id) -> dict:
    get_system(conn, system_id)
    open_findings = conn.execute(
        "SELECT COUNT(*) AS c FROM guardian_findings WHERE system_id = ? AND status = 'open'",
        (system_id,),
    ).fetchone()["c"]
    open_incidents = conn.execute(
        "SELECT COUNT(*) AS c FROM guardian_security_incidents WHERE system_id = ? AND status = 'open'",
        (system_id,),
    ).fetchone()["c"]

    # Simple, transparent weighting: each open finding costs 5 points,
    # each open security incident costs 15, floor at 0.
    findings_weight = min(open_findings * 5, 100)
    security_weight = min(open_incidents * 15, 100)
    score = max(0.0, 100.0 - findings_weight - security_weight)

    score_id = _uid()
    conn.execute(
        """INSERT INTO guardian_system_health_scores
           (id, system_id, score, open_findings_weight, security_weight, computed_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (score_id, system_id, score, findings_weight, security_weight, _now()),
    )
    conn.commit()
    row = conn.execute(
        "SELECT * FROM guardian_system_health_scores WHERE id = ?", (score_id,)
    ).fetchone()
    return _row_to_dict(row)


def list_system_health_scores(conn, system_id) -> list:
    rows = conn.execute(
        "SELECT * FROM guardian_system_health_scores WHERE system_id = ? ORDER BY computed_at DESC",
        (system_id,),
    ).fetchall()
    return [_row_to_dict(r) for r in rows]


def compute_ecosystem_risk_score(conn) -> dict:
    systems = list_systems(conn)
    active_systems = [s for s in systems if s["is_active"]]
    if not active_systems:
        raise InvalidStateError("no active systems registered — nothing to score")

    breakdown = []
    total_deficit = 0.0
    for system in active_systems:
        health = compute_system_health_score(conn, system["id"])
        deficit = 100.0 - health["score"]
        total_deficit += deficit
        breakdown.append({
            "system_id": system["id"], "system_key": system["system_key"],
            "health_score": health["score"], "deficit": deficit,
        })

    risk_score = min(100.0, total_deficit / len(active_systems))

    score_id = _uid()
    conn.execute(
        """INSERT INTO guardian_ecosystem_risk_scores
           (id, score, systems_included, contributing_factors_json, computed_at)
           VALUES (?, ?, ?, ?, ?)""",
        (score_id, risk_score, len(active_systems), json.dumps(breakdown), _now()),
    )
    conn.commit()
    row = conn.execute(
        "SELECT * FROM guardian_ecosystem_risk_scores WHERE id = ?", (score_id,)
    ).fetchone()
    d = _row_to_dict(row)
    d["contributing_factors_json"] = json.loads(d["contributing_factors_json"])
    return d


def list_ecosystem_risk_scores(conn) -> list:
    rows = conn.execute(
        "SELECT * FROM guardian_ecosystem_risk_scores ORDER BY computed_at DESC"
    ).fetchall()
    out = []
    for row in rows:
        d = _row_to_dict(row)
        d["contributing_factors_json"] = json.loads(d["contributing_factors_json"])
        out.append(d)
    return out


# ---------- Ingestion rate limiting / backpressure ----------

def set_rate_limit(conn, *, max_events_per_minute, system_id=None, sensor_id=None):
    if system_id:
        get_system(conn, system_id)
    if sensor_id:
        get_sensor(conn, sensor_id)
    if max_events_per_minute < 1:
        raise InvalidStateError("max_events_per_minute must be at least 1")

    limit_id = _uid()
    conn.execute(
        """INSERT INTO guardian_ingestion_rate_limits
           (id, system_id, sensor_id, max_events_per_minute, current_window_count,
            window_started_at, is_throttled)
           VALUES (?, ?, ?, ?, 0, ?, 0)""",
        (limit_id, system_id, sensor_id, max_events_per_minute, _now()),
    )
    conn.commit()
    row = conn.execute(
        "SELECT * FROM guardian_ingestion_rate_limits WHERE id = ?", (limit_id,)
    ).fetchone()
    return _row_to_dict(row)


def _check_and_increment_rate_limit(conn, *, system_id, sensor_id=None):
    """Finds the most specific applicable rate limit (sensor-scoped
    beats system-scoped) and increments its rolling one-minute window.
    Returns {"throttled": bool}. If no limit is configured, ingestion
    is unrestricted (returns not throttled)."""
    row = None
    if sensor_id:
        row = conn.execute(
            "SELECT * FROM guardian_ingestion_rate_limits WHERE sensor_id = ?", (sensor_id,)
        ).fetchone()
    if row is None and system_id:
        row = conn.execute(
            "SELECT * FROM guardian_ingestion_rate_limits WHERE system_id = ? AND sensor_id IS NULL",
            (system_id,),
        ).fetchone()
    if row is None:
        return {"throttled": False}

    limit = _row_to_dict(row)
    window_started = datetime.fromisoformat(limit["window_started_at"])
    now = datetime.now(timezone.utc)
    elapsed_seconds = (now - window_started).total_seconds()

    if elapsed_seconds >= 60:
        # New window.
        new_count = 1
        conn.execute(
            """UPDATE guardian_ingestion_rate_limits
               SET current_window_count = ?, window_started_at = ?, is_throttled = 0
               WHERE id = ?""",
            (new_count, now.isoformat(), limit["id"]),
        )
        conn.commit()
        return {"throttled": False}

    new_count = limit["current_window_count"] + 1
    throttled = new_count > limit["max_events_per_minute"]
    conn.execute(
        """UPDATE guardian_ingestion_rate_limits
           SET current_window_count = ?, is_throttled = ?, throttled_at = ?
           WHERE id = ?""",
        (new_count, int(throttled), _now() if throttled else limit.get("throttled_at"), limit["id"]),
    )

    if throttled and not limit["is_throttled"]:
        # Newly throttled this call — raise visibility rather than
        # silently absorbing the spike. No check_id exists for a
        # synthetic system-level signal, so log it directly.
        _log_action(conn, system_id=system_id, action_type="ingestion_rate_limited",
                    reference_table="guardian_ingestion_rate_limits", reference_id=limit["id"],
                    detail={"sensor_id": sensor_id, "max_events_per_minute": limit["max_events_per_minute"]})

    conn.commit()
    return {"throttled": throttled}


def get_rate_limit_status(conn, *, system_id=None, sensor_id=None) -> dict:
    row = None
    if sensor_id:
        row = conn.execute(
            "SELECT * FROM guardian_ingestion_rate_limits WHERE sensor_id = ?", (sensor_id,)
        ).fetchone()
    elif system_id:
        row = conn.execute(
            "SELECT * FROM guardian_ingestion_rate_limits WHERE system_id = ? AND sensor_id IS NULL",
            (system_id,),
        ).fetchone()
    if not row:
        raise NotFoundError("no rate limit configured for this scope")
    d = _row_to_dict(row)
    d["is_throttled"] = bool(d["is_throttled"])
    return d

