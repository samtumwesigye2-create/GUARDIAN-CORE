"""
Database layer for the Guardian core engine. No ORM — plain SQL,
plain dicts, so the query logic in services.py never has to change.

Supports two backends, chosen by the connection string:
  - SQLite (default): any path not starting with postgres(ql)://
  - Postgres: a postgres:// or postgresql:// URL, via psycopg2

Every query in services.py is written in ANSI-portable SQL (plain
TEXT/INTEGER columns, no SQLite-only functions), so the only backend-
specific work is here: placeholder style ('?' vs '%s') and how a
connection's .execute()/.commit() are exposed. _PostgresConnAdapter
below gives a psycopg2 connection the same sqlite3.Connection-style
`conn.execute(query, params).fetchone()` interface the rest of the
codebase already uses, so nothing above this file needs to know which
backend it's talking to.

NOTE ON TESTING: the Postgres path is implemented but could not be
exercised in the sandbox this was built in (no network access to
install psycopg2, no reachable Postgres server). tests/test_postgres_backend.py
skips itself automatically unless psycopg2 is importable AND a
GUARDIAN_DATABASE_URL pointing at a real Postgres instance is set —
run it in CI or locally with a real Postgres to actually validate this.
"""

import sqlite3
import threading

try:
    import psycopg2
    import psycopg2.extras
    _HAS_PSYCOPG2 = True
except ImportError:
    _HAS_PSYCOPG2 = False

SCHEMA = """
CREATE TABLE IF NOT EXISTS guardian_system_registry (
    id TEXT PRIMARY KEY,
    system_key TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    category TEXT NOT NULL,
    criticality TEXT NOT NULL DEFAULT 'medium',
    trust_level TEXT NOT NULL DEFAULT 'standard',
    permitted_categories TEXT NOT NULL DEFAULT '[]',  -- JSON array
    connection_type TEXT NOT NULL DEFAULT 'api_poll',
    is_active INTEGER NOT NULL DEFAULT 1,
    onboarded_at TEXT NOT NULL,
    deactivated_at TEXT
);

CREATE TABLE IF NOT EXISTS guardian_checks (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    scope TEXT NOT NULL DEFAULT 'single_system',
    system_id TEXT REFERENCES guardian_system_registry(id),
    target_module TEXT,
    check_logic_ref TEXT NOT NULL,
    run_frequency TEXT NOT NULL DEFAULT 'hourly',
    severity_default TEXT NOT NULL DEFAULT 'medium',
    is_active INTEGER NOT NULL DEFAULT 1,
    auto_fix_allowed INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS guardian_findings (
    id TEXT PRIMARY KEY,
    check_id TEXT NOT NULL REFERENCES guardian_checks(id),
    system_id TEXT REFERENCES guardian_system_registry(id),
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    severity TEXT NOT NULL,
    summary TEXT NOT NULL,
    evidence_json TEXT,
    status TEXT NOT NULL DEFAULT 'open',
    detected_at TEXT NOT NULL,
    resolved_at TEXT,
    resolved_by TEXT
);

CREATE TABLE IF NOT EXISTS guardian_fix_proposals (
    id TEXT PRIMARY KEY,
    finding_id TEXT NOT NULL REFERENCES guardian_findings(id),
    system_id TEXT NOT NULL REFERENCES guardian_system_registry(id),
    proposed_action TEXT NOT NULL,
    change_json TEXT NOT NULL,
    category TEXT NOT NULL,
    risk_level TEXT NOT NULL,
    requires_approval INTEGER NOT NULL DEFAULT 1,
    approved_by TEXT,
    approved_at TEXT,
    auto_applied INTEGER NOT NULL DEFAULT 0,
    applied_at TEXT,
    rolled_back_at TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    effectiveness_checked_at TEXT,
    effectiveness_result TEXT
);

CREATE TABLE IF NOT EXISTS guardian_admins (
    id TEXT PRIMARY KEY,
    identity_ref TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL DEFAULT 'viewer',
    system_scope TEXT,  -- JSON array of system_ids, NULL = all systems
    api_key_hash TEXT NOT NULL,  -- sha256 of the admin's API key; the raw key is never stored
    added_at TEXT NOT NULL,
    revoked_at TEXT
);

CREATE TABLE IF NOT EXISTS guardian_action_log (
    id TEXT PRIMARY KEY,
    system_id TEXT REFERENCES guardian_system_registry(id),
    action_type TEXT NOT NULL,
    reference_table TEXT NOT NULL,
    reference_id TEXT NOT NULL,
    detail_json TEXT,
    occurred_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS guardian_security_incidents (
    id TEXT PRIMARY KEY,
    system_id TEXT REFERENCES guardian_system_registry(id),
    incident_type TEXT NOT NULL,
    actor_ref TEXT,
    source_ip TEXT,
    severity TEXT NOT NULL,
    auto_response TEXT,
    evidence_json TEXT,
    status TEXT NOT NULL DEFAULT 'open',
    detected_at TEXT NOT NULL,
    resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS guardian_escalation_policies (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    applies_to_severity TEXT NOT NULL,
    system_id TEXT REFERENCES guardian_system_registry(id),
    escalation_order TEXT NOT NULL,  -- JSON array of admin identity_refs
    step_timeout_minutes INTEGER NOT NULL DEFAULT 30,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS guardian_escalation_events (
    id TEXT PRIMARY KEY,
    policy_id TEXT NOT NULL REFERENCES guardian_escalation_policies(id),
    finding_id TEXT REFERENCES guardian_findings(id),
    security_incident_id TEXT REFERENCES guardian_security_incidents(id),
    current_step INTEGER NOT NULL DEFAULT 0,
    notified_ref TEXT,
    notified_at TEXT NOT NULL,
    acknowledged_at TEXT,
    status TEXT NOT NULL DEFAULT 'active'  -- active, acknowledged, exhausted
);

CREATE TABLE IF NOT EXISTS guardian_audio_streams (
    id TEXT PRIMARY KEY,
    system_id TEXT NOT NULL REFERENCES guardian_system_registry(id),
    source_ref TEXT NOT NULL,
    channel_count INTEGER NOT NULL DEFAULT 1,
    sample_rate_hz INTEGER,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    status TEXT NOT NULL DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS guardian_audio_channels (
    id TEXT PRIMARY KEY,
    stream_id TEXT NOT NULL REFERENCES guardian_audio_streams(id),
    channel_index INTEGER NOT NULL,
    channel_label TEXT,
    actor_ref TEXT,
    UNIQUE (stream_id, channel_index)
);

CREATE TABLE IF NOT EXISTS guardian_audio_bands (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    low_hz REAL NOT NULL,
    high_hz REAL NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS guardian_audio_band_metrics (
    id TEXT PRIMARY KEY,
    channel_id TEXT NOT NULL REFERENCES guardian_audio_channels(id),
    band_id TEXT NOT NULL REFERENCES guardian_audio_bands(id),
    window_start TEXT NOT NULL,
    window_end TEXT NOT NULL,
    avg_level_db REAL,
    peak_level_db REAL,
    noise_floor_db REAL,
    clipping_ratio REAL,
    silence_ratio REAL
);

CREATE TABLE IF NOT EXISTS guardian_audio_findings (
    id TEXT PRIMARY KEY,
    stream_id TEXT NOT NULL REFERENCES guardian_audio_streams(id),
    channel_id TEXT REFERENCES guardian_audio_channels(id),
    band_id TEXT REFERENCES guardian_audio_bands(id),
    linked_security_incident_id TEXT REFERENCES guardian_security_incidents(id),
    finding_type TEXT NOT NULL,
    severity TEXT NOT NULL,
    summary TEXT NOT NULL,
    evidence_json TEXT,
    detected_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS guardian_code_signatures (
    id TEXT PRIMARY KEY,
    system_id TEXT NOT NULL REFERENCES guardian_system_registry(id),
    component_ref TEXT NOT NULL,       -- file path, artifact name, or deployed module identifier
    algorithm TEXT NOT NULL DEFAULT 'sha256',
    expected_hash TEXT NOT NULL,
    registered_by TEXT,
    registered_at TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS guardian_integrity_check_log (
    id TEXT PRIMARY KEY,
    signature_id TEXT REFERENCES guardian_code_signatures(id),
    system_id TEXT NOT NULL REFERENCES guardian_system_registry(id),
    component_ref TEXT NOT NULL,
    actual_hash TEXT NOT NULL,
    result TEXT NOT NULL,              -- match, mismatch, no_baseline
    linked_security_incident_id TEXT REFERENCES guardian_security_incidents(id),
    checked_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS guardian_connector_registry (
    id TEXT PRIMARY KEY,
    connector_key TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    connector_type TEXT NOT NULL,
    direction TEXT NOT NULL,
    target_system_id TEXT REFERENCES guardian_system_registry(id),
    capabilities_json TEXT,
    version TEXT NOT NULL DEFAULT '1.0',
    auth_ref TEXT,
    authorized_by TEXT NOT NULL,
    authorized_at TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS guardian_vendor_gateway_connectors (
    id TEXT PRIMARY KEY,
    connector_id TEXT NOT NULL REFERENCES guardian_connector_registry(id),
    vendor_system_id TEXT NOT NULL REFERENCES guardian_system_registry(id),
    data_direction TEXT NOT NULL,
    exposed_fields TEXT NOT NULL,
    isolation_method TEXT NOT NULL,
    never_exposes_internal_ref TEXT,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS guardian_sensor_registry (
    id TEXT PRIMARY KEY,
    sensor_key TEXT UNIQUE NOT NULL,
    sensor_type TEXT NOT NULL,
    system_id TEXT NOT NULL REFERENCES guardian_system_registry(id),
    connector_id TEXT REFERENCES guardian_connector_registry(id),
    capabilities_json TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    registered_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS guardian_sensor_events (
    id TEXT PRIMARY KEY,
    sensor_id TEXT NOT NULL REFERENCES guardian_sensor_registry(id),
    event_type TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'info',
    payload_json TEXT,
    linked_finding_id TEXT REFERENCES guardian_findings(id),
    occurred_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS guardian_c2_integrations (
    id TEXT PRIMARY KEY,
    connector_id TEXT NOT NULL REFERENCES guardian_connector_registry(id),
    c2_system_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'upstream_command',
    data_scope TEXT NOT NULL,
    accepts_directives INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS guardian_c2_sync_log (
    id TEXT PRIMARY KEY,
    c2_integration_id TEXT NOT NULL REFERENCES guardian_c2_integrations(id),
    direction TEXT NOT NULL,
    payload_summary TEXT NOT NULL,
    reference_table TEXT,
    reference_id TEXT,
    occurred_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS guardian_system_health_scores (
    id TEXT PRIMARY KEY,
    system_id TEXT NOT NULL REFERENCES guardian_system_registry(id),
    score REAL NOT NULL,
    open_findings_weight REAL NOT NULL DEFAULT 0,
    security_weight REAL NOT NULL DEFAULT 0,
    computed_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS guardian_ecosystem_risk_scores (
    id TEXT PRIMARY KEY,
    score REAL NOT NULL,
    systems_included INTEGER NOT NULL,
    contributing_factors_json TEXT,
    computed_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS guardian_ingestion_rate_limits (
    id TEXT PRIMARY KEY,
    system_id TEXT REFERENCES guardian_system_registry(id),
    sensor_id TEXT REFERENCES guardian_sensor_registry(id),
    max_events_per_minute INTEGER NOT NULL,
    current_window_count INTEGER NOT NULL DEFAULT 0,
    window_started_at TEXT NOT NULL,
    is_throttled INTEGER NOT NULL DEFAULT 0,
    throttled_at TEXT
);
"""

_local = threading.local()


def _is_postgres_url(connection_string: str) -> bool:
    return connection_string.startswith("postgres://") or connection_string.startswith("postgresql://")


class _PostgresCursorResult:
    """Wraps a psycopg2 cursor so call sites written against sqlite3's
    `conn.execute(...).fetchone()` pattern work unchanged."""

    def __init__(self, cursor):
        self._cursor = cursor

    def fetchone(self):
        return self._cursor.fetchone()

    def fetchall(self):
        return self._cursor.fetchall()


class _PostgresConnAdapter:
    """Gives a psycopg2 connection the same .execute()-returns-a-
    cursor convenience sqlite3.Connection provides natively, and
    translates '?' placeholders to psycopg2's '%s' style. RealDictCursor
    rows behave like dicts (row["col"], row.keys()), matching
    sqlite3.Row closely enough that _row_to_dict() in services.py
    works unchanged against either backend."""

    def __init__(self, pg_conn):
        self._conn = pg_conn

    def execute(self, query, params=()):
        translated = query.replace("?", "%s")
        cursor = self._conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        try:
            cursor.execute(translated, params)
        except psycopg2.Error:
            # Postgres aborts the whole transaction on any error until
            # rolled back — and since one connection is reused across
            # many requests on this thread (see get_connection below),
            # an unrolled-back failure here would silently break every
            # subsequent query on this connection, not just this one.
            self._conn.rollback()
            raise
        return _PostgresCursorResult(cursor)

    def executescript(self, script: str):
        cursor = self._conn.cursor()
        cursor.execute(script)
        cursor.close()

    def commit(self):
        self._conn.commit()


def get_connection(connection_string: str):
    """One connection per (thread, connection_string) — good enough
    for tests and small deployments; swap for a real pool (e.g.
    psycopg2.pool or pgbouncer in front) for serious concurrent load."""
    key = f"_conn_{connection_string}"
    conn = getattr(_local, key, None)
    if conn is None:
        if _is_postgres_url(connection_string):
            if not _HAS_PSYCOPG2:
                raise RuntimeError(
                    "GUARDIAN_DB_PATH/DATABASE_URL points at Postgres but psycopg2 "
                    "is not installed. Run: pip install psycopg2-binary"
                )
            raw_conn = psycopg2.connect(connection_string)
            conn = _PostgresConnAdapter(raw_conn)
        else:
            conn = sqlite3.connect(connection_string, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON")
        setattr(_local, key, conn)
    return conn


def init_db(connection_string: str) -> None:
    conn = get_connection(connection_string)
    conn.executescript(SCHEMA)
    conn.commit()
