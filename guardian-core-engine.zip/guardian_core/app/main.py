import os
import secrets
import sys

from flask import Flask, request, jsonify, g

from . import services
from .db import get_connection, init_db


def create_app(db_path=None, api_key=None):
    app = Flask(__name__)
    # DATABASE_URL/GUARDIAN_DATABASE_URL (a postgres:// URL) takes
    # priority when set — that's the Postgres path. Otherwise falls
    # back to GUARDIAN_DB_PATH, a plain SQLite file path.
    app.config["DB_PATH"] = (
        db_path
        or os.environ.get("GUARDIAN_DATABASE_URL")
        or os.environ.get("DATABASE_URL")
        or os.environ.get("GUARDIAN_DB_PATH", "guardian.db")
    )
    init_db(app.config["DB_PATH"])

    # ---------- Auth setup ----------
    # Every request (except /health) requires a service-level bearer
    # token. This is a coarse "is this caller allowed to talk to
    # Guardian at all" gate — separate from per-admin identity, which
    # is enforced additionally on approve/reject/acknowledge below.
    configured_key = api_key or os.environ.get("GUARDIAN_API_KEY")
    if not configured_key:
        if os.environ.get("GUARDIAN_ENV") == "production":
            raise RuntimeError(
                "GUARDIAN_API_KEY must be set via environment variable in production — "
                "refusing to start with no service authentication configured"
            )
        configured_key = secrets.token_urlsafe(32)
        app.config["API_KEY_AUTO_GENERATED"] = True
        print(
            f"[guardian] No GUARDIAN_API_KEY set — generated an ephemeral key for this "
            f"run only: {configured_key}",
            file=sys.stderr,
        )
    app.config["API_KEY"] = configured_key

    @app.before_request
    def _require_service_api_key():
        if request.path in ("/health", "/openapi.yaml", "/docs"):
            return None
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"detail": "missing or malformed Authorization header"}), 401
        token = auth_header[len("Bearer "):]
        if not secrets.compare_digest(token, app.config["API_KEY"]):
            return jsonify({"detail": "invalid API key"}), 401
        return None

    def _require_admin():
        """Resolves the calling admin from X-Admin-Api-Key. Returns
        (admin_dict, None) on success or (None, (response, status)) on
        failure — callers must check the second element."""
        raw_key = request.headers.get("X-Admin-Api-Key")
        if not raw_key:
            return None, (jsonify({"detail": "missing X-Admin-Api-Key header"}), 401)
        try:
            admin = services.get_admin_by_api_key(db(), raw_key)
        except services.ForbiddenError as e:
            return None, (jsonify({"detail": str(e)}), 403)
        return admin, None

    def db():
        if "conn" not in g:
            g.conn = get_connection(app.config["DB_PATH"])
        return g.conn

    def handle_errors(fn):
        def wrapper(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except services.NotFoundError as e:
                return jsonify({"detail": str(e)}), 404
            except services.ForbiddenError as e:
                return jsonify({"detail": str(e)}), 403
            except services.InvalidStateError as e:
                return jsonify({"detail": str(e)}), 409
        wrapper.__name__ = fn.__name__
        return wrapper

    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    @app.get("/openapi.yaml")
    def openapi_spec():
        spec_path = os.path.join(os.path.dirname(__file__), "..", "openapi.yaml")
        try:
            with open(spec_path, "r") as f:
                content = f.read()
        except FileNotFoundError:
            return jsonify({"detail": "openapi.yaml not found — run scripts/generate_openapi.py"}), 404
        return app.response_class(content, mimetype="application/yaml")

    @app.get("/docs")
    def docs():
        # Swagger UI loaded from a CDN — needs outbound internet from
        # whoever's BROWSER loads this page (not from the server
        # itself). Fine for internal tooling; self-host swagger-ui-dist
        # instead if this needs to work fully air-gapped.
        html = """<!DOCTYPE html>
<html>
<head>
  <title>Guardian Core Engine — API Docs</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/5.11.0/swagger-ui.min.css">
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/5.11.0/swagger-ui-bundle.min.js"></script>
  <script>
    window.onload = () => {
      SwaggerUIBundle({ url: "/openapi.yaml", dom_id: "#swagger-ui" });
    };
  </script>
</body>
</html>"""
        return app.response_class(html, mimetype="text/html")

    # ---------- Systems ----------

    @app.post("/systems")
    @handle_errors
    def create_system():
        data = request.get_json(force=True)
        system = services.register_system(
            db(),
            system_key=data["system_key"],
            display_name=data["display_name"],
            category=data["category"],
            criticality=data.get("criticality", "medium"),
            trust_level=data.get("trust_level", "standard"),
            permitted_categories=data.get("permitted_categories", []),
            connection_type=data.get("connection_type", "api_poll"),
        )
        return jsonify(system)

    @app.get("/systems")
    def list_systems():
        return jsonify(services.list_systems(db()))

    @app.get("/systems/<system_id>")
    @handle_errors
    def get_system(system_id):
        return jsonify(services.get_system(db(), system_id))

    # ---------- Checks ----------

    @app.post("/checks")
    @handle_errors
    def create_check():
        data = request.get_json(force=True)
        check = services.create_check(
            db(),
            name=data["name"],
            category=data["category"],
            check_logic_ref=data["check_logic_ref"],
            scope=data.get("scope", "single_system"),
            system_id=data.get("system_id"),
            target_module=data.get("target_module"),
            run_frequency=data.get("run_frequency", "hourly"),
            severity_default=data.get("severity_default", "medium"),
            auto_fix_allowed=data.get("auto_fix_allowed", False),
        )
        return jsonify(check)

    @app.get("/checks")
    def list_checks():
        return jsonify(services.list_checks(db()))

    # ---------- Findings ----------

    @app.post("/findings")
    @handle_errors
    def create_finding():
        data = request.get_json(force=True)
        finding = services.create_finding(
            db(),
            check_id=data["check_id"],
            entity_type=data["entity_type"],
            severity=data["severity"],
            summary=data["summary"],
            system_id=data.get("system_id"),
            entity_id=data.get("entity_id"),
            evidence_json=data.get("evidence_json"),
        )
        return jsonify(finding)

    @app.get("/findings")
    def list_findings():
        return jsonify(services.list_findings(db(), status=request.args.get("status")))

    @app.post("/findings/<finding_id>/resolve")
    @handle_errors
    def resolve_finding(finding_id):
        data = request.get_json(force=True)
        finding = services.resolve_finding(
            db(), finding_id,
            resolved_by=data["resolved_by"],
            status=data.get("status", "fixed"),
        )
        return jsonify(finding)

    # ---------- Fix proposals ----------

    @app.post("/fix-proposals")
    @handle_errors
    def create_fix_proposal():
        data = request.get_json(force=True)
        proposal = services.create_fix_proposal(
            db(),
            finding_id=data["finding_id"],
            system_id=data["system_id"],
            proposed_action=data["proposed_action"],
            change_json=data.get("change_json", {}),
            category=data["category"],
            risk_level=data["risk_level"],
        )
        return jsonify(proposal)

    @app.get("/fix-proposals")
    def list_fix_proposals():
        return jsonify(services.list_fix_proposals(db(), status=request.args.get("status")))

    @app.post("/fix-proposals/<proposal_id>/approve")
    @handle_errors
    def approve_fix_proposal(proposal_id):
        admin, err = _require_admin()
        if err:
            return err
        proposal = services.approve_fix_proposal(
            db(), proposal_id, admin_identity_ref=admin["identity_ref"]
        )
        return jsonify(proposal)

    @app.post("/fix-proposals/<proposal_id>/apply")
    @handle_errors
    def apply_fix_proposal(proposal_id):
        proposal = services.apply_fix_proposal(db(), proposal_id)
        return jsonify(proposal)

    @app.post("/fix-proposals/<proposal_id>/reject")
    @handle_errors
    def reject_fix_proposal(proposal_id):
        admin, err = _require_admin()
        if err:
            return err
        data = request.get_json(silent=True) or {}
        proposal = services.reject_fix_proposal(
            db(), proposal_id,
            admin_identity_ref=admin["identity_ref"],
            reason=data.get("reason"),
        )
        return jsonify(proposal)

    # ---------- Admins ----------

    @app.post("/admins")
    @handle_errors
    def create_admin():
        data = request.get_json(force=True)
        admin = services.register_admin_guarded(
            db(),
            identity_ref=data["identity_ref"],
            role=data.get("role", "viewer"),
            system_scope=data.get("system_scope"),
        )
        return jsonify(admin)

    @app.get("/admins")
    def list_admins():
        return jsonify(services.list_admins(db()))

    @app.post("/admins/<identity_ref>/revoke")
    @handle_errors
    def revoke_admin(identity_ref):
        caller, err = _require_admin()
        if err:
            return err
        if caller["role"] != "super_admin":
            return jsonify({"detail": "only a super_admin may revoke admin access"}), 403
        return jsonify(services.revoke_admin(db(), identity_ref))

    # ---------- Action log ----------

    @app.get("/action-log")
    def list_action_log():
        return jsonify(services.list_action_log(db(), system_id=request.args.get("system_id")))

    # ---------- Security incidents ----------

    @app.post("/security-incidents")
    @handle_errors
    def create_security_incident():
        data = request.get_json(force=True)
        incident = services.create_security_incident(
            db(),
            incident_type=data["incident_type"],
            severity=data["severity"],
            system_id=data.get("system_id"),
            actor_ref=data.get("actor_ref"),
            source_ip=data.get("source_ip"),
            auto_response=data.get("auto_response"),
            evidence_json=data.get("evidence_json"),
        )
        return jsonify(incident)

    @app.get("/security-incidents")
    def list_security_incidents():
        return jsonify(services.list_security_incidents(db(), status=request.args.get("status")))

    @app.post("/security-incidents/<incident_id>/resolve")
    @handle_errors
    def resolve_security_incident(incident_id):
        data = request.get_json(silent=True) or {}
        incident = services.resolve_security_incident(
            db(), incident_id, resolved_by=data.get("resolved_by")
        )
        return jsonify(incident)

    # ---------- Escalation policies & events ----------

    @app.post("/escalation-policies")
    @handle_errors
    def create_escalation_policy():
        data = request.get_json(force=True)
        policy = services.create_escalation_policy(
            db(),
            name=data["name"],
            applies_to_severity=data["applies_to_severity"],
            escalation_order=data["escalation_order"],
            system_id=data.get("system_id"),
            step_timeout_minutes=data.get("step_timeout_minutes", 30),
        )
        return jsonify(policy)

    @app.get("/escalation-policies")
    def list_escalation_policies():
        return jsonify(services.list_escalation_policies(db()))

    @app.get("/escalation-events")
    def list_escalation_events():
        return jsonify(services.list_escalation_events(db(), status=request.args.get("status")))

    @app.post("/escalation-events/<event_id>/acknowledge")
    @handle_errors
    def acknowledge_escalation(event_id):
        admin, err = _require_admin()
        if err:
            return err
        event = services.acknowledge_escalation(
            db(), event_id, admin_identity_ref=admin["identity_ref"]
        )
        return jsonify(event)

    @app.post("/process-escalations")
    @handle_errors
    def process_escalations():
        data = request.get_json(silent=True) or {}
        advanced = services.process_escalation_timeouts(db(), now=data.get("now"))
        return jsonify({"advanced_or_exhausted": advanced})

    # ---------- Audio monitoring ----------

    @app.post("/audio-streams")
    @handle_errors
    def create_audio_stream():
        data = request.get_json(force=True)
        stream = services.create_audio_stream(
            db(),
            system_id=data["system_id"],
            source_ref=data["source_ref"],
            channel_count=data.get("channel_count", 1),
            sample_rate_hz=data.get("sample_rate_hz"),
        )
        return jsonify(stream)

    @app.get("/audio-streams")
    def list_audio_streams():
        return jsonify(services.list_audio_streams(db(), system_id=request.args.get("system_id")))

    @app.post("/audio-streams/<stream_id>/end")
    @handle_errors
    def end_audio_stream(stream_id):
        return jsonify(services.end_audio_stream(db(), stream_id))

    @app.get("/audio-streams/<stream_id>/channels")
    @handle_errors
    def list_audio_channels(stream_id):
        return jsonify(services.list_audio_channels(db(), stream_id))

    @app.post("/audio-channels/<channel_id>")
    @handle_errors
    def update_audio_channel(channel_id):
        data = request.get_json(force=True)
        channel = services.update_audio_channel(
            db(), channel_id,
            channel_label=data.get("channel_label"),
            actor_ref=data.get("actor_ref"),
        )
        return jsonify(channel)

    @app.post("/audio-bands")
    @handle_errors
    def create_audio_band():
        data = request.get_json(force=True)
        band = services.create_audio_band(
            db(), name=data["name"], low_hz=data["low_hz"], high_hz=data["high_hz"]
        )
        return jsonify(band)

    @app.get("/audio-bands")
    def list_audio_bands():
        return jsonify(services.list_audio_bands(db()))

    @app.post("/audio-band-metrics")
    @handle_errors
    def record_audio_band_metric():
        data = request.get_json(force=True)
        metric = services.record_audio_band_metric(
            db(),
            channel_id=data["channel_id"],
            band_id=data["band_id"],
            window_start=data["window_start"],
            window_end=data["window_end"],
            avg_level_db=data.get("avg_level_db"),
            peak_level_db=data.get("peak_level_db"),
            noise_floor_db=data.get("noise_floor_db"),
            clipping_ratio=data.get("clipping_ratio"),
            silence_ratio=data.get("silence_ratio"),
        )
        return jsonify(metric)

    @app.get("/audio-channels/<channel_id>/metrics")
    @handle_errors
    def list_audio_band_metrics(channel_id):
        return jsonify(services.list_audio_band_metrics(db(), channel_id))

    @app.post("/audio-findings")
    @handle_errors
    def create_audio_finding():
        data = request.get_json(force=True)
        finding = services.create_audio_finding(
            db(),
            stream_id=data["stream_id"],
            finding_type=data["finding_type"],
            severity=data["severity"],
            summary=data["summary"],
            channel_id=data.get("channel_id"),
            band_id=data.get("band_id"),
            evidence_json=data.get("evidence_json"),
        )
        return jsonify(finding)

    @app.get("/audio-findings")
    def list_audio_findings():
        return jsonify(services.list_audio_findings(
            db(), stream_id=request.args.get("stream_id"), status=request.args.get("status")
        ))

    @app.post("/audio-findings/<finding_id>/resolve")
    @handle_errors
    def resolve_audio_finding(finding_id):
        data = request.get_json(silent=True) or {}
        finding = services.resolve_audio_finding(db(), finding_id, resolved_by=data.get("resolved_by"))
        return jsonify(finding)

    # ---------- Code integrity verification ----------

    @app.post("/code-signatures")
    @handle_errors
    def register_code_signature():
        data = request.get_json(force=True)
        signature = services.register_code_signature(
            db(),
            system_id=data["system_id"],
            component_ref=data["component_ref"],
            expected_hash=data["expected_hash"],
            algorithm=data.get("algorithm", "sha256"),
            registered_by=data.get("registered_by"),
        )
        return jsonify(signature)

    @app.get("/code-signatures")
    def list_code_signatures():
        return jsonify(services.list_code_signatures(
            db(), system_id=request.args.get("system_id"),
            component_ref=request.args.get("component_ref"),
        ))

    @app.post("/integrity-checks")
    @handle_errors
    def verify_code_integrity():
        data = request.get_json(force=True)
        result = services.verify_code_integrity(
            db(),
            system_id=data["system_id"],
            component_ref=data["component_ref"],
            actual_hash=data["actual_hash"],
        )
        return jsonify(result)

    @app.get("/integrity-checks")
    def list_integrity_checks():
        return jsonify(services.list_integrity_checks(
            db(), system_id=request.args.get("system_id"),
            component_ref=request.args.get("component_ref"),
            result=request.args.get("result"),
        ))

    # ---------- Connector registry ----------

    @app.post("/connectors")
    @handle_errors
    def register_connector():
        data = request.get_json(force=True)
        connector = services.register_connector(
            db(),
            connector_key=data["connector_key"],
            display_name=data["display_name"],
            connector_type=data["connector_type"],
            direction=data["direction"],
            authorized_by=data["authorized_by"],
            target_system_id=data.get("target_system_id"),
            capabilities_json=data.get("capabilities_json"),
            version=data.get("version", "1.0"),
            auth_ref=data.get("auth_ref"),
        )
        return jsonify(connector)

    @app.get("/connectors")
    def list_connectors():
        return jsonify(services.list_connectors(db(), connector_type=request.args.get("connector_type")))

    # ---------- Vendor gateway ----------

    @app.post("/vendor-gateway-connectors")
    @handle_errors
    def create_vendor_gateway_connector():
        data = request.get_json(force=True)
        gateway = services.create_vendor_gateway_connector(
            db(),
            connector_id=data["connector_id"],
            vendor_system_id=data["vendor_system_id"],
            data_direction=data["data_direction"],
            exposed_fields=data["exposed_fields"],
            isolation_method=data["isolation_method"],
            never_exposes_internal_ref=data.get("never_exposes_internal_ref"),
        )
        return jsonify(gateway)

    @app.get("/vendor-gateway-connectors")
    def list_vendor_gateway_connectors():
        return jsonify(services.list_vendor_gateway_connectors(
            db(), vendor_system_id=request.args.get("vendor_system_id")
        ))

    # ---------- Sensors ----------

    @app.post("/sensors")
    @handle_errors
    def register_sensor():
        data = request.get_json(force=True)
        sensor = services.register_sensor(
            db(),
            sensor_key=data["sensor_key"],
            sensor_type=data["sensor_type"],
            system_id=data["system_id"],
            connector_id=data.get("connector_id"),
            capabilities_json=data.get("capabilities_json"),
        )
        return jsonify(sensor)

    @app.get("/sensors")
    def list_sensors():
        return jsonify(services.list_sensors(
            db(), system_id=request.args.get("system_id"), sensor_type=request.args.get("sensor_type")
        ))

    @app.post("/sensor-events")
    @handle_errors
    def record_sensor_event():
        data = request.get_json(force=True)
        result = services.record_sensor_event(
            db(),
            sensor_id=data["sensor_id"],
            event_type=data["event_type"],
            severity=data.get("severity", "info"),
            payload_json=data.get("payload_json"),
        )
        return jsonify(result)

    @app.get("/sensor-events")
    def list_sensor_events():
        return jsonify(services.list_sensor_events(db(), sensor_id=request.args.get("sensor_id")))

    # ---------- C2 integration ----------

    @app.post("/c2-integrations")
    @handle_errors
    def create_c2_integration():
        data = request.get_json(force=True)
        integration = services.create_c2_integration(
            db(),
            connector_id=data["connector_id"],
            c2_system_name=data["c2_system_name"],
            data_scope=data["data_scope"],
            role=data.get("role", "upstream_command"),
            accepts_directives=data.get("accepts_directives", False),
        )
        return jsonify(integration)

    @app.post("/c2-integrations/<integration_id>/publish")
    @handle_errors
    def publish_to_c2(integration_id):
        data = request.get_json(force=True)
        log_entry = services.publish_to_c2(
            db(), integration_id,
            payload_summary=data["payload_summary"],
            reference_table=data.get("reference_table"),
            reference_id=data.get("reference_id"),
        )
        return jsonify(log_entry)

    @app.post("/c2-integrations/<integration_id>/directive")
    @handle_errors
    def receive_c2_directive(integration_id):
        data = request.get_json(force=True)
        proposal = services.receive_c2_directive(
            db(), integration_id,
            finding_id=data["finding_id"],
            system_id=data["system_id"],
            proposed_action=data["proposed_action"],
            change_json=data.get("change_json", {}),
            category=data["category"],
            risk_level=data["risk_level"],
        )
        return jsonify(proposal)

    @app.get("/c2-sync-log")
    def list_c2_sync_log():
        return jsonify(services.list_c2_sync_log(db(), integration_id=request.args.get("integration_id")))

    # ---------- Health & risk scoring ----------

    @app.post("/systems/<system_id>/health-score")
    @handle_errors
    def compute_system_health_score(system_id):
        return jsonify(services.compute_system_health_score(db(), system_id))

    @app.get("/systems/<system_id>/health-scores")
    @handle_errors
    def list_system_health_scores(system_id):
        return jsonify(services.list_system_health_scores(db(), system_id))

    @app.post("/ecosystem-risk-score")
    @handle_errors
    def compute_ecosystem_risk_score():
        return jsonify(services.compute_ecosystem_risk_score(db()))

    @app.get("/ecosystem-risk-scores")
    def list_ecosystem_risk_scores():
        return jsonify(services.list_ecosystem_risk_scores(db()))

    # ---------- Rate limiting ----------

    @app.post("/rate-limits")
    @handle_errors
    def set_rate_limit():
        data = request.get_json(force=True)
        limit = services.set_rate_limit(
            db(),
            max_events_per_minute=data["max_events_per_minute"],
            system_id=data.get("system_id"),
            sensor_id=data.get("sensor_id"),
        )
        return jsonify(limit)

    @app.get("/rate-limits/status")
    @handle_errors
    def get_rate_limit_status():
        return jsonify(services.get_rate_limit_status(
            db(), system_id=request.args.get("system_id"), sensor_id=request.args.get("sensor_id")
        ))

    return app


if __name__ == "__main__":
    application = create_app()
    application.run(debug=True, port=8000)
