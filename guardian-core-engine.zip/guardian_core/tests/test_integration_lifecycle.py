"""
Full-lifecycle integration test. Unlike the other test files (which
test one module's rules in isolation), this simulates one coherent
story end to end, the way an actual deployment would be used:

  1. Ops registers a system and a couple of admins.
  2. A monitoring check fires a finding.
  3. A low-risk fix auto-applies; a high-risk one requires approval,
     is spoofing-resistant, and only applies after real approval.
  4. A critical security incident fires, triggers escalation,
     times out once, then gets acknowledged.
  5. A code integrity mismatch is detected and creates its own
     incident.
  6. A vendor gateway is set up with real isolation constraints.
  7. A sensor sends events, one of which trips the rate limiter.
  8. Everything gets rolled into a health score and an ecosystem
     risk score.
  9. The action log has a complete, coherent trail of everything
     above.

If any module's wiring to another module is subtly broken (e.g. a
health score not reflecting a resolved finding, or a fix proposal
losing its audit trail), this test is where it would show up — the
per-module tests only prove each module works alone.
"""

import os
import sys
import json
import tempfile
import unittest
from datetime import datetime, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import create_app  # noqa: E402

try:
    from _helpers import AuthClient
except ImportError:
    from tests._helpers import AuthClient

TEST_API_KEY = "lifecycle-test-key"


class TestFullIncidentLifecycle(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(db_path=self.db_path, api_key=TEST_API_KEY)
        self.client = AuthClient(self.app.test_client(), TEST_API_KEY)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def post(self, path, payload=None, headers=None):
        return self.client.post(path, data=json.dumps(payload or {}),
                                 content_type="application/json", headers=headers)

    def get(self, path):
        return self.client.get(path)

    def test_full_lifecycle(self):
        # ---------- 1. Ops sets up the system and people ----------
        system = self.post("/systems", {
            "system_key": "ugaforce_hr", "display_name": "UGAFORCE-HR",
            "category": "hr", "criticality": "high",
            "permitted_categories": ["data_quality"],
            "connection_type": "db_direct",
        }).get_json()

        super_admin = self.post("/admins", {
            "identity_ref": "cto@example.com", "role": "super_admin",
        }).get_json()
        on_call = self.post("/admins", {
            "identity_ref": "oncall@example.com", "role": "approver",
        }).get_json()

        # ---------- 2. A check fires findings ----------
        dup_check = self.post("/checks", {
            "name": "Duplicate employee records", "category": "data_quality",
            "system_id": system["id"], "check_logic_ref": "dup_emp_v1",
            "auto_fix_allowed": True,
        }).get_json()

        low_finding = self.post("/findings", {
            "check_id": dup_check["id"], "system_id": system["id"],
            "entity_type": "employee", "severity": "low",
            "summary": "Malformed phone number on employee #4471",
        }).get_json()

        high_finding = self.post("/findings", {
            "check_id": dup_check["id"], "system_id": system["id"],
            "entity_type": "employee", "severity": "medium",
            "summary": "Two employee records share a national ID",
        }).get_json()

        # ---------- 3a. Low-risk fix auto-applies ----------
        auto_proposal = self.post("/fix-proposals", {
            "finding_id": low_finding["id"], "system_id": system["id"],
            "proposed_action": "normalize phone number format",
            "change_json": {"before": "0771-234-567", "after": "+256771234567"},
            "category": "data_quality", "risk_level": "low",
        }).get_json()
        self.assertTrue(auto_proposal["auto_applied"])
        self.assertEqual(auto_proposal["status"], "applied")

        # ---------- 3b. High-risk fix requires real approval ----------
        merge_proposal = self.post("/fix-proposals", {
            "finding_id": high_finding["id"], "system_id": system["id"],
            "proposed_action": "merge duplicate employee records",
            "change_json": {"merge": ["emp_4471", "emp_9981"]},
            "category": "data_quality", "risk_level": "high",
        }).get_json()
        self.assertTrue(merge_proposal["requires_approval"])
        self.assertEqual(merge_proposal["status"], "pending")

        # Spoofing attempt: claiming to be the super_admin via body text
        # alone, no key, must fail and leave the proposal untouched.
        spoofed = self.post(f"/fix-proposals/{merge_proposal['id']}/approve", {
            "admin_identity_ref": "cto@example.com",
        })
        self.assertEqual(spoofed.status_code, 401)

        # Real approval, with the real key.
        approved = self.post(f"/fix-proposals/{merge_proposal['id']}/approve", {},
                              headers={"X-Admin-Api-Key": super_admin["api_key"]})
        self.assertEqual(approved.status_code, 200)
        self.assertEqual(approved.get_json()["status"], "approved")

        applied = self.post(f"/fix-proposals/{merge_proposal['id']}/apply")
        self.assertEqual(applied.get_json()["status"], "applied")

        # Resolve the findings now that their fixes are in.
        self.post(f"/findings/{low_finding['id']}/resolve", {"resolved_by": "system", "status": "fixed"})
        self.post(f"/findings/{high_finding['id']}/resolve", {"resolved_by": "cto@example.com", "status": "fixed"})

        # ---------- 4. Security incident triggers escalation ----------
        self.post("/escalation-policies", {
            "name": "HR critical incidents", "applies_to_severity": "critical",
            "system_id": system["id"],
            "escalation_order": ["oncall@example.com", "cto@example.com"],
            "step_timeout_minutes": 10,
        })

        incident = self.post("/security-incidents", {
            "incident_type": "brute_force", "severity": "critical",
            "system_id": system["id"], "auto_response": "account_locked",
        }).get_json()

        events = self.get("/escalation-events").get_json()
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["notified_ref"], "oncall@example.com")

        # Simulate the on-call missing the window — escalates to the CTO.
        future = (datetime.fromisoformat(events[0]["notified_at"]) + timedelta(minutes=15)).isoformat()
        self.post("/process-escalations", {"now": future})
        events = self.get("/escalation-events").get_json()
        self.assertEqual(events[0]["notified_ref"], "cto@example.com")

        # CTO acknowledges.
        ack = self.post(f"/escalation-events/{events[0]['id']}/acknowledge", {},
                         headers={"X-Admin-Api-Key": super_admin["api_key"]})
        self.assertEqual(ack.get_json()["status"], "acknowledged")

        self.post(f"/security-incidents/{incident['id']}/resolve", {"resolved_by": "cto@example.com"})

        # ---------- 5. Code integrity check catches tampering ----------
        good_hash = "a" * 64
        bad_hash = "f" * 64
        self.post("/code-signatures", {
            "system_id": system["id"], "component_ref": "app/payroll_calc.py",
            "expected_hash": good_hash, "registered_by": "ci@example.com",
        })
        integrity_result = self.post("/integrity-checks", {
            "system_id": system["id"], "component_ref": "app/payroll_calc.py",
            "actual_hash": bad_hash,
        }).get_json()
        self.assertEqual(integrity_result["result"], "mismatch")
        integrity_incident_id = integrity_result["linked_security_incident_id"]
        self.assertIsNotNone(integrity_incident_id)

        # ---------- 6. Vendor gateway, correctly isolated ----------
        vendor_system = self.post("/systems", {
            "system_key": "payroll_vendor", "display_name": "Payroll Vendor Co",
            "category": "vendor",
        }).get_json()
        connector = self.post("/connectors", {
            "connector_key": "payroll_vendor_gateway", "display_name": "Payroll Vendor Gateway",
            "connector_type": "vendor_gateway", "direction": "outbound",
            "authorized_by": "cto@example.com",
        }).get_json()
        gateway = self.post("/vendor-gateway-connectors", {
            "connector_id": connector["id"], "vendor_system_id": vendor_system["id"],
            "data_direction": "guardian_pushes_alerts_to_vendor",
            "exposed_fields": ["alert_summary", "severity"],
            "isolation_method": "one_way_webhook",
        }).get_json()
        self.assertEqual(gateway["isolation_method"], "one_way_webhook")

        # The vendor system can never be granted admin scope.
        blocked = self.post("/admins", {
            "identity_ref": "vendor-contact@example.com", "role": "approver",
            "system_scope": [vendor_system["id"]],
        })
        self.assertEqual(blocked.status_code, 403)

        # ---------- 7. Sensor events, one throttled ----------
        sensor = self.post("/sensors", {
            "sensor_key": "hr_audit_feed", "sensor_type": "log_feed", "system_id": system["id"],
        }).get_json()
        self.post("/rate-limits", {"sensor_id": sensor["id"], "max_events_per_minute": 2})

        accepted_flags = []
        for _ in range(4):
            r = self.post("/sensor-events", {
                "sensor_id": sensor["id"], "event_type": "audit_entry",
            })
            accepted_flags.append(r.get_json()["accepted"])
        self.assertEqual(accepted_flags, [True, True, False, False])

        # ---------- 8. Health and ecosystem risk scoring ----------
        health = self.post(f"/systems/{system['id']}/health-score").get_json()
        # By this point: both HR findings resolved, one HR incident
        # resolved, plus the integrity-check incident is still OPEN
        # against this same system — one open incident costs 15.
        self.assertEqual(health["score"], 85.0)

        risk = self.post("/ecosystem-risk-score").get_json()
        self.assertIn("systems_included", risk)
        self.assertGreaterEqual(risk["systems_included"], 2)  # hr + vendor system both registered

        # ---------- 9. The action log tells a coherent story ----------
        log = self.get(f"/action-log?system_id={system['id']}").get_json()
        action_types = {entry["action_type"] for entry in log}
        expected_actions = {
            "finding_created", "fix_auto_applied", "fix_proposal_created",
            "fix_approved", "fix_applied", "finding_resolved",
            "security_incident_created", "escalation_triggered",
            "escalation_advanced", "escalation_acknowledged",
            "security_incident_resolved", "integrity_check_performed",
        }
        missing = expected_actions - action_types
        self.assertEqual(missing, set(), f"expected actions missing from log: {missing}")

        # Resolve the integrity incident to close the loop cleanly.
        self.post(f"/security-incidents/{integrity_incident_id}/resolve", {"resolved_by": "cto@example.com"})
        final_health = self.post(f"/systems/{system['id']}/health-score").get_json()
        self.assertEqual(final_health["score"], 100.0)


if __name__ == "__main__":
    unittest.main()
