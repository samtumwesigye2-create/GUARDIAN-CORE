"""
Validates the Postgres backend actually works — not just that the
adapter code exists. This test is SKIPPED automatically unless both:
  1. psycopg2 is importable, and
  2. GUARDIAN_TEST_POSTGRES_URL is set to a reachable Postgres instance
     (e.g. postgresql://guardian:guardian@localhost:5432/guardian_test)

Neither condition holds in the sandbox this was built in (no network
access to install psycopg2, no Postgres server available) — this file
exists so CI or a local machine WITH Postgres can actually prove the
backend works, rather than trusting the adapter code by inspection
alone. Run it with:

    docker run -d -e POSTGRES_PASSWORD=guardian -e POSTGRES_USER=guardian \\
        -e POSTGRES_DB=guardian_test -p 5432:5432 postgres:16
    export GUARDIAN_TEST_POSTGRES_URL=postgresql://guardian:guardian@localhost:5432/guardian_test
    python -m unittest tests.test_postgres_backend -v
"""

import json
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

try:
    import psycopg2
    _HAS_PSYCOPG2 = True
except ImportError:
    _HAS_PSYCOPG2 = False

_TEST_PG_URL = os.environ.get("GUARDIAN_TEST_POSTGRES_URL")

_SKIP_REASON = (
    "requires psycopg2 installed AND GUARDIAN_TEST_POSTGRES_URL pointing "
    "at a real, reachable Postgres instance — see this file's docstring"
)


@unittest.skipUnless(_HAS_PSYCOPG2 and _TEST_PG_URL, _SKIP_REASON)
class TestPostgresBackend(unittest.TestCase):
    def setUp(self):
        from app.main import create_app
        # Each test run truncates its own tables via a fresh schema
        # apply — init_db uses CREATE TABLE IF NOT EXISTS, so previous
        # runs' rows would otherwise leak across test runs. We DROP
        # first for a clean slate.
        conn = psycopg2.connect(_TEST_PG_URL)
        cur = conn.cursor()
        cur.execute("""
            DO $$ DECLARE r RECORD;
            BEGIN
                FOR r IN (SELECT tablename FROM pg_tables
                          WHERE schemaname = 'public' AND tablename LIKE 'guardian_%')
                LOOP
                    EXECUTE 'DROP TABLE IF EXISTS ' || quote_ident(r.tablename) || ' CASCADE';
                END LOOP;
            END $$;
        """)
        conn.commit()
        cur.close()
        conn.close()

        self.app = create_app(db_path=_TEST_PG_URL, api_key="pg-test-key")
        self.client = self.app.test_client()
        self.headers = {"Authorization": "Bearer pg-test-key"}

    def post(self, path, payload, extra_headers=None):
        headers = dict(self.headers)
        headers.update(extra_headers or {})
        return self.client.post(path, data=json.dumps(payload),
                                 content_type="application/json", headers=headers)

    def get(self, path):
        return self.client.get(path, headers=self.headers)

    def test_health_check(self):
        r = self.client.get("/health")
        self.assertEqual(r.status_code, 200)

    def test_full_round_trip_against_real_postgres(self):
        """The same core lifecycle as the SQLite tests, run against a
        real Postgres instance — proves the adapter's placeholder
        translation and RealDictCursor row handling actually work,
        not just that they compile."""
        system = self.post("/systems", {
            "system_key": "pg_test_system", "display_name": "PG Test",
            "category": "test", "permitted_categories": ["data_quality"],
        }).get_json()
        self.assertEqual(system["system_key"], "pg_test_system")

        admin = self.post("/admins", {"identity_ref": "pg-admin@example.com", "role": "super_admin"}).get_json()
        self.assertTrue(admin["api_key"].startswith("gdn_"))

        check = self.post("/checks", {
            "name": "pg check", "category": "data_quality",
            "system_id": system["id"], "check_logic_ref": "ref",
        }).get_json()

        finding = self.post("/findings", {
            "check_id": check["id"], "system_id": system["id"],
            "entity_type": "x", "severity": "low", "summary": "pg finding",
        }).get_json()
        self.assertEqual(finding["status"], "open")

        proposal = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "fix it", "change_json": {"a": 1},
            "category": "data_quality", "risk_level": "low",
        }).get_json()
        self.assertTrue(proposal["auto_applied"])  # low risk + permitted category

        health = self.post(f"/systems/{system['id']}/health-score", {}).get_json()
        self.assertEqual(health["score"], 100.0)

        log = self.get(f"/action-log?system_id={system['id']}").get_json()
        self.assertGreaterEqual(len(log), 2)  # finding_created + fix_auto_applied at least

    def test_unique_constraint_enforced_by_postgres(self):
        self.post("/systems", {"system_key": "dup_test", "display_name": "A", "category": "x"})
        r = self.post("/systems", {"system_key": "dup_test", "display_name": "B", "category": "x"})
        self.assertEqual(r.status_code, 409)


if __name__ == "__main__":
    unittest.main()
