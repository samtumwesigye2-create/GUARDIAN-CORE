import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import create_app  # noqa: E402


class DocsTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(db_path=self.db_path, api_key="docs-test-key")
        self.client = self.app.test_client()

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_openapi_spec_served_without_auth(self):
        r = self.client.get("/openapi.yaml")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"openapi:", r.get_data())

    def test_docs_page_served_without_auth(self):
        r = self.client.get("/docs")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"swagger-ui", r.get_data())

    def test_openapi_spec_is_valid_yaml_with_expected_top_level_keys(self):
        import yaml
        r = self.client.get("/openapi.yaml")
        spec = yaml.safe_load(r.get_data())
        self.assertEqual(spec["openapi"], "3.0.3")
        self.assertIn("paths", spec)
        self.assertIn("components", spec)
        self.assertIn("/systems", spec["paths"])

    def test_other_endpoints_still_require_auth(self):
        r = self.client.get("/systems")
        self.assertEqual(r.status_code, 401)


if __name__ == "__main__":
    unittest.main()
