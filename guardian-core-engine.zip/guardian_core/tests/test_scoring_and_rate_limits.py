import os
import sys
import json
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import create_app  # noqa: E402

try:
    from _helpers import AuthClient
except ImportError:
    from tests._helpers import AuthClient

TEST_API_KEY = "test-service-key"


class ScoringTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(db_path=self.db_path, api_key=TEST_API_KEY)
        self.client = AuthClient(self.app.test_client(), TEST_API_KEY)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def post(self, path, payload, headers=None):
        return self.client.post(path, data=json.dumps(payload), content_type="application/json",
                                 headers=headers)

    def make_system(self, **overrides):
        payload = {"system_key": "ugaforce_hr", "display_name": "HR", "category": "hr"}
        payload.update(overrides)
        r = self.post("/systems", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def make_finding(self, system_id, severity="medium"):
        check = self.post("/checks", {
            "name": "c", "category": "data_quality", "system_id": system_id, "check_logic_ref": "r",
        }).get_json()
        return self.post("/findings", {
            "check_id": check["id"], "system_id": system_id, "entity_type": "x",
            "severity": severity, "summary": "s",
        }).get_json()


class TestSystemHealthScore(ScoringTestCase):
    def test_perfect_score_with_no_issues(self):
        system = self.make_system()
        r = self.post(f"/systems/{system['id']}/health-score", {})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["score"], 100.0)

    def test_score_drops_with_open_findings(self):
        system = self.make_system()
        for _ in range(3):
            self.make_finding(system["id"])
        r = self.post(f"/systems/{system['id']}/health-score", {})
        score = r.get_json()
        self.assertEqual(score["score"], 85.0)  # 100 - (3 * 5)
        self.assertEqual(score["open_findings_weight"], 15.0)

    def test_resolved_findings_dont_count_against_score(self):
        system = self.make_system()
        finding = self.make_finding(system["id"])
        self.post(f"/findings/{finding['id']}/resolve", {"resolved_by": "x@example.com"})
        r = self.post(f"/systems/{system['id']}/health-score", {})
        self.assertEqual(r.get_json()["score"], 100.0)

    def test_security_incidents_weighted_more_heavily(self):
        system = self.make_system()
        self.post("/security-incidents", {
            "incident_type": "brute_force", "severity": "high", "system_id": system["id"],
        })
        r = self.post(f"/systems/{system['id']}/health-score", {})
        score = r.get_json()
        self.assertEqual(score["score"], 85.0)  # 100 - 15
        self.assertEqual(score["security_weight"], 15.0)

    def test_score_history_is_listable(self):
        system = self.make_system()
        self.post(f"/systems/{system['id']}/health-score", {})
        self.make_finding(system["id"])
        self.post(f"/systems/{system['id']}/health-score", {})
        history = self.client.get(f"/systems/{system['id']}/health-scores").get_json()
        self.assertEqual(len(history), 2)


class TestEcosystemRiskScore(ScoringTestCase):
    def test_no_systems_rejected(self):
        r = self.post("/ecosystem-risk-score", {})
        self.assertEqual(r.status_code, 409)

    def test_healthy_ecosystem_has_low_risk(self):
        self.make_system(system_key="sys_a")
        self.make_system(system_key="sys_b")
        r = self.post("/ecosystem-risk-score", {})
        self.assertEqual(r.status_code, 200)
        result = r.get_json()
        self.assertEqual(result["score"], 0.0)
        self.assertEqual(result["systems_included"], 2)

    def test_one_unhealthy_system_raises_ecosystem_risk(self):
        healthy = self.make_system(system_key="sys_a")
        unhealthy = self.make_system(system_key="sys_b")
        for _ in range(4):
            self.make_finding(unhealthy["id"])  # 100 - 20 = 80 health -> 20 deficit

        r = self.post("/ecosystem-risk-score", {})
        result = r.get_json()
        # average deficit across 2 systems: (0 + 20) / 2 = 10
        self.assertEqual(result["score"], 10.0)
        factors = {f["system_key"]: f for f in result["contributing_factors_json"]}
        self.assertEqual(factors["sys_b"]["health_score"], 80.0)
        self.assertEqual(factors["sys_a"]["health_score"], 100.0)


class TestRateLimiting(ScoringTestCase):
    def test_set_and_get_status(self):
        system = self.make_system()
        self.post("/rate-limits", {"system_id": system["id"], "max_events_per_minute": 10})
        status = self.client.get(f"/rate-limits/status?system_id={system['id']}").get_json()
        self.assertEqual(status["max_events_per_minute"], 10)
        self.assertFalse(status["is_throttled"])

    def test_invalid_limit_rejected(self):
        system = self.make_system()
        r = self.post("/rate-limits", {"system_id": system["id"], "max_events_per_minute": 0})
        self.assertEqual(r.status_code, 409)

    def test_status_for_unconfigured_scope_404s(self):
        system = self.make_system()
        r = self.client.get(f"/rate-limits/status?system_id={system['id']}")
        self.assertEqual(r.status_code, 404)


if __name__ == "__main__":
    unittest.main()
