"""Shared helpers for tests. All test files use AuthClient instead of
the raw Flask test client, since every endpoint (except /health) now
requires a service-level bearer token."""


class AuthClient:
    """Wraps a Flask test client, injecting the Authorization header
    on every request so existing test call sites (`self.client.get(...)`,
    `self.client.post(...)`) don't need to change beyond how they're
    constructed in setUp."""

    def __init__(self, flask_test_client, api_key):
        self._client = flask_test_client
        self._auth_headers = {"Authorization": f"Bearer {api_key}"}

    def _merge_headers(self, kwargs):
        headers = dict(self._auth_headers)
        headers.update(kwargs.pop("headers", {}) or {})
        kwargs["headers"] = headers
        return kwargs

    def get(self, path, **kwargs):
        return self._client.get(path, **self._merge_headers(kwargs))

    def post(self, path, **kwargs):
        return self._client.post(path, **self._merge_headers(kwargs))

    def put(self, path, **kwargs):
        return self._client.put(path, **self._merge_headers(kwargs))

    def delete(self, path, **kwargs):
        return self._client.delete(path, **self._merge_headers(kwargs))
