import os
import sys
import json
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import create_app  # noqa: E402

try:
    from _helpers import AuthClient
except ImportError:
    from tests._helpers import AuthClient

TEST_API_KEY = "test-service-key"

GOOD_HASH = "a" * 64
BAD_HASH = "b" * 64


class IntegrityTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(db_path=self.db_path, api_key=TEST_API_KEY)
        self.client = AuthClient(self.app.test_client(), TEST_API_KEY)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def post(self, path, payload, headers=None):
        return self.client.post(path, data=json.dumps(payload), content_type="application/json",
                                 headers=headers)

    def make_system(self, **overrides):
        payload = {
            "system_key": "tax_filing", "display_name": "Tax Filing App",
            "category": "finance", "permitted_categories": [],
        }
        payload.update(overrides)
        r = self.post("/systems", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()


class TestSignatureRegistration(IntegrityTestCase):
    def test_register_signature(self):
        system = self.make_system()
        r = self.post("/code-signatures", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "expected_hash": GOOD_HASH, "registered_by": "ci@example.com",
        })
        self.assertEqual(r.status_code, 200)
        sig = r.get_json()
        self.assertTrue(sig["is_active"])
        self.assertEqual(sig["algorithm"], "sha256")

    def test_reregistering_deactivates_previous_signature(self):
        system = self.make_system()
        self.post("/code-signatures", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "expected_hash": GOOD_HASH,
        })
        self.post("/code-signatures", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "expected_hash": BAD_HASH,  # new legit release, new hash
        })
        sigs = self.client.get(
            f"/code-signatures?system_id={system['id']}&component_ref=app/services.py"
        ).get_json()
        active = [s for s in sigs if s["is_active"]]
        self.assertEqual(len(active), 1)
        self.assertEqual(active[0]["expected_hash"], BAD_HASH)


class TestIntegrityVerification(IntegrityTestCase):
    def test_matching_hash_passes(self):
        system = self.make_system()
        self.post("/code-signatures", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "expected_hash": GOOD_HASH,
        })
        r = self.post("/integrity-checks", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "actual_hash": GOOD_HASH,
        })
        self.assertEqual(r.status_code, 200)
        result = r.get_json()
        self.assertEqual(result["result"], "match")
        self.assertIsNone(result["linked_security_incident_id"])

    def test_mismatched_hash_creates_critical_incident(self):
        system = self.make_system()
        self.post("/code-signatures", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "expected_hash": GOOD_HASH,
        })
        r = self.post("/integrity-checks", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "actual_hash": BAD_HASH,
        })
        self.assertEqual(r.status_code, 200)
        result = r.get_json()
        self.assertEqual(result["result"], "mismatch")
        self.assertIsNotNone(result["linked_security_incident_id"])

        incidents = self.client.get("/security-incidents").get_json()
        self.assertEqual(len(incidents), 1)
        self.assertEqual(incidents[0]["incident_type"], "code_integrity_violation")
        self.assertEqual(incidents[0]["severity"], "critical")

    def test_no_baseline_registered_reports_no_baseline(self):
        system = self.make_system()
        r = self.post("/integrity-checks", {
            "system_id": system["id"], "component_ref": "app/never_registered.py",
            "actual_hash": GOOD_HASH,
        })
        self.assertEqual(r.status_code, 200)
        result = r.get_json()
        self.assertEqual(result["result"], "no_baseline")
        self.assertIsNone(result["linked_security_incident_id"])
        # no incident should be created just for a missing baseline
        self.assertEqual(len(self.client.get("/security-incidents").get_json()), 0)

    def test_verification_against_unknown_system_rejected(self):
        r = self.post("/integrity-checks", {
            "system_id": "does-not-exist", "component_ref": "x", "actual_hash": GOOD_HASH,
        })
        self.assertEqual(r.status_code, 404)

    def test_checks_are_logged_and_listable(self):
        system = self.make_system()
        self.post("/code-signatures", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "expected_hash": GOOD_HASH,
        })
        self.post("/integrity-checks", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "actual_hash": GOOD_HASH,
        })
        self.post("/integrity-checks", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "actual_hash": BAD_HASH,
        })
        checks = self.client.get(f"/integrity-checks?system_id={system['id']}").get_json()
        self.assertEqual(len(checks), 2)
        results = {c["result"] for c in checks}
        self.assertEqual(results, {"match", "mismatch"})

    def test_filter_checks_by_result(self):
        system = self.make_system()
        self.post("/code-signatures", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "expected_hash": GOOD_HASH,
        })
        self.post("/integrity-checks", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "actual_hash": BAD_HASH,
        })
        mismatches = self.client.get("/integrity-checks?result=mismatch").get_json()
        self.assertEqual(len(mismatches), 1)

    def test_rotated_signature_is_used_for_new_checks(self):
        system = self.make_system()
        self.post("/code-signatures", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "expected_hash": GOOD_HASH,
        })
        # legitimate new release rotates the expected hash
        self.post("/code-signatures", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "expected_hash": BAD_HASH,
        })
        # checking against the OLD hash should now be a mismatch
        r = self.post("/integrity-checks", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "actual_hash": GOOD_HASH,
        })
        self.assertEqual(r.get_json()["result"], "mismatch")
        # checking against the NEW hash should match
        r = self.post("/integrity-checks", {
            "system_id": system["id"], "component_ref": "app/services.py",
            "actual_hash": BAD_HASH,
        })
        self.assertEqual(r.get_json()["result"], "match")


if __name__ == "__main__":
    unittest.main()
