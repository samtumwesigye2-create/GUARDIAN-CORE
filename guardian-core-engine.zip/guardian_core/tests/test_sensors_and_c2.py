import os
import sys
import json
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import create_app  # noqa: E402

try:
    from _helpers import AuthClient
except ImportError:
    from tests._helpers import AuthClient

TEST_API_KEY = "test-service-key"


class SensorC2TestCase(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(db_path=self.db_path, api_key=TEST_API_KEY)
        self.client = AuthClient(self.app.test_client(), TEST_API_KEY)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def post(self, path, payload, headers=None):
        return self.client.post(path, data=json.dumps(payload), content_type="application/json",
                                 headers=headers)

    def make_system(self, **overrides):
        payload = {"system_key": "badge_readers", "display_name": "Badge Readers", "category": "physical_security"}
        payload.update(overrides)
        r = self.post("/systems", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def make_connector(self, **overrides):
        payload = {
            "connector_key": "sensor_link", "display_name": "Sensor Link",
            "connector_type": "sensor_feed", "direction": "inbound",
            "authorized_by": "security-lead@example.com",
        }
        payload.update(overrides)
        r = self.post("/connectors", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def make_sensor(self, system_id, **overrides):
        payload = {"sensor_key": "lobby_badge_reader", "sensor_type": "badge_reader", "system_id": system_id}
        payload.update(overrides)
        r = self.post("/sensors", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()


class TestSensorRegistry(SensorC2TestCase):
    def test_register_and_list_sensor(self):
        system = self.make_system()
        sensor = self.make_sensor(system["id"])
        self.assertEqual(sensor["sensor_type"], "badge_reader")

        sensors = self.client.get(f"/sensors?system_id={system['id']}").get_json()
        self.assertEqual(len(sensors), 1)

    def test_duplicate_sensor_key_rejected(self):
        system = self.make_system()
        self.make_sensor(system["id"])
        r = self.post("/sensors", {
            "sensor_key": "lobby_badge_reader", "sensor_type": "badge_reader", "system_id": system["id"],
        })
        self.assertEqual(r.status_code, 409)


class TestSensorEvents(SensorC2TestCase):
    def test_record_and_list_event(self):
        system = self.make_system()
        sensor = self.make_sensor(system["id"])
        r = self.post("/sensor-events", {
            "sensor_id": sensor["id"], "event_type": "badge_denied", "severity": "medium",
            "payload_json": {"badge_id": "12345"},
        })
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.get_json()["accepted"])

        events = self.client.get(f"/sensor-events?sensor_id={sensor['id']}").get_json()
        self.assertEqual(len(events), 1)

    def test_events_beyond_rate_limit_are_throttled(self):
        system = self.make_system()
        sensor = self.make_sensor(system["id"])
        self.post("/rate-limits", {"sensor_id": sensor["id"], "max_events_per_minute": 3})

        results = []
        for _ in range(5):
            r = self.post("/sensor-events", {
                "sensor_id": sensor["id"], "event_type": "heartbeat",
            })
            results.append(r.get_json()["accepted"])

        self.assertEqual(results, [True, True, True, False, False])

        status = self.client.get(f"/rate-limits/status?sensor_id={sensor['id']}").get_json()
        self.assertTrue(status["is_throttled"])


class TestC2Integration(SensorC2TestCase):
    def make_c2(self, accepts_directives=False, **overrides):
        connector = self.make_connector(connector_key="c2_link", connector_type="c2_link")
        payload = {
            "connector_id": connector["id"], "c2_system_name": "sensor_fusion",
            "data_scope": ["findings", "sensor_events"], "accepts_directives": accepts_directives,
        }
        payload.update(overrides)
        r = self.post("/c2-integrations", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def test_create_and_publish(self):
        integration = self.make_c2()
        r = self.post(f"/c2-integrations/{integration['id']}/publish", {
            "payload_summary": "3 new findings this hour",
        })
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["direction"], "published")

        log = self.client.get(f"/c2-sync-log?integration_id={integration['id']}").get_json()
        self.assertEqual(len(log), 1)

    def test_directive_rejected_if_integration_does_not_accept_directives(self):
        integration = self.make_c2(accepts_directives=False)
        system = self.make_system()
        check = self.post("/checks", {
            "name": "c", "category": "security", "system_id": system["id"], "check_logic_ref": "r",
        }).get_json()
        finding = self.post("/findings", {
            "check_id": check["id"], "system_id": system["id"], "entity_type": "x",
            "severity": "high", "summary": "s",
        }).get_json()

        r = self.post(f"/c2-integrations/{integration['id']}/directive", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "lock account", "category": "security", "risk_level": "high",
        })
        self.assertEqual(r.status_code, 403)

    def test_directive_always_becomes_fix_proposal_never_auto_applied(self):
        integration = self.make_c2(accepts_directives=True)
        system = self.make_system(permitted_categories=["security"])
        check = self.post("/checks", {
            "name": "c", "category": "security", "system_id": system["id"], "check_logic_ref": "r",
        }).get_json()
        finding = self.post("/findings", {
            "check_id": check["id"], "system_id": system["id"], "entity_type": "x",
            "severity": "high", "summary": "s",
        }).get_json()

        # Even a "low risk, permitted category" directive from C2 goes
        # through create_fix_proposal's normal rules — if it WOULD
        # auto-apply under those rules it's allowed to, but it is never
        # given special unilateral authority just for coming from C2.
        r = self.post(f"/c2-integrations/{integration['id']}/directive", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "merge duplicate records", "category": "security",
            "risk_level": "high",  # high risk -> must require approval
        })
        self.assertEqual(r.status_code, 200)
        proposal = r.get_json()
        self.assertTrue(proposal["requires_approval"])
        self.assertFalse(proposal["auto_applied"])
        self.assertEqual(proposal["status"], "pending")

    def test_directive_forced_categories_still_require_approval(self):
        integration = self.make_c2(accepts_directives=True)
        system = self.make_system(permitted_categories=["payroll"])
        check = self.post("/checks", {
            "name": "c", "category": "payroll", "system_id": system["id"], "check_logic_ref": "r",
        }).get_json()
        finding = self.post("/findings", {
            "check_id": check["id"], "system_id": system["id"], "entity_type": "x",
            "severity": "low", "summary": "s",
        }).get_json()

        r = self.post(f"/c2-integrations/{integration['id']}/directive", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "adjust payroll value", "category": "payroll", "risk_level": "low",
        })
        proposal = r.get_json()
        self.assertTrue(proposal["requires_approval"])  # payroll always requires approval


if __name__ == "__main__":
    unittest.main()
