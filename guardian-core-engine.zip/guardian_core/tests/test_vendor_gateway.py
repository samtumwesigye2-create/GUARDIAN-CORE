import os
import sys
import json
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import create_app  # noqa: E402

try:
    from _helpers import AuthClient
except ImportError:
    from tests._helpers import AuthClient

TEST_API_KEY = "test-service-key"


class VendorGatewayTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(db_path=self.db_path, api_key=TEST_API_KEY)
        self.client = AuthClient(self.app.test_client(), TEST_API_KEY)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def post(self, path, payload, headers=None):
        return self.client.post(path, data=json.dumps(payload), content_type="application/json",
                                 headers=headers)

    def make_system(self, **overrides):
        payload = {"system_key": "vendor_x", "display_name": "Vendor X", "category": "vendor"}
        payload.update(overrides)
        r = self.post("/systems", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def make_connector(self, **overrides):
        payload = {
            "connector_key": "vendor_x_gateway", "display_name": "Vendor X Gateway",
            "connector_type": "vendor_gateway", "direction": "outbound",
            "authorized_by": "security-lead@example.com",
        }
        payload.update(overrides)
        r = self.post("/connectors", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()


class TestConnectorRegistry(VendorGatewayTestCase):
    def test_register_connector(self):
        connector = self.make_connector()
        self.assertEqual(connector["connector_key"], "vendor_x_gateway")
        self.assertTrue(connector["is_active"])

    def test_duplicate_connector_key_rejected(self):
        self.make_connector()
        r = self.post("/connectors", {
            "connector_key": "vendor_x_gateway", "display_name": "dup",
            "connector_type": "vendor_gateway", "direction": "outbound",
            "authorized_by": "someone@example.com",
        })
        self.assertEqual(r.status_code, 409)


class TestVendorGatewayIsolation(VendorGatewayTestCase):
    def test_one_way_webhook_gateway_created(self):
        vendor = self.make_system()
        connector = self.make_connector()
        r = self.post("/vendor-gateway-connectors", {
            "connector_id": connector["id"], "vendor_system_id": vendor["id"],
            "data_direction": "guardian_pushes_alerts_to_vendor",
            "exposed_fields": ["alert_summary", "severity"],
            "isolation_method": "one_way_webhook",
        })
        self.assertEqual(r.status_code, 200)
        gateway = r.get_json()
        self.assertEqual(gateway["isolation_method"], "one_way_webhook")
        self.assertEqual(gateway["exposed_fields"], ["alert_summary", "severity"])

    def test_direct_db_link_rejected(self):
        vendor = self.make_system()
        connector = self.make_connector()
        r = self.post("/vendor-gateway-connectors", {
            "connector_id": connector["id"], "vendor_system_id": vendor["id"],
            "data_direction": "guardian_reads_from_vendor",
            "exposed_fields": ["status"],
            "isolation_method": "direct_db_link",
        })
        self.assertEqual(r.status_code, 409)

    def test_empty_exposed_fields_rejected(self):
        vendor = self.make_system()
        connector = self.make_connector()
        r = self.post("/vendor-gateway-connectors", {
            "connector_id": connector["id"], "vendor_system_id": vendor["id"],
            "data_direction": "guardian_reads_from_vendor",
            "exposed_fields": [],
            "isolation_method": "dmz_proxy",
        })
        self.assertEqual(r.status_code, 409)

    def test_vendor_system_cannot_be_granted_admin_scope(self):
        vendor = self.make_system()
        connector = self.make_connector()
        self.post("/vendor-gateway-connectors", {
            "connector_id": connector["id"], "vendor_system_id": vendor["id"],
            "data_direction": "guardian_reads_from_vendor",
            "exposed_fields": ["status"],
            "isolation_method": "signed_event_relay",
        })
        r = self.post("/admins", {
            "identity_ref": "vendor-contact@example.com", "role": "approver",
            "system_scope": [vendor["id"]],
        })
        self.assertEqual(r.status_code, 403)

    def test_admin_scoped_to_non_vendor_system_still_works(self):
        internal = self.make_system(system_key="internal_hr", category="hr")
        r = self.post("/admins", {
            "identity_ref": "hr-admin@example.com", "role": "approver",
            "system_scope": [internal["id"]],
        })
        self.assertEqual(r.status_code, 200)

    def test_admin_with_no_scope_still_works_even_with_vendor_registered(self):
        vendor = self.make_system()
        connector = self.make_connector()
        self.post("/vendor-gateway-connectors", {
            "connector_id": connector["id"], "vendor_system_id": vendor["id"],
            "data_direction": "guardian_reads_from_vendor",
            "exposed_fields": ["status"],
            "isolation_method": "signed_event_relay",
        })
        # global admin (system_scope=None) — different from being SCOPED to the vendor
        r = self.post("/admins", {"identity_ref": "global-admin@example.com", "role": "super_admin"})
        self.assertEqual(r.status_code, 200)


if __name__ == "__main__":
    unittest.main()
