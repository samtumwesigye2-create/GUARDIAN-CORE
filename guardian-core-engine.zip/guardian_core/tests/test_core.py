import os
import sys
import json
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import create_app  # noqa: E402

try:
    from _helpers import AuthClient
except ImportError:
    from tests._helpers import AuthClient

TEST_API_KEY = "test-service-key"


class GuardianTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)  # let init_db create it fresh
        self.app = create_app(db_path=self.db_path, api_key=TEST_API_KEY)
        self.client = AuthClient(self.app.test_client(), TEST_API_KEY)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    # ---- helpers ----

    def post(self, path, payload, headers=None):
        return self.client.post(path, data=json.dumps(payload), content_type="application/json",
                                 headers=headers)

    def make_system(self, **overrides):
        payload = {
            "system_key": "ugaforce_hr",
            "display_name": "UGAFORCE-HR",
            "category": "hr",
            "criticality": "high",
            "trust_level": "standard",
            "permitted_categories": ["data_quality", "performance"],
            "connection_type": "db_direct",
        }
        payload.update(overrides)
        r = self.post("/systems", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def make_check(self, system_id, **overrides):
        payload = {
            "name": "Duplicate employee records",
            "category": "data_quality",
            "scope": "single_system",
            "system_id": system_id,
            "check_logic_ref": "dup_employee_check_v1",
            "auto_fix_allowed": True,
        }
        payload.update(overrides)
        r = self.post("/checks", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def make_finding(self, check_id, system_id, **overrides):
        payload = {
            "check_id": check_id,
            "system_id": system_id,
            "entity_type": "employee",
            "severity": "low",
            "summary": "Duplicate email detected",
        }
        payload.update(overrides)
        r = self.post("/findings", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()


class TestHealth(GuardianTestCase):
    def test_health(self):
        r = self.client.get("/health")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "ok")


class TestSystemRegistration(GuardianTestCase):
    def test_register_system(self):
        system = self.make_system()
        self.assertEqual(system["system_key"], "ugaforce_hr")
        self.assertTrue(system["is_active"])

    def test_duplicate_system_key_rejected(self):
        self.make_system()
        r = self.post("/systems", {
            "system_key": "ugaforce_hr", "display_name": "dup", "category": "hr",
        })
        self.assertEqual(r.status_code, 409)


class TestChecks(GuardianTestCase):
    def test_single_system_check_requires_system_id(self):
        r = self.post("/checks", {
            "name": "orphan check", "category": "data_quality",
            "scope": "single_system", "check_logic_ref": "ref",
        })
        self.assertEqual(r.status_code, 409)

    def test_cross_system_check_allows_null_system_id(self):
        r = self.post("/checks", {
            "name": "cross system login burst", "category": "security",
            "scope": "cross_system", "check_logic_ref": "ref",
        })
        self.assertEqual(r.status_code, 200)


class TestFindings(GuardianTestCase):
    def test_create_and_resolve_finding(self):
        system = self.make_system()
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])
        self.assertEqual(finding["status"], "open")

        r = self.post(f"/findings/{finding['id']}/resolve", {
            "resolved_by": "alice@example.com", "status": "fixed",
        })
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "fixed")

    def test_cannot_resolve_already_resolved_finding(self):
        system = self.make_system()
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])
        self.post(f"/findings/{finding['id']}/resolve", {
            "resolved_by": "alice@example.com", "status": "fixed",
        })
        r = self.post(f"/findings/{finding['id']}/resolve", {
            "resolved_by": "alice@example.com", "status": "fixed",
        })
        self.assertEqual(r.status_code, 409)


class TestFixProposalSafetyRules(GuardianTestCase):
    """The part that actually matters: verifying the approval rules
    from the design doc are enforced, not just documented."""

    def test_low_risk_permitted_category_auto_applies(self):
        system = self.make_system(permitted_categories=["data_quality"])
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])

        r = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "normalize phone number format",
            "change_json": {"before": "0771-234-567", "after": "+256771234567"},
            "category": "data_quality", "risk_level": "low",
        })
        self.assertEqual(r.status_code, 200)
        proposal = r.get_json()
        self.assertTrue(proposal["auto_applied"])
        self.assertEqual(proposal["status"], "applied")
        self.assertFalse(proposal["requires_approval"])

    def test_high_risk_requires_approval_even_if_permitted_category(self):
        system = self.make_system(permitted_categories=["data_quality"])
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])

        r = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "merge two duplicate employee records",
            "change_json": {"merge": ["emp_1", "emp_2"]},
            "category": "data_quality", "risk_level": "high",
        })
        proposal = r.get_json()
        self.assertFalse(proposal["auto_applied"])
        self.assertTrue(proposal["requires_approval"])
        self.assertEqual(proposal["status"], "pending")

    def test_category_not_in_permitted_list_requires_approval(self):
        system = self.make_system(permitted_categories=["performance"])
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])

        r = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "normalize phone number", "change_json": {},
            "category": "data_quality", "risk_level": "low",
        })
        proposal = r.get_json()
        self.assertTrue(proposal["requires_approval"])
        self.assertFalse(proposal["auto_applied"])

    def test_protected_categories_always_require_approval(self):
        for forced_category in ("finance", "payroll", "benefits", "compensation",
                                 "tax", "vault_secret", "code_patch", "infrastructure"):
            with self.subTest(category=forced_category):
                system = self.make_system(
                    system_key=f"sys_{forced_category}",
                    permitted_categories=[forced_category],
                )
                check = self.make_check(system["id"])
                finding = self.make_finding(check["id"], system["id"])

                r = self.post("/fix-proposals", {
                    "finding_id": finding["id"], "system_id": system["id"],
                    "proposed_action": "adjust value", "change_json": {},
                    "category": forced_category, "risk_level": "low",
                })
                proposal = r.get_json()
                self.assertTrue(proposal["requires_approval"], forced_category)
                self.assertFalse(proposal["auto_applied"], forced_category)


class TestApprovalWorkflow(GuardianTestCase):
    def test_approval_flow_happy_path(self):
        system = self.make_system(permitted_categories=["data_quality"])
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])

        proposal = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "merge duplicate records", "change_json": {},
            "category": "data_quality", "risk_level": "high",
        }).get_json()
        self.assertEqual(proposal["status"], "pending")

        admin = self.post("/admins", {
            "identity_ref": "admin@example.com", "role": "approver", "system_scope": None,
        }).get_json()

        r = self.post(f"/fix-proposals/{proposal['id']}/approve", {},
                       headers={"X-Admin-Api-Key": admin["api_key"]})
        self.assertEqual(r.status_code, 200)
        approved = r.get_json()
        self.assertEqual(approved["status"], "approved")
        self.assertEqual(approved["approved_by"], "admin@example.com")

        r = self.client.post(f"/fix-proposals/{proposal['id']}/apply")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "applied")

    def test_viewer_cannot_approve(self):
        system = self.make_system()
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])
        proposal = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "x", "change_json": {},
            "category": "security", "risk_level": "high",
        }).get_json()

        viewer = self.post("/admins", {"identity_ref": "viewer@example.com", "role": "viewer"}).get_json()

        r = self.post(f"/fix-proposals/{proposal['id']}/approve", {},
                       headers={"X-Admin-Api-Key": viewer["api_key"]})
        self.assertEqual(r.status_code, 403)

    def test_admin_scoped_to_other_system_cannot_approve(self):
        system_a = self.make_system(system_key="sys_a")
        system_b = self.make_system(system_key="sys_b")
        check = self.make_check(system_a["id"])
        finding = self.make_finding(check["id"], system_a["id"])
        proposal = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system_a["id"],
            "proposed_action": "x", "change_json": {},
            "category": "security", "risk_level": "high",
        }).get_json()

        scoped = self.post("/admins", {
            "identity_ref": "scoped@example.com", "role": "approver",
            "system_scope": [system_b["id"]],
        }).get_json()

        r = self.post(f"/fix-proposals/{proposal['id']}/approve", {},
                       headers={"X-Admin-Api-Key": scoped["api_key"]})
        self.assertEqual(r.status_code, 403)

    def test_cannot_apply_before_approval(self):
        system = self.make_system()
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])
        proposal = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "x", "change_json": {},
            "category": "security", "risk_level": "high",
        }).get_json()

        r = self.client.post(f"/fix-proposals/{proposal['id']}/apply")
        self.assertEqual(r.status_code, 409)

    def test_cannot_approve_already_auto_applied_proposal(self):
        system = self.make_system(permitted_categories=["data_quality"])
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])
        proposal = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "x", "change_json": {},
            "category": "data_quality", "risk_level": "low",
        }).get_json()
        self.assertTrue(proposal["auto_applied"])

        admin2 = self.post("/admins", {"identity_ref": "admin2@example.com", "role": "super_admin"}).get_json()
        r = self.post(f"/fix-proposals/{proposal['id']}/approve", {},
                       headers={"X-Admin-Api-Key": admin2["api_key"]})
        self.assertEqual(r.status_code, 409)

    def test_rejected_proposal_cannot_be_applied(self):
        system = self.make_system()
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])
        proposal = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "x", "change_json": {},
            "category": "security", "risk_level": "high",
        }).get_json()

        admin3 = self.post("/admins", {"identity_ref": "admin3@example.com", "role": "super_admin"}).get_json()
        r = self.post(f"/fix-proposals/{proposal['id']}/reject", {"reason": "not needed"},
                       headers={"X-Admin-Api-Key": admin3["api_key"]})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "rejected")

        r = self.client.post(f"/fix-proposals/{proposal['id']}/apply")
        self.assertEqual(r.status_code, 409)

    def test_unknown_admin_api_key_rejected(self):
        system = self.make_system()
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])
        proposal = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "x", "change_json": {},
            "category": "security", "risk_level": "high",
        }).get_json()

        r = self.post(f"/fix-proposals/{proposal['id']}/approve", {},
                       headers={"X-Admin-Api-Key": "gdn_not-a-real-key"})
        self.assertEqual(r.status_code, 403)

    def test_missing_admin_api_key_rejected(self):
        system = self.make_system()
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])
        proposal = self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "x", "change_json": {},
            "category": "security", "risk_level": "high",
        }).get_json()

        r = self.post(f"/fix-proposals/{proposal['id']}/approve", {})
        self.assertEqual(r.status_code, 401)


class TestActionLog(GuardianTestCase):
    def test_action_log_records_key_events(self):
        system = self.make_system(permitted_categories=["data_quality"])
        check = self.make_check(system["id"])
        finding = self.make_finding(check["id"], system["id"])
        self.post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "x", "change_json": {},
            "category": "data_quality", "risk_level": "low",
        })

        r = self.client.get(f"/action-log?system_id={system['id']}")
        self.assertEqual(r.status_code, 200)
        action_types = {row["action_type"] for row in r.get_json()}
        self.assertIn("finding_created", action_types)
        self.assertIn("fix_auto_applied", action_types)


if __name__ == "__main__":
    unittest.main()
