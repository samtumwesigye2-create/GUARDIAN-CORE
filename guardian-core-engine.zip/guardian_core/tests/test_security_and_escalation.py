import os
import sys
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import create_app  # noqa: E402

try:
    from _helpers import AuthClient
except ImportError:
    from tests._helpers import AuthClient

TEST_API_KEY = "test-service-key"


class EscalationTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(db_path=self.db_path, api_key=TEST_API_KEY)
        self.client = AuthClient(self.app.test_client(), TEST_API_KEY)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def post(self, path, payload, headers=None):
        return self.client.post(path, data=json.dumps(payload), content_type="application/json",
                                 headers=headers)

    def make_system(self, **overrides):
        payload = {
            "system_key": "internal_comms",
            "display_name": "Internal Comms",
            "category": "comms",
            "permitted_categories": ["data_quality"],
        }
        payload.update(overrides)
        r = self.post("/systems", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()


class TestSecurityIncidents(EscalationTestCase):
    def test_create_incident_with_allowed_auto_response(self):
        system = self.make_system()
        r = self.post("/security-incidents", {
            "incident_type": "brute_force",
            "severity": "medium",
            "system_id": system["id"],
            "auto_response": "account_locked",
        })
        self.assertEqual(r.status_code, 200)
        incident = r.get_json()
        self.assertEqual(incident["status"], "open")
        self.assertEqual(incident["auto_response"], "account_locked")

    def test_disallowed_auto_response_rejected(self):
        system = self.make_system()
        r = self.post("/security-incidents", {
            "incident_type": "data_exfil_attempt",
            "severity": "critical",
            "system_id": system["id"],
            "auto_response": "delete_all_data",  # not an allowed reversible action
        })
        self.assertEqual(r.status_code, 409)

    def test_permanent_ban_rejected(self):
        system = self.make_system()
        r = self.post("/security-incidents", {
            "incident_type": "brute_force",
            "severity": "high",
            "system_id": system["id"],
            "auto_response": "permanent_ban",
        })
        self.assertEqual(r.status_code, 409)

    def test_resolve_incident(self):
        system = self.make_system()
        incident = self.post("/security-incidents", {
            "incident_type": "brute_force", "severity": "low", "system_id": system["id"],
        }).get_json()
        r = self.post(f"/security-incidents/{incident['id']}/resolve", {"resolved_by": "sec@example.com"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "resolved")

    def test_cannot_resolve_twice(self):
        system = self.make_system()
        incident = self.post("/security-incidents", {
            "incident_type": "brute_force", "severity": "low", "system_id": system["id"],
        }).get_json()
        self.post(f"/security-incidents/{incident['id']}/resolve", {"resolved_by": "sec@example.com"})
        r = self.post(f"/security-incidents/{incident['id']}/resolve", {"resolved_by": "sec@example.com"})
        self.assertEqual(r.status_code, 409)


class TestEscalationTrigger(EscalationTestCase):
    def test_critical_incident_triggers_matching_policy(self):
        system = self.make_system()
        self.post("/admins", {"identity_ref": "oncall1@example.com", "role": "approver"})
        self.post("/admins", {"identity_ref": "oncall2@example.com", "role": "super_admin"})

        self.post("/escalation-policies", {
            "name": "Comms critical incidents",
            "applies_to_severity": "critical",
            "system_id": system["id"],
            "escalation_order": ["oncall1@example.com", "oncall2@example.com"],
            "step_timeout_minutes": 15,
        })

        self.post("/security-incidents", {
            "incident_type": "data_exfil_attempt",
            "severity": "critical",
            "system_id": system["id"],
        })

        events = self.client.get("/escalation-events").get_json()
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["notified_ref"], "oncall1@example.com")
        self.assertEqual(events[0]["current_step"], 0)
        self.assertEqual(events[0]["status"], "active")

    def test_low_severity_incident_does_not_trigger_escalation(self):
        system = self.make_system()
        self.post("/admins", {"identity_ref": "oncall1@example.com", "role": "approver"})
        self.post("/escalation-policies", {
            "name": "Comms critical incidents",
            "applies_to_severity": "critical",
            "system_id": system["id"],
            "escalation_order": ["oncall1@example.com"],
        })
        self.post("/security-incidents", {
            "incident_type": "minor_anomaly", "severity": "low", "system_id": system["id"],
        })
        events = self.client.get("/escalation-events").get_json()
        self.assertEqual(len(events), 0)

    def test_global_policy_matches_any_system(self):
        system = self.make_system()
        self.post("/admins", {"identity_ref": "global_oncall@example.com", "role": "approver"})
        self.post("/escalation-policies", {
            "name": "Global high severity",
            "applies_to_severity": "high",
            "escalation_order": ["global_oncall@example.com"],
            # no system_id => applies to every system
        })
        self.post("/security-incidents", {
            "incident_type": "unusual_access_pattern", "severity": "high", "system_id": system["id"],
        })
        events = self.client.get("/escalation-events").get_json()
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["notified_ref"], "global_oncall@example.com")


class TestEscalationAcknowledgeAndTimeout(EscalationTestCase):
    def _setup_incident_with_policy(self, timeout_minutes=30):
        system = self.make_system()
        self.oncall1 = self.post("/admins", {"identity_ref": "oncall1@example.com", "role": "approver"}).get_json()
        self.oncall2 = self.post("/admins", {"identity_ref": "oncall2@example.com", "role": "super_admin"}).get_json()
        self.post("/escalation-policies", {
            "name": "policy", "applies_to_severity": "critical",
            "system_id": system["id"],
            "escalation_order": ["oncall1@example.com", "oncall2@example.com"],
            "step_timeout_minutes": timeout_minutes,
        })
        self.post("/security-incidents", {
            "incident_type": "brute_force", "severity": "critical", "system_id": system["id"],
        })
        event = self.client.get("/escalation-events").get_json()[0]
        return event

    @staticmethod
    def _minutes_after(event, minutes):
        notified_at = datetime.fromisoformat(event["notified_at"])
        return (notified_at + timedelta(minutes=minutes)).isoformat()

    def test_acknowledge_by_notified_admin(self):
        event = self._setup_incident_with_policy()
        r = self.post(f"/escalation-events/{event['id']}/acknowledge", {},
                       headers={"X-Admin-Api-Key": self.oncall1["api_key"]})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "acknowledged")

    def test_super_admin_can_acknowledge_even_if_not_currently_notified(self):
        event = self._setup_incident_with_policy()
        # oncall2 is step-2 (not yet notified), but has role super_admin,
        # so they're allowed to acknowledge on anyone's behalf (covering).
        r = self.post(f"/escalation-events/{event['id']}/acknowledge", {},
                       headers={"X-Admin-Api-Key": self.oncall2["api_key"]})
        self.assertEqual(r.status_code, 200)

    def test_unrelated_approver_cannot_acknowledge(self):
        event = self._setup_incident_with_policy()
        rando = self.post("/admins", {"identity_ref": "rando@example.com", "role": "approver"}).get_json()
        r = self.post(f"/escalation-events/{event['id']}/acknowledge", {},
                       headers={"X-Admin-Api-Key": rando["api_key"]})
        self.assertEqual(r.status_code, 403)

    def test_cannot_acknowledge_twice(self):
        event = self._setup_incident_with_policy()
        self.post(f"/escalation-events/{event['id']}/acknowledge", {},
                  headers={"X-Admin-Api-Key": self.oncall1["api_key"]})
        r = self.post(f"/escalation-events/{event['id']}/acknowledge", {},
                       headers={"X-Admin-Api-Key": self.oncall1["api_key"]})
        self.assertEqual(r.status_code, 409)

    def test_timeout_advances_to_next_step(self):
        event = self._setup_incident_with_policy(timeout_minutes=15)
        # simulate 20 minutes having passed since this event's notified_at
        future_now = self._minutes_after(event, 20)
        r = self.post("/process-escalations", {"now": future_now})
        self.assertEqual(r.status_code, 200)
        self.assertIn(event["id"], r.get_json()["advanced_or_exhausted"])

        updated = [e for e in self.client.get("/escalation-events").get_json() if e["id"] == event["id"]][0]
        self.assertEqual(updated["current_step"], 1)
        self.assertEqual(updated["notified_ref"], "oncall2@example.com")
        self.assertEqual(updated["status"], "active")

    def test_timeout_exhausts_after_last_step(self):
        event = self._setup_incident_with_policy(timeout_minutes=15)
        # first timeout: step 0 -> 1
        self.post("/process-escalations", {"now": self._minutes_after(event, 20)})
        # second timeout: step 1 -> exhausted (no more admins in order)
        r = self.post("/process-escalations", {"now": self._minutes_after(event, 40)})
        self.assertIn(event["id"], r.get_json()["advanced_or_exhausted"])

        updated = [e for e in self.client.get("/escalation-events").get_json() if e["id"] == event["id"]][0]
        self.assertEqual(updated["status"], "exhausted")

    def test_no_timeout_before_window_elapses(self):
        event = self._setup_incident_with_policy(timeout_minutes=30)
        r = self.post("/process-escalations", {"now": self._minutes_after(event, 5)})
        self.assertNotIn(event["id"], r.get_json()["advanced_or_exhausted"])

    def test_acknowledged_event_not_advanced_by_timeout(self):
        event = self._setup_incident_with_policy(timeout_minutes=15)
        self.post(f"/escalation-events/{event['id']}/acknowledge", {},
                  headers={"X-Admin-Api-Key": self.oncall1["api_key"]})
        r = self.post("/process-escalations", {"now": self._minutes_after(event, 300)})
        self.assertNotIn(event["id"], r.get_json()["advanced_or_exhausted"])


class TestEscalationPolicyValidation(EscalationTestCase):
    def test_empty_escalation_order_rejected(self):
        system = self.make_system()
        r = self.post("/escalation-policies", {
            "name": "bad policy", "applies_to_severity": "high",
            "system_id": system["id"], "escalation_order": [],
        })
        self.assertEqual(r.status_code, 409)


if __name__ == "__main__":
    unittest.main()
