import os
import sys
import json
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import create_app  # noqa: E402

TEST_API_KEY = "test-service-key"


class AuthTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(db_path=self.db_path, api_key=TEST_API_KEY)
        self.raw_client = self.app.test_client()  # deliberately NOT auto-authenticated

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)


class TestServiceApiKey(AuthTestCase):
    def test_health_does_not_require_auth(self):
        r = self.raw_client.get("/health")
        self.assertEqual(r.status_code, 200)

    def test_request_without_authorization_header_rejected(self):
        r = self.raw_client.get("/systems")
        self.assertEqual(r.status_code, 401)

    def test_request_with_malformed_authorization_header_rejected(self):
        r = self.raw_client.get("/systems", headers={"Authorization": TEST_API_KEY})  # missing "Bearer "
        self.assertEqual(r.status_code, 401)

    def test_request_with_wrong_key_rejected(self):
        r = self.raw_client.get("/systems", headers={"Authorization": "Bearer wrong-key"})
        self.assertEqual(r.status_code, 401)

    def test_request_with_correct_key_succeeds(self):
        r = self.raw_client.get("/systems", headers={"Authorization": f"Bearer {TEST_API_KEY}"})
        self.assertEqual(r.status_code, 200)

    def test_ephemeral_key_generated_when_none_provided_outside_production(self):
        fd, db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(db_path)
        try:
            app = create_app(db_path=db_path)  # no api_key passed, no env var set
            self.assertIn("API_KEY", app.config)
            self.assertTrue(app.config.get("API_KEY_AUTO_GENERATED"))
        finally:
            if os.path.exists(db_path):
                os.remove(db_path)

    def test_refuses_to_start_in_production_without_api_key(self):
        fd, db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(db_path)
        old_env = os.environ.get("GUARDIAN_ENV")
        os.environ["GUARDIAN_ENV"] = "production"
        try:
            with self.assertRaises(RuntimeError):
                create_app(db_path=db_path)  # no api_key, production mode
        finally:
            if old_env is None:
                os.environ.pop("GUARDIAN_ENV", None)
            else:
                os.environ["GUARDIAN_ENV"] = old_env
            if os.path.exists(db_path):
                os.remove(db_path)


class TestAdminApiKey(AuthTestCase):
    def _authed_post(self, path, payload, extra_headers=None):
        headers = {"Authorization": f"Bearer {TEST_API_KEY}"}
        if extra_headers:
            headers.update(extra_headers)
        return self.raw_client.post(path, data=json.dumps(payload),
                                     content_type="application/json", headers=headers)

    def _authed_get(self, path, extra_headers=None):
        headers = {"Authorization": f"Bearer {TEST_API_KEY}"}
        if extra_headers:
            headers.update(extra_headers)
        return self.raw_client.get(path, headers=headers)

    def make_system(self):
        r = self._authed_post("/systems", {
            "system_key": "hr", "display_name": "HR", "category": "hr",
        })
        return r.get_json()

    def make_pending_proposal(self, system):
        check = self._authed_post("/checks", {
            "name": "c", "category": "security", "system_id": system["id"], "check_logic_ref": "r",
        }).get_json()
        finding = self._authed_post("/findings", {
            "check_id": check["id"], "system_id": system["id"], "entity_type": "x",
            "severity": "high", "summary": "s",
        }).get_json()
        return self._authed_post("/fix-proposals", {
            "finding_id": finding["id"], "system_id": system["id"],
            "proposed_action": "x", "change_json": {},
            "category": "security", "risk_level": "high",
        }).get_json()

    def test_admin_registration_returns_raw_key_once(self):
        r = self._authed_post("/admins", {"identity_ref": "a@example.com", "role": "approver"})
        admin = r.get_json()
        self.assertIn("api_key", admin)
        self.assertTrue(admin["api_key"].startswith("gdn_"))

    def test_raw_key_never_appears_in_list_admins(self):
        self._authed_post("/admins", {"identity_ref": "a@example.com", "role": "approver"})
        admins = self._authed_get("/admins").get_json()
        for a in admins:
            self.assertNotIn("api_key", a)
            self.assertNotIn("api_key_hash", a)

    def test_approve_requires_admin_key_header(self):
        system = self.make_system()
        proposal = self.make_pending_proposal(system)
        r = self._authed_post(f"/fix-proposals/{proposal['id']}/approve", {})
        self.assertEqual(r.status_code, 401)

    def test_body_supplied_identity_is_ignored_without_valid_key(self):
        """The critical regression test: simply typing someone else's
        email in the request body must NOT be enough to act as them."""
        system = self.make_system()
        self._authed_post("/admins", {"identity_ref": "real-admin@example.com", "role": "super_admin"})
        proposal = self.make_pending_proposal(system)

        r = self._authed_post(f"/fix-proposals/{proposal['id']}/approve", {
            "admin_identity_ref": "real-admin@example.com",  # no key presented — must fail
        })
        self.assertEqual(r.status_code, 401)
        # proposal should still be pending — the spoofed approval never happened
        current = self._authed_get(f"/fix-proposals?status=pending").get_json()
        self.assertTrue(any(p["id"] == proposal["id"] for p in current))

    def test_approve_succeeds_with_correct_admin_key(self):
        system = self.make_system()
        admin = self._authed_post("/admins", {"identity_ref": "a@example.com", "role": "super_admin"}).get_json()
        proposal = self.make_pending_proposal(system)

        r = self._authed_post(f"/fix-proposals/{proposal['id']}/approve", {},
                               extra_headers={"X-Admin-Api-Key": admin["api_key"]})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "approved")

    def test_revoked_admin_key_no_longer_works(self):
        system = self.make_system()
        super_admin = self._authed_post("/admins", {
            "identity_ref": "boss@example.com", "role": "super_admin",
        }).get_json()
        admin = self._authed_post("/admins", {"identity_ref": "a@example.com", "role": "approver"}).get_json()
        proposal = self.make_pending_proposal(system)

        revoke = self._authed_post(f"/admins/a@example.com/revoke", {},
                                    extra_headers={"X-Admin-Api-Key": super_admin["api_key"]})
        self.assertEqual(revoke.status_code, 200)

        r = self._authed_post(f"/fix-proposals/{proposal['id']}/approve", {},
                               extra_headers={"X-Admin-Api-Key": admin["api_key"]})
        self.assertEqual(r.status_code, 403)

    def test_only_super_admin_can_revoke(self):
        approver = self._authed_post("/admins", {"identity_ref": "approver@example.com", "role": "approver"}).get_json()
        target = self._authed_post("/admins", {"identity_ref": "target@example.com", "role": "viewer"}).get_json()

        r = self._authed_post("/admins/target@example.com/revoke", {},
                               extra_headers={"X-Admin-Api-Key": approver["api_key"]})
        self.assertEqual(r.status_code, 403)


if __name__ == "__main__":
    unittest.main()
