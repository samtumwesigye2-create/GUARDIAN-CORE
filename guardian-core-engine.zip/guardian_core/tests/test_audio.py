import os
import sys
import json
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.main import create_app  # noqa: E402

try:
    from _helpers import AuthClient
except ImportError:
    from tests._helpers import AuthClient

TEST_API_KEY = "test-service-key"


class AudioTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        os.remove(self.db_path)
        self.app = create_app(db_path=self.db_path, api_key=TEST_API_KEY)
        self.client = AuthClient(self.app.test_client(), TEST_API_KEY)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def post(self, path, payload, headers=None):
        return self.client.post(path, data=json.dumps(payload), content_type="application/json",
                                 headers=headers)

    def make_system(self, **overrides):
        payload = {
            "system_key": "internal_comms",
            "display_name": "Internal Comms",
            "category": "comms",
            "permitted_categories": ["data_quality"],
        }
        payload.update(overrides)
        r = self.post("/systems", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def make_stream(self, system_id, **overrides):
        payload = {
            "system_id": system_id,
            "source_ref": "call_12345",
            "channel_count": 2,
            "sample_rate_hz": 48000,
        }
        payload.update(overrides)
        r = self.post("/audio-streams", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def make_band(self, **overrides):
        payload = {"name": "voice_band", "low_hz": 300, "high_hz": 3400}
        payload.update(overrides)
        r = self.post("/audio-bands", payload)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()


class TestAudioStreamsAndChannels(AudioTestCase):
    def test_stream_auto_creates_channels(self):
        system = self.make_system()
        stream = self.make_stream(system["id"], channel_count=3)
        self.assertEqual(stream["channel_count"], 3)
        self.assertEqual(len(stream["channel_ids"]), 3)

        channels = self.client.get(f"/audio-streams/{stream['id']}/channels").get_json()
        self.assertEqual(len(channels), 3)
        self.assertEqual([c["channel_index"] for c in channels], [0, 1, 2])

    def test_zero_channel_count_rejected(self):
        system = self.make_system()
        r = self.post("/audio-streams", {
            "system_id": system["id"], "source_ref": "call_x", "channel_count": 0,
        })
        self.assertEqual(r.status_code, 409)

    def test_update_channel_label_and_actor(self):
        system = self.make_system()
        stream = self.make_stream(system["id"])
        channel_id = stream["channel_ids"][0]
        r = self.post(f"/audio-channels/{channel_id}", {
            "channel_label": "alice_track", "actor_ref": "alice@example.com",
        })
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["channel_label"], "alice_track")
        self.assertEqual(r.get_json()["actor_ref"], "alice@example.com")

    def test_end_stream(self):
        system = self.make_system()
        stream = self.make_stream(system["id"])
        r = self.post(f"/audio-streams/{stream['id']}/end", {})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "ended")

    def test_cannot_end_already_ended_stream(self):
        system = self.make_system()
        stream = self.make_stream(system["id"])
        self.post(f"/audio-streams/{stream['id']}/end", {})
        r = self.post(f"/audio-streams/{stream['id']}/end", {})
        self.assertEqual(r.status_code, 409)


class TestAudioBands(AudioTestCase):
    def test_create_band(self):
        band = self.make_band()
        self.assertEqual(band["name"], "voice_band")
        self.assertTrue(band["is_active"])

    def test_duplicate_band_name_rejected(self):
        self.make_band()
        r = self.post("/audio-bands", {"name": "voice_band", "low_hz": 100, "high_hz": 200})
        self.assertEqual(r.status_code, 409)

    def test_invalid_range_rejected(self):
        r = self.post("/audio-bands", {"name": "bad_band", "low_hz": 5000, "high_hz": 100})
        self.assertEqual(r.status_code, 409)


class TestAudioBandMetrics(AudioTestCase):
    def test_record_and_list_metric(self):
        system = self.make_system()
        stream = self.make_stream(system["id"])
        band = self.make_band()
        channel_id = stream["channel_ids"][0]

        r = self.post("/audio-band-metrics", {
            "channel_id": channel_id, "band_id": band["id"],
            "window_start": "2026-09-06T10:00:00Z", "window_end": "2026-09-06T10:00:05Z",
            "avg_level_db": -20.5, "peak_level_db": -5.0, "noise_floor_db": -60.0,
            "clipping_ratio": 0.0, "silence_ratio": 0.1,
        })
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))

        metrics = self.client.get(f"/audio-channels/{channel_id}/metrics").get_json()
        self.assertEqual(len(metrics), 1)
        self.assertEqual(metrics[0]["avg_level_db"], -20.5)

    def test_clipping_ratio_out_of_range_rejected(self):
        system = self.make_system()
        stream = self.make_stream(system["id"])
        band = self.make_band()
        r = self.post("/audio-band-metrics", {
            "channel_id": stream["channel_ids"][0], "band_id": band["id"],
            "window_start": "t0", "window_end": "t1", "clipping_ratio": 1.5,
        })
        self.assertEqual(r.status_code, 409)

    def test_unknown_channel_rejected(self):
        band = self.make_band()
        r = self.post("/audio-band-metrics", {
            "channel_id": "does-not-exist", "band_id": band["id"],
            "window_start": "t0", "window_end": "t1",
        })
        self.assertEqual(r.status_code, 404)


class TestAudioFindings(AudioTestCase):
    def test_ordinary_finding_does_not_create_incident(self):
        system = self.make_system()
        stream = self.make_stream(system["id"])
        r = self.post("/audio-findings", {
            "stream_id": stream["id"], "finding_type": "dropout",
            "severity": "medium", "summary": "3-second dropout on channel 0",
            "channel_id": stream["channel_ids"][0],
        })
        self.assertEqual(r.status_code, 200)
        finding = r.get_json()
        self.assertIsNone(finding["linked_security_incident_id"])

        r = self.post(f"/audio-findings/{finding['id']}/resolve", {"resolved_by": "ops@example.com"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "resolved")

    def test_unauthorized_capture_finding_creates_security_incident(self):
        system = self.make_system()
        stream = self.make_stream(system["id"])
        r = self.post("/audio-findings", {
            "stream_id": stream["id"], "finding_type": "possible_unauthorized_capture",
            "severity": "critical", "summary": "unexpected second energy source detected",
            "channel_id": stream["channel_ids"][0],
        })
        self.assertEqual(r.status_code, 200)
        finding = r.get_json()
        self.assertIsNotNone(finding["linked_security_incident_id"])

        incidents = self.client.get("/security-incidents").get_json()
        self.assertEqual(len(incidents), 1)
        self.assertEqual(incidents[0]["incident_type"], "possible_unauthorized_capture")

    def test_cannot_resolve_unauthorized_capture_finding_before_incident_resolved(self):
        system = self.make_system()
        stream = self.make_stream(system["id"])
        finding = self.post("/audio-findings", {
            "stream_id": stream["id"], "finding_type": "possible_unauthorized_capture",
            "severity": "critical", "summary": "suspicious energy pattern",
        }).get_json()

        r = self.post(f"/audio-findings/{finding['id']}/resolve", {"resolved_by": "sec@example.com"})
        self.assertEqual(r.status_code, 409)

        # resolve the linked incident first, then the audio finding should be resolvable
        incident_id = finding["linked_security_incident_id"]
        self.post(f"/security-incidents/{incident_id}/resolve", {"resolved_by": "sec@example.com"})
        r = self.post(f"/audio-findings/{finding['id']}/resolve", {"resolved_by": "sec@example.com"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "resolved")

    def test_cannot_resolve_twice(self):
        system = self.make_system()
        stream = self.make_stream(system["id"])
        finding = self.post("/audio-findings", {
            "stream_id": stream["id"], "finding_type": "dropout",
            "severity": "low", "summary": "brief dropout",
        }).get_json()
        self.post(f"/audio-findings/{finding['id']}/resolve", {"resolved_by": "ops@example.com"})
        r = self.post(f"/audio-findings/{finding['id']}/resolve", {"resolved_by": "ops@example.com"})
        self.assertEqual(r.status_code, 409)

    def test_list_findings_filtered_by_stream_and_status(self):
        system = self.make_system()
        stream_a = self.make_stream(system["id"], source_ref="call_a")
        stream_b = self.make_stream(system["id"], source_ref="call_b")
        self.post("/audio-findings", {
            "stream_id": stream_a["id"], "finding_type": "dropout",
            "severity": "low", "summary": "a",
        })
        self.post("/audio-findings", {
            "stream_id": stream_b["id"], "finding_type": "clipping",
            "severity": "low", "summary": "b",
        })
        findings_a = self.client.get(f"/audio-findings?stream_id={stream_a['id']}").get_json()
        self.assertEqual(len(findings_a), 1)
        self.assertEqual(findings_a[0]["summary"], "a")


if __name__ == "__main__":
    unittest.main()
